import Link from 'next/link'
import {
  MoreHorizontal,
  Pencil,
  ExternalLink,
  Image as ImageIcon,
} from 'lucide-react'

export default function ProductTable({
  products,
}) {
  if (!products.length) {
    return (
      <div className="rounded-3xl border border-black/[0.05] bg-white px-6 py-20 text-center">

        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-neutral-100">
          <ImageIcon
            size={24}
            className="text-neutral-400"
          />
        </div>

        <h3 className="mt-5 text-lg font-semibold">
          No products found
        </h3>

        <p className="mx-auto mt-2 max-w-sm text-sm text-neutral-400">
          Try changing your search or filters,
          or create your first product.
        </p>

        <Link
          href="/admin/products/new"
          className="mt-6 inline-flex items-center rounded-xl bg-neutral-950 px-5 py-3 text-sm font-medium text-white"
        >
          Create Product
        </Link>

      </div>
    )
  }

  return (
    <div className="overflow-hidden rounded-3xl border border-black/[0.05] bg-white">

      {/* Desktop header */}

      <div className="hidden grid-cols-[minmax(260px,1.8fr)_1fr_120px_120px_80px] gap-4 border-b border-neutral-100 px-6 py-4 text-[10px] font-semibold uppercase tracking-[0.15em] text-neutral-400 md:grid">

        <span>Product</span>
        <span>Category</span>
        <span>Price</span>
        <span>Status</span>
        <span />

      </div>

      <div className="divide-y divide-neutral-100">

        {products.map((product) => (
          <ProductRow
            key={product.id}
            product={product}
          />
        ))}

      </div>

    </div>
  )
}

function ProductRow({
  product,
}) {
  const image =
    product.product_images?.find(
      (item) =>
        item.is_primary
    )?.image_url ||
    product.product_images?.[0]
      ?.image_url

  return (
    <div className="group px-4 py-4 transition hover:bg-neutral-50 md:px-6">

      {/* Desktop */}

      <div className="hidden grid-cols-[minmax(260px,1.8fr)_1fr_120px_120px_80px] items-center gap-4 md:grid">

        <ProductInfo
          product={product}
          image={image}
        />

        <Category
          product={product}
        />

        <Price
          product={product}
        />

        <Status
          product={product}
        />

        <Actions
          product={product}
        />

      </div>

      {/* Mobile */}

      <div className="flex items-center gap-4 md:hidden">

        <ProductImage
          image={image}
          name={product.name}
        />

        <div className="min-w-0 flex-1">

          <p className="truncate text-sm font-semibold">
            {product.name}
          </p>

          <p className="mt-1 text-xs text-neutral-400">
            {product.categories?.name ||
              'Uncategorized'}
          </p>

          <div className="mt-2 flex items-center gap-2">

            <span className="text-sm font-semibold">
              ₹{Number(
                product.base_price || 0
              ).toLocaleString('en-IN')}
            </span>

            <Status
              product={product}
            />

          </div>

        </div>

        <Actions
          product={product}
        />

      </div>

    </div>
  )
}

function ProductInfo({
  product,
  image,
}) {
  return (
    <div className="flex min-w-0 items-center gap-4">

      <ProductImage
        image={image}
        name={product.name}
      />

      <div className="min-w-0">

        <p className="truncate text-sm font-semibold">
          {product.name}
        </p>

        <p className="mt-1 truncate text-xs text-neutral-400">
          {product.slug}
        </p>

        <div className="mt-2 flex gap-1.5">

          {product.is_featured && (
            <Badge>
              Featured
            </Badge>
          )}

          {product.is_trending && (
            <Badge>
              Trending
            </Badge>
          )}

          {product.badge && (
            <Badge>
              {product.badge}
            </Badge>
          )}

        </div>

      </div>

    </div>
  )
}

function ProductImage({
  image,
  name,
}) {
  return (
    <div className="h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-neutral-100">

      {image ? (
        <img
          src={image}
          alt={name}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center text-neutral-300">
          <ImageIcon size={20} />
        </div>
      )}

    </div>
  )
}

function Category({
  product,
}) {
  return (
    <span className="text-sm text-neutral-500">
      {product.categories?.name ||
        'Uncategorized'}
    </span>
  )
}

function Price({
  product,
}) {
  return (
    <div>

      <p className="text-sm font-semibold">
        ₹{Number(
          product.base_price || 0
        ).toLocaleString('en-IN')}
      </p>

      {product.compare_price && (
        <p className="text-xs text-neutral-400 line-through">
          ₹{Number(
            product.compare_price
          ).toLocaleString('en-IN')}
        </p>
      )}

    </div>
  )
}

function Status({
  product,
}) {
  return (
    <span
      className={`inline-flex w-fit rounded-full px-2.5 py-1 text-[10px] font-semibold ${
        product.is_active
          ? 'bg-green-50 text-green-600'
          : 'bg-neutral-100 text-neutral-500'
      }`}
    >
      {product.is_active
        ? 'Active'
        : 'Inactive'}
    </span>
  )
}

function Badge({
  children,
}) {
  return (
    <span className="rounded-full bg-neutral-100 px-2 py-0.5 text-[8px] font-medium uppercase tracking-wide text-neutral-500">
      {children}
    </span>
  )
}

function Actions({
  product,
}) {
  return (
    <div className="flex items-center justify-end gap-1">

      <Link
        href={`/admin/products/${product.id}/edit`}
        className="flex h-9 w-9 items-center justify-center rounded-lg text-neutral-400 transition hover:bg-neutral-100 hover:text-neutral-900"
        title="Edit product"
      >
        <Pencil size={15} />
      </Link>

      <Link
        href={`/shop/${product.slug}`}
        target="_blank"
        className="flex h-9 w-9 items-center justify-center rounded-lg text-neutral-400 transition hover:bg-neutral-100 hover:text-neutral-900"
        title="View product"
      >
        <ExternalLink size={15} />
      </Link>

    </div>
  )
}