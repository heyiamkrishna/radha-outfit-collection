'use client'

import { useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft, Save, Trash2, X, Plus, Loader2, Package, UploadCloud } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { toast } from 'sonner'

// --- PREDEFINED OPTIONS ---
const SIZE_OPTIONS = ['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL', '4XL', 'Free Size']
const COLOR_OPTIONS = ['Black', 'White', 'Grey', 'Navy', 'Blue', 'Red', 'Maroon', 'Olive', 'Green', 'Beige', 'Brown', 'Pink', 'Purple', 'Yellow', 'Orange', 'Multi']

// --- IMAGE COMPRESSION ---
async function compressToWebP(file, maxWidth = 1600, maxHeight = 1600, quality = 0.82) {
  return new Promise((resolve, reject) => {
    const image = new window.Image()
    const objectUrl = URL.createObjectURL(file)

    image.onload = () => {
      try {
        let width = image.width
        let height = image.height
        const ratio = Math.min(maxWidth / width, maxHeight / height, 1)
        width = Math.round(width * ratio)
        height = Math.round(height * ratio)

        const canvas = document.createElement('canvas')
        canvas.width = width
        canvas.height = height
        const context = canvas.getContext('2d')
        context.drawImage(image, 0, 0, width, height)

        canvas.toBlob((blob) => {
          URL.revokeObjectURL(objectUrl)
          if (!blob) return reject(new Error('Unable to convert image.'))
          const webpFile = new File([blob], `${file.name.replace(/\.[^/.]+$/, '')}.webp`, { type: 'image/webp' })
          resolve(webpFile)
        }, 'image/webp', quality)
      } catch (error) {
        URL.revokeObjectURL(objectUrl)
        reject(error)
      }
    }
    image.onerror = () => {
      URL.revokeObjectURL(objectUrl)
      reject(new Error('Unable to read image.'))
    }
    image.src = objectUrl
  })
}

export default function ProductForm({ categories = [], initialData = null, productId = null }) {
  const router = useRouter()
  const supabase = createClient()
  const fileInputRef = useRef(null)

  const isEditing = !!productId

  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [isDragging, setIsDragging] = useState(false)

  // Parse initial data if editing
  const [form, setForm] = useState({
    name: initialData?.name || '',
    slug: initialData?.slug || '',
    description: initialData?.description || '',
    price: initialData?.base_price ?? initialData?.price ?? '',
    compare_price: initialData?.compare_price ?? '',
    stock: initialData?.stock ?? '',
    sku: initialData?.sku || '',
    category: initialData?.category_id || '',
    gender: initialData?.gender || '',
    sizes: Array.isArray(initialData?.sizes) ? initialData.sizes : [],
    colors: Array.isArray(initialData?.colors) ? initialData.colors : [],
    is_active: initialData?.is_active !== false,
  })

  // Format existing images
  let loadedImages = []
  if (Array.isArray(initialData?.images)) {
    loadedImages = initialData.images.map(img => typeof img === 'string' ? { url: img, isExisting: true } : { ...img, isExisting: true }).filter(img => img.url)
  } else if (initialData?.image_url) {
    loadedImages = [{ url: initialData.image_url, isExisting: true }]
  }

  const [images, setImages] = useState(loadedImages)
  const [newImages, setNewImages] = useState([])
  const [sizeInput, setSizeInput] = useState('')
  const [colorInput, setColorInput] = useState('')

  function updateField(field, value) {
    setForm(current => ({ ...current, [field]: value }))
  }

  // --- ARRAY MANAGEMENT (DROPDOWNS) ---
  function addSize() {
    const val = sizeInput.trim()
    if (!val || form.sizes.includes(val)) return setSizeInput('')
    updateField('sizes', [...form.sizes, val])
    setSizeInput('')
  }
  function removeSize(size) { updateField('sizes', form.sizes.filter(s => s !== size)) }
  
  function addColor() {
    const val = colorInput.trim()
    if (!val || form.colors.includes(val)) return setColorInput('')
    updateField('colors', [...form.colors, val])
    setColorInput('')
  }
  function removeColor(color) { updateField('colors', form.colors.filter(c => c !== color)) }

  // --- DRAG AND DROP IMAGES ---
  function openImagePicker() { fileInputRef.current?.click() }
  
  function handleDragOver(e) { e.preventDefault(); setIsDragging(true) }
  function handleDragLeave(e) { e.preventDefault(); setIsDragging(false) }
  function handleDrop(e) {
    e.preventDefault()
    setIsDragging(false)
    processFiles(Array.from(e.dataTransfer.files))
  }
  function handleFileInput(e) { processFiles(Array.from(e.target.files || [])) }

  async function processFiles(files) {
    if (!files.length) return
    try {
      setUploading(true)
      const processed = []
      for (const file of files) {
        if (!file.type.startsWith('image/')) continue
        const webp = await compressToWebP(file)
        processed.push({ file: webp, preview: URL.createObjectURL(webp) })
      }
      setNewImages(curr => [...curr, ...processed])
    } catch (err) {
      toast.error('Unable to process images.')
    } finally {
      setUploading(false)
      if (fileInputRef.current) fileInputRef.current.value = ''
    }
  }

  function removeExistingImage(index) { setImages(curr => curr.filter((_, i) => i !== index)) }
  function removeNewImage(index) {
    setNewImages(curr => {
      if (curr[index]?.preview) URL.revokeObjectURL(curr[index].preview)
      return curr.filter((_, i) => i !== index)
    })
  }

  // --- DB SUBMIT ---
  async function handleSubmit(event) {
    event.preventDefault()
    if (!form.name.trim()) return toast.error('Product name is required.')
    if (!form.price || Number(form.price) < 0) return toast.error('Please enter a valid price.')

    setSaving(true)
    const toastId = toast.loading(isEditing ? 'Updating product...' : 'Creating product...')

    try {
      let targetId = productId

      // 1. GENERATE UNIQUE SLUG TO PREVENT DATABASE ERRORS
      const generatedSlug = form.name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
      const finalSlug = form.slug.trim() ? form.slug.trim() : `${generatedSlug}-${Math.random().toString(36).substring(2, 6)}`

      if (!isEditing) {
        const { data: newProd, error: insertError } = await supabase
          .from('products')
          .insert([{
            name: form.name.trim(),
            slug: finalSlug, // Safe, unique slug
            base_price: Number(form.price),
            is_active: form.is_active
          }])
          .select('id')
          .single()

        if (insertError) throw insertError
        targetId = newProd.id
      }

      // 2. UPLOAD IMAGES TO 'product-images' BUCKET
      const uploadedImages = []
      for (const item of newImages) {
        const fileName = `${crypto.randomUUID()}.webp`
        const filePath = `products/${targetId}/${fileName}`
        
        const { error: uploadErr } = await supabase.storage.from('product-images').upload(filePath, item.file, { contentType: 'image/webp' })
        if (uploadErr) throw uploadErr
        
        const { data: pubData } = supabase.storage.from('product-images').getPublicUrl(filePath)
        uploadedImages.push({ url: pubData.publicUrl, path: filePath })
      }

      const finalImages = [...images.map(img => ({ url: img.url, path: img.path || null })), ...uploadedImages]
      
      // 3. DELETE REMOVED IMAGES FROM STORAGE
      if (isEditing) {
        const removedImages = loadedImages.filter(old => !finalImages.some(newImg => newImg.url === old.url))
        for (const img of removedImages) {
          if (img.path) await supabase.storage.from('product-images').remove([img.path])
        }
      }

      // 4. UPDATE FULL RECORD
      const updateData = {
        name: form.name.trim(),
        slug: finalSlug,
        description: form.description.trim(),
        base_price: Number(form.price),
        compare_price: form.compare_price ? Number(form.compare_price) : null,
        stock: Number(form.stock || 0),
        sku: form.sku.trim() || null,
        category_id: form.category || null,
        gender: form.gender || null,
        sizes: form.sizes,
        colors: form.colors,
        images: finalImages,
        image_url: finalImages[0]?.url || null, 
        is_active: form.is_active,
        updated_at: new Date().toISOString(),
      }

      const { error: updateError } = await supabase
        .from('products')
        .update(updateData)
        .eq('id', targetId)

      if (updateError) throw updateError

      toast.success(isEditing ? 'Product updated!' : 'Product created!', { id: toastId })

      if (!isEditing) {
        router.push('/admin/products') 
        router.refresh()
      } else {
        newImages.forEach(i => i.preview && URL.revokeObjectURL(i.preview))
        setNewImages([])
        setImages(finalImages)
        router.refresh()
      }

    } catch (err) {
      console.error(err)
      toast.error(err.message || 'Failed to save product.', { id: toastId })
    } finally {
      setSaving(false)
    }
  }

  async function handleDelete() {
    if (!window.confirm(`Delete "${form.name}"?\nThis action cannot be undone.`)) return
    try {
      setDeleting(true)
      const toastId = toast.loading('Deleting product...')
      const { error } = await supabase.from('products').delete().eq('id', productId)
      if (error) throw error
      toast.success('Product deleted', { id: toastId })
      router.push('/admin/products')
      router.refresh()
    } catch (err) {
      toast.error('Unable to delete product.')
      setDeleting(false)
    }
  }

  return (
    <div className="min-h-screen pb-24">
      {/* HEADER */}
      <div className="sticky top-0 z-30 border-b border-neutral-200 bg-[#f5f4f0]/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 md:px-8">
          <div className="flex items-center gap-4">
            <Link href="/admin/products" className="flex h-10 w-10 items-center justify-center rounded-xl bg-white border border-neutral-200 hover:bg-neutral-50 hover:border-neutral-300 transition-all shadow-sm">
              <ArrowLeft size={18} className="text-neutral-600" />
            </Link>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-neutral-400">Admin / Products</p>
              <h1 className="text-xl font-bold tracking-tight text-neutral-900">{isEditing ? 'Edit Product' : 'New Product'}</h1>
            </div>
          </div>
          <div className="flex gap-3">
            {isEditing && (
              <button onClick={handleDelete} disabled={deleting || saving} className="flex h-10 items-center gap-2 rounded-xl border border-red-100 bg-red-50 px-5 text-sm font-semibold text-red-600 hover:bg-red-100 transition-colors shadow-sm">
                {deleting ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />} <span className="hidden sm:inline">Delete</span>
              </button>
            )}
            <button onClick={handleSubmit} disabled={saving || deleting} className="flex h-10 items-center gap-2 rounded-xl bg-neutral-900 px-6 text-sm font-semibold text-white hover:bg-black transition-all shadow-md active:scale-95">
              {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} Save Product
            </button>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-6xl px-4 py-8 md:px-8">
        <form onSubmit={handleSubmit} className="grid gap-8 lg:grid-cols-[1fr_360px]">
          
          <div className="space-y-8">
            {/* BASIC INFO */}
            <section className="rounded-3xl border border-neutral-200 bg-white p-6 md:p-8 shadow-sm">
              <h2 className="mb-6 text-lg font-bold tracking-tight text-neutral-900">Basic Information</h2>
              <div className="space-y-5">
                <div>
                  <label className="mb-2 block text-sm font-semibold text-neutral-700">Product Name</label>
                  <input type="text" value={form.name} onChange={e => updateField('name', e.target.value)} placeholder="e.g., Oversized Graphic T-Shirt" className="h-12 w-full rounded-xl border border-neutral-200 px-4 text-sm outline-none focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 transition-all bg-neutral-50 focus:bg-white" />
                </div>
                <div>
                  <label className="mb-2 block text-sm font-semibold text-neutral-700">Slug (Optional URL)</label>
                  <input type="text" value={form.slug} onChange={e => updateField('slug', e.target.value)} placeholder="Leave blank to auto-generate" className="h-12 w-full rounded-xl border border-neutral-200 px-4 text-sm font-mono outline-none focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 transition-all bg-neutral-50 focus:bg-white" />
                </div>
                <div>
                  <label className="mb-2 block text-sm font-semibold text-neutral-700">Description</label>
                  <textarea rows={5} value={form.description} onChange={e => updateField('description', e.target.value)} placeholder="Describe the material, fit, and style..." className="w-full rounded-xl border border-neutral-200 px-4 py-3 text-sm outline-none focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 transition-all bg-neutral-50 focus:bg-white resize-y" />
                </div>
              </div>
            </section>

            {/* DRAG & DROP IMAGES */}
            <section className="rounded-3xl border border-neutral-200 bg-white p-6 md:p-8 shadow-sm">
              <div className="mb-6 flex justify-between items-end">
                <div>
                  <h2 className="text-lg font-bold tracking-tight text-neutral-900">Media</h2>
                  <p className="text-xs text-neutral-500 mt-1">First image will be the display image.</p>
                </div>
                <button type="button" onClick={openImagePicker} className="flex h-9 items-center gap-2 rounded-lg border border-neutral-200 bg-white px-4 text-xs font-semibold text-neutral-700 hover:bg-neutral-50 transition-colors shadow-sm">
                  Upload <Plus size={14} />
                </button>
              </div>

              <div 
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`relative w-full rounded-2xl border-2 border-dashed transition-all duration-200 flex flex-col items-center justify-center p-10 ${isDragging ? 'border-neutral-900 bg-neutral-50' : 'border-neutral-200 bg-neutral-50/50 hover:bg-neutral-50'}`}
              >
                <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={handleFileInput} />
                {uploading ? (
                  <div className="flex flex-col items-center text-neutral-500 gap-3">
                    <Loader2 size={32} className="animate-spin text-neutral-400"/> 
                    <p className="text-sm font-medium">Processing & Compressing...</p>
                  </div>
                ) : (
                  <>
                    <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-sm border border-neutral-100 mb-4 text-neutral-400">
                      <UploadCloud size={24} />
                    </div>
                    <p className="text-sm font-semibold text-neutral-700 mb-1">Click to upload or drag and drop</p>
                    <p className="text-xs text-neutral-500">SVG, PNG, JPG or WEBP</p>
                  </>
                )}
              </div>
              
              {(images.length > 0 || newImages.length > 0) && (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mt-6">
                  {images.map((img, i) => (
                    <div key={`exist-${i}`} className="group relative aspect-[3/4] rounded-xl bg-neutral-100 overflow-hidden border border-neutral-200 shadow-sm">
                      <img src={img.url} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" alt="Product" />
                      {i === 0 && <span className="absolute left-2 top-2 bg-black/80 backdrop-blur-sm text-white text-[10px] font-bold tracking-wider px-2 py-1 rounded-md">MAIN</span>}
                      <button type="button" onClick={() => removeExistingImage(i)} className="absolute right-2 top-2 h-7 w-7 rounded-full bg-white text-red-500 opacity-0 group-hover:opacity-100 flex items-center justify-center shadow-md transform scale-90 group-hover:scale-100 transition-all"><X size={14}/></button>
                    </div>
                  ))}
                  {newImages.map((img, i) => (
                    <div key={`new-${i}`} className="group relative aspect-[3/4] rounded-xl bg-neutral-100 overflow-hidden border border-neutral-200 shadow-sm">
                      <img src={img.preview} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" alt="New" />
                      <span className="absolute left-2 top-2 bg-emerald-500 text-white text-[10px] font-bold tracking-wider px-2 py-1 rounded-md">NEW</span>
                      <button type="button" onClick={() => removeNewImage(i)} className="absolute right-2 top-2 h-7 w-7 rounded-full bg-white text-red-500 opacity-0 group-hover:opacity-100 flex items-center justify-center shadow-md transform scale-90 group-hover:scale-100 transition-all"><X size={14}/></button>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* PRICING & VARIANTS */}
            <div className="grid sm:grid-cols-2 gap-8">
              <section className="rounded-3xl border border-neutral-200 bg-white p-6 shadow-sm">
                <h2 className="mb-6 text-lg font-bold tracking-tight text-neutral-900">Pricing & Stock</h2>
                <div className="space-y-5">
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-neutral-700">Price (₹)</label>
                    <input type="number" value={form.price} onChange={e => updateField('price', e.target.value)} placeholder="0.00" className="h-12 w-full rounded-xl border border-neutral-200 px-4 text-sm outline-none focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 transition-all bg-neutral-50 focus:bg-white" />
                  </div>
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-neutral-700">Compare at (₹)</label>
                    <input type="number" value={form.compare_price} onChange={e => updateField('compare_price', e.target.value)} placeholder="0.00" className="h-12 w-full rounded-xl border border-neutral-200 px-4 text-sm outline-none focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 transition-all bg-neutral-50 focus:bg-white" />
                  </div>
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-neutral-700">Stock Quantity</label>
                    <input type="number" value={form.stock} onChange={e => updateField('stock', e.target.value)} placeholder="0" className="h-12 w-full rounded-xl border border-neutral-200 px-4 text-sm outline-none focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 transition-all bg-neutral-50 focus:bg-white" />
                  </div>
                </div>
              </section>

              {/* VARIANTS WITH DROPDOWNS */}
              <section className="rounded-3xl border border-neutral-200 bg-white p-6 shadow-sm">
                <h2 className="mb-6 text-lg font-bold tracking-tight text-neutral-900">Variants</h2>
                <div className="space-y-6">
                  
                  {/* SIZES DROPDOWN */}
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-neutral-700">Sizes</label>
                    <div className="flex gap-2">
                      <select 
                        value={sizeInput} 
                        onChange={e => setSizeInput(e.target.value)} 
                        className="h-11 flex-1 rounded-xl border border-neutral-200 px-4 text-sm outline-none focus:border-neutral-900 focus:ring-1 bg-neutral-50 focus:bg-white transition-all cursor-pointer"
                      >
                        <option value="">Select a size...</option>
                        {SIZE_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                      <button type="button" onClick={addSize} className="h-11 w-11 shrink-0 bg-neutral-900 hover:bg-black text-white rounded-xl flex items-center justify-center transition-colors shadow-sm"><Plus size={16}/></button>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-3">
                      {form.sizes.map(size => (
                        <span key={size} className="bg-neutral-100 border border-neutral-200 text-neutral-700 text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-2">{size} <X size={12} className="cursor-pointer text-neutral-400 hover:text-red-500 transition-colors" onClick={() => removeSize(size)}/></span>
                      ))}
                    </div>
                  </div>

                  {/* COLORS DROPDOWN */}
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-neutral-700">Colors</label>
                    <div className="flex gap-2">
                      <select 
                        value={colorInput} 
                        onChange={e => setColorInput(e.target.value)} 
                        className="h-11 flex-1 rounded-xl border border-neutral-200 px-4 text-sm outline-none focus:border-neutral-900 focus:ring-1 bg-neutral-50 focus:bg-white transition-all cursor-pointer"
                      >
                        <option value="">Select a color...</option>
                        {COLOR_OPTIONS.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                      <button type="button" onClick={addColor} className="h-11 w-11 shrink-0 bg-neutral-900 hover:bg-black text-white rounded-xl flex items-center justify-center transition-colors shadow-sm"><Plus size={16}/></button>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-3">
                      {form.colors.map(color => (
                        <span key={color} className="bg-neutral-100 border border-neutral-200 text-neutral-700 text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-2">{color} <X size={12} className="cursor-pointer text-neutral-400 hover:text-red-500 transition-colors" onClick={() => removeColor(color)}/></span>
                      ))}
                    </div>
                  </div>

                </div>
              </section>
            </div>
          </div>

          {/* RIGHT SIDEBAR */}
          <aside className="space-y-6 lg:sticky lg:top-28 lg:self-start">
            <section className="rounded-3xl border border-neutral-200 bg-white p-6 shadow-sm">
              <h2 className="mb-6 text-lg font-bold tracking-tight text-neutral-900">Organization</h2>
              <div className="space-y-5">
                <div>
                  <label className="mb-2 block text-sm font-semibold text-neutral-700">Category</label>
                  <select value={form.category} onChange={e => updateField('category', e.target.value)} className="h-12 w-full rounded-xl border border-neutral-200 bg-neutral-50 focus:bg-white px-4 text-sm outline-none focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 transition-all cursor-pointer">
                    <option value="">Select category...</option>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="mb-2 block text-sm font-semibold text-neutral-700">Gender</label>
                  <select value={form.gender} onChange={e => updateField('gender', e.target.value)} className="h-12 w-full rounded-xl border border-neutral-200 bg-neutral-50 focus:bg-white px-4 text-sm outline-none focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 transition-all cursor-pointer">
                    <option value="">Select gender...</option>
                    <option value="men">Men</option>
                    <option value="women">Women</option>
                    <option value="kids">Kids</option>
                    <option value="unisex">Unisex</option>
                  </select>
                </div>
              </div>
            </section>
            
            <section className="rounded-3xl border border-neutral-200 bg-white p-6 shadow-sm">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-bold text-neutral-900">Active Product</p>
                  <p className="text-xs text-neutral-500 mt-1">Visible on the storefront</p>
                </div>
                <button type="button" onClick={() => updateField('is_active', !form.is_active)} className={`relative h-7 w-12 rounded-full transition-colors duration-300 ${form.is_active ? 'bg-black' : 'bg-neutral-300'}`}>
                  <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow-sm transition-all duration-300 ${form.is_active ? 'left-6' : 'left-1'}`} />
                </button>
              </div>
            </section>
            
            {isEditing && (
              <section className="rounded-3xl border border-neutral-200 bg-neutral-50 p-6 flex items-center gap-4 shadow-sm">
                <div className="h-12 w-12 flex shrink-0 items-center justify-center rounded-xl bg-white border border-neutral-200 shadow-sm"><Package size={20} className="text-neutral-500" /></div>
                <div className="min-w-0">
                  <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-neutral-500">Product ID</p>
                  <p className="mt-1 truncate font-mono text-xs font-medium text-neutral-800">{productId}</p>
                </div>
              </section>
            )}
          </aside>
        </form>
      </main>
    </div>
  )
}