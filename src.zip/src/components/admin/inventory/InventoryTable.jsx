'use client'

import {
  useState,
} from 'react'

import {
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Loader2,
  Pencil,
  Trash2,
  Package,
} from 'lucide-react'

import Link from 'next/link'

import { toast } from 'sonner'

export default function InventoryTable({
  variants = [],
  onRefresh,
}) {
  const [
    editingId,
    setEditingId,
  ] = useState(null)

  const [
    editStock,
    setEditStock,
  ] = useState('')

  const [
    savingId,
    setSavingId,
  ] = useState(null)

  const [
    deletingId,
    setDeletingId,
  ] = useState(null)

  const [
    expandedId,
    setExpandedId,
  ] = useState(null)

  /*
  ==================================================
  START EDIT
  ==================================================
  */

  function startEdit(variant) {
    setEditingId(
      variant.id
    )

    setEditStock(
      String(
        variant.stock_quantity || 0
      )
    )
  }

  /*
  ==================================================
  CANCEL EDIT
  ==================================================
  */

  function cancelEdit() {
    setEditingId(null)
    setEditStock('')
  }

  /*
  ==================================================
  SAVE STOCK
  ==================================================
  */

  async function saveStock(
    variantId
  ) {
    const stock =
      Number(editStock)

    if (
      !Number.isInteger(stock) ||
      stock < 0
    ) {
      toast.error(
        'Enter a valid stock quantity.'
      )

      return
    }

    try {
      setSavingId(
        variantId
      )

      const response =
        await fetch(
          `/api/admin/inventory/${variantId}`,
          {
            method: 'PATCH',
            headers: {
              'Content-Type':
                'application/json',
            },
            body: JSON.stringify({
              stock_quantity:
                stock,
            }),
          }
        )

      const result =
        await response.json()

      if (!response.ok) {
        throw new Error(
          result.error ||
            'Unable to update stock.'
        )
      }

      toast.success(
        'Stock updated successfully.'
      )

      setEditingId(null)
      setEditStock('')

      if (onRefresh) {
        await onRefresh()
      }
    } catch (error) {
      console.error(
        'Stock update error:',
        error
      )

      toast.error(
        error?.message ||
          'Unable to update stock.'
      )
    } finally {
      setSavingId(null)
    }
  }

  /*
  ==================================================
  DELETE VARIANT
  ==================================================
  */

  async function deleteVariant(
    variant
  ) {
    const productName =
      variant.products?.name ||
      'this product'

    const variantName = [
      variant.size,
      variant.color,
    ]
      .filter(Boolean)
      .join(' / ')

    const confirmed =
      window.confirm(
        `Delete inventory variant for ${productName}${variantName ? ` (${variantName})` : ''}?\n\nThe product itself will NOT be deleted.`
      )

    if (!confirmed) {
      return
    }

    try {
      setDeletingId(
        variant.id
      )

      const response =
        await fetch(
          `/api/admin/inventory/${variant.id}`,
          {
            method: 'DELETE',
          }
        )

      const result =
        await response.json()

      if (!response.ok) {
        throw new Error(
          result.error ||
            'Unable to delete variant.'
        )
      }

      toast.success(
        'Inventory variant deleted.'
      )

      if (onRefresh) {
        await onRefresh()
      }
    } catch (error) {
      console.error(
        'Variant delete error:',
        error
      )

      toast.error(
        error?.message ||
          'Unable to delete variant.'
      )
    } finally {
      setDeletingId(null)
    }
  }

  /*
  ==================================================
  EMPTY
  ==================================================
  */

  if (!variants.length) {
    return (
      <div className="rounded-[28px] border border-black/[0.05] bg-white p-16 text-center shadow-[0_4px_20px_rgba(0,0,0,0.03)]">

        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-neutral-100">
          <Package
            size={26}
            className="text-neutral-400"
          />
        </div>

        <h3 className="mt-5 text-lg font-bold">
          No inventory found
        </h3>

        <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-neutral-400">
          Try changing your search or
          inventory filter.
        </p>

      </div>
    )
  }

  return (
    <div className="overflow-hidden rounded-[28px] border border-black/[0.05] bg-white shadow-[0_4px_20px_rgba(0,0,0,0.03)]">

      {/* ==========================================
          DESKTOP TABLE
      ========================================== */}

      <div className="hidden overflow-x-auto md:block">

        <table className="w-full min-w-[900px]">

          <thead>
            <tr className="border-b border-neutral-100 text-left">

              <th className="px-6 py-5 text-xs font-semibold uppercase tracking-wider text-neutral-400">
                Product
              </th>

              <th className="px-6 py-5 text-xs font-semibold uppercase tracking-wider text-neutral-400">
                SKU
              </th>

              <th className="px-6 py-5 text-xs font-semibold uppercase tracking-wider text-neutral-400">
                Variant
              </th>

              <th className="px-6 py-5 text-xs font-semibold uppercase tracking-wider text-neutral-400">
                Stock
              </th>

              <th className="px-6 py-5 text-xs font-semibold uppercase tracking-wider text-neutral-400">
                Status
              </th>

              <th className="px-6 py-5 text-right text-xs font-semibold uppercase tracking-wider text-neutral-400">
                Actions
              </th>

            </tr>
          </thead>

          <tbody>

            {variants.map(
              (variant) => {
                const stock =
                  Number(
                    variant.stock_quantity ||
                      0
                  )

                const product =
                  variant.products

                const isEditing =
                  editingId ===
                  variant.id

                const isSaving =
                  savingId ===
                  variant.id

                const isDeleting =
                  deletingId ===
                  variant.id

                const isExpanded =
                  expandedId ===
                  variant.id

                return (
                  <tr
                    key={variant.id}
                    className="border-b border-neutral-100 last:border-0 hover:bg-neutral-50/70"
                  >

                    {/* PRODUCT */}

                    <td className="px-6 py-5">

                      <div className="flex items-center gap-4">

                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-neutral-100">
                          <Package
                            size={18}
                            className="text-neutral-400"
                          />
                        </div>

                        <div className="min-w-0">

                          <p className="truncate text-sm font-semibold text-neutral-900">
                            {product?.name ||
                              'Unknown Product'}
                          </p>

                          <p className="mt-1 text-xs text-neutral-400">
                            {product?.slug ||
                              '—'}
                          </p>

                        </div>

                      </div>

                    </td>

                    {/* SKU */}

                    <td className="px-6 py-5">

                      <span className="rounded-lg bg-neutral-100 px-3 py-1.5 font-mono text-xs text-neutral-600">
                        {variant.sku ||
                          '—'}
                      </span>

                    </td>

                    {/* VARIANT */}

                    <td className="px-6 py-5">

                      <div className="flex flex-wrap gap-2">

                        {variant.size && (
                          <span className="rounded-lg border border-neutral-200 px-2.5 py-1 text-xs font-medium">
                            {variant.size}
                          </span>
                        )}

                        {variant.color && (
                          <span className="rounded-lg border border-neutral-200 px-2.5 py-1 text-xs font-medium">
                            {variant.color}
                          </span>
                        )}

                        {!variant.size &&
                          !variant.color && (
                            <span className="text-xs text-neutral-400">
                              Default
                            </span>
                          )}

                      </div>

                    </td>

                    {/* STOCK */}

                    <td className="px-6 py-5">

                      {isEditing ? (
                        <div className="flex items-center gap-2">

                          <input
                            type="number"
                            min="0"
                            value={
                              editStock
                            }
                            onChange={(
                              event
                            ) =>
                              setEditStock(
                                event
                                  .target
                                  .value
                              )
                            }
                            className="h-10 w-24 rounded-xl border border-neutral-200 bg-white px-3 text-sm font-semibold outline-none focus:border-black"
                            autoFocus
                          />

                          <button
                            type="button"
                            disabled={
                              isSaving
                            }
                            onClick={() =>
                              saveStock(
                                variant.id
                              )
                            }
                            className="h-10 rounded-xl bg-black px-3 text-xs font-semibold text-white"
                          >
                            {isSaving ? (
                              <Loader2
                                size={15}
                                className="animate-spin"
                              />
                            ) : (
                              'Save'
                            )}
                          </button>

                          <button
                            type="button"
                            disabled={
                              isSaving
                            }
                            onClick={
                              cancelEdit
                            }
                            className="h-10 rounded-xl border border-neutral-200 px-3 text-xs font-semibold"
                          >
                            Cancel
                          </button>

                        </div>
                      ) : (
                        <span className="text-sm font-bold">
                          {stock}
                        </span>
                      )}

                    </td>

                    {/* STATUS */}

                    <td className="px-6 py-5">

                      <StockStatus
                        stock={
                          stock
                        }
                      />

                    </td>

                    {/* ACTIONS */}

                    <td className="px-6 py-5">

                      <div className="flex items-center justify-end gap-2">

                        <button
                          type="button"
                          onClick={() => {
                            if (
                              isExpanded
                            ) {
                              setExpandedId(
                                null
                              )
                            } else {
                              setExpandedId(
                                variant.id
                              )
                            }
                          }}
                          className="flex h-10 w-10 items-center justify-center rounded-xl border border-neutral-200 transition hover:bg-neutral-100"
                          title="View variant"
                        >
                          {isExpanded ? (
                            <ChevronUp
                              size={16}
                            />
                          ) : (
                            <ChevronDown
                              size={16}
                            />
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            startEdit(
                              variant
                            )
                          }
                          className="flex h-10 w-10 items-center justify-center rounded-xl border border-neutral-200 transition hover:bg-neutral-100"
                          title="Edit stock"
                        >
                          <Pencil
                            size={16}
                          />
                        </button>

                        <Link
                          href={`/product/${product?.slug || product?.id}`}
                          target="_blank"
                          className="flex h-10 w-10 items-center justify-center rounded-xl border border-neutral-200 transition hover:bg-neutral-100"
                          title="View product"
                        >
                          <ExternalLink
                            size={16}
                          />
                        </Link>

                        <button
                          type="button"
                          disabled={
                            isDeleting
                          }
                          onClick={() =>
                            deleteVariant(
                              variant
                            )
                          }
                          className="flex h-10 w-10 items-center justify-center rounded-xl border border-red-100 text-red-500 transition hover:bg-red-50 disabled:opacity-50"
                          title="Delete inventory variant"
                        >
                          {isDeleting ? (
                            <Loader2
                              size={16}
                              className="animate-spin"
                            />
                          ) : (
                            <Trash2
                              size={16}
                            />
                          )}
                        </button>

                      </div>

                    </td>

                  </tr>
                )
              }
            )}

          </tbody>

        </table>

      </div>

      {/* ==========================================
          MOBILE CARDS
      ========================================== */}

      <div className="divide-y divide-neutral-100 md:hidden">

        {variants.map(
          (variant) => {
            const stock =
              Number(
                variant.stock_quantity ||
                  0
              )

            const product =
              variant.products

            const isEditing =
              editingId ===
              variant.id

            const isSaving =
              savingId ===
              variant.id

            const isDeleting =
              deletingId ===
              variant.id

            return (
              <div
                key={variant.id}
                className="p-5"
              >

                <div className="flex items-start justify-between gap-4">

                  <div className="min-w-0">

                    <p className="truncate text-sm font-bold">
                      {product?.name ||
                        'Unknown Product'}
                    </p>

                    <p className="mt-1 font-mono text-[11px] text-neutral-400">
                      {variant.sku ||
                        'NO SKU'}
                    </p>

                  </div>

                  <StockStatus
                    stock={stock}
                  />

                </div>

                <div className="mt-4 flex flex-wrap gap-2">

                  {variant.size && (
                    <span className="rounded-lg bg-neutral-100 px-3 py-1.5 text-xs">
                      Size: {variant.size}
                    </span>
                  )}

                  {variant.color && (
                    <span className="rounded-lg bg-neutral-100 px-3 py-1.5 text-xs">
                      Color: {variant.color}
                    </span>
                  )}

                </div>

                <div className="mt-5 rounded-2xl bg-neutral-50 p-4">

                  <p className="text-xs text-neutral-400">
                    Stock
                  </p>

                  {isEditing ? (
                    <div className="mt-3 flex gap-2">

                      <input
                        type="number"
                        min="0"
                        value={
                          editStock
                        }
                        onChange={(
                          event
                        ) =>
                          setEditStock(
                            event
                              .target
                              .value
                          )
                        }
                        className="h-11 min-w-0 flex-1 rounded-xl border border-neutral-200 bg-white px-3 text-sm font-semibold outline-none focus:border-black"
                      />

                      <button
                        type="button"
                        disabled={
                          isSaving
                        }
                        onClick={() =>
                          saveStock(
                            variant.id
                          )
                        }
                        className="h-11 rounded-xl bg-black px-4 text-xs font-semibold text-white"
                      >
                        {isSaving ? (
                          <Loader2
                            size={15}
                            className="animate-spin"
                          />
                        ) : (
                          'Save'
                        )}
                      </button>

                    </div>
                  ) : (
                    <p className="mt-1 text-2xl font-bold">
                      {stock}
                    </p>
                  )}

                </div>

                <div className="mt-4 flex gap-2">

                  {!isEditing && (
                    <button
                      type="button"
                      onClick={() =>
                        startEdit(
                          variant
                        )
                      }
                      className="flex h-11 flex-1 items-center justify-center gap-2 rounded-xl border border-neutral-200 text-xs font-semibold"
                    >
                      <Pencil
                        size={15}
                      />
                      Edit Stock
                    </button>
                  )}

                  <Link
                    href={`/product/${product?.slug || product?.id}`}
                    target="_blank"
                    className="flex h-11 w-11 items-center justify-center rounded-xl border border-neutral-200"
                  >
                    <ExternalLink
                      size={15}
                    />
                  </Link>

                  <button
                    type="button"
                    disabled={
                      isDeleting
                    }
                    onClick={() =>
                      deleteVariant(
                        variant
                      )
                    }
                    className="flex h-11 w-11 items-center justify-center rounded-xl border border-red-100 text-red-500"
                  >
                    {isDeleting ? (
                      <Loader2
                        size={15}
                        className="animate-spin"
                      />
                    ) : (
                      <Trash2
                        size={15}
                      />
                    )}
                  </button>

                </div>

              </div>
            )
          }
        )}

      </div>

    </div>
  )
}

/*
==================================================
STOCK STATUS
==================================================
*/

function StockStatus({
  stock,
}) {
  if (stock <= 0) {
    return (
      <span className="inline-flex rounded-full bg-red-50 px-3 py-1.5 text-[11px] font-semibold text-red-600">
        Out of Stock
      </span>
    )
  }

  if (stock <= 5) {
    return (
      <span className="inline-flex rounded-full bg-amber-50 px-3 py-1.5 text-[11px] font-semibold text-amber-600">
        Low Stock
      </span>
    )
  }

  return (
    <span className="inline-flex rounded-full bg-emerald-50 px-3 py-1.5 text-[11px] font-semibold text-emerald-600">
      In Stock
    </span>
  )
}