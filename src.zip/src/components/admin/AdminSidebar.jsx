'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion } from 'framer-motion'
import { useState } from 'react'

import {
  LayoutDashboard,
  ShoppingBag,
  Layers3,
  ShoppingCart,
  Users,
  Boxes,
  TicketPercent,
  Images,
  FileText,
  MessageSquare,
  Settings,
  X,
  ChevronLeft,
  ChevronRight,
  Store,
  Receipt,
  UserRoundPlus,
  PackageSearch,
} from 'lucide-react'

const navigation = [
  {
    label: 'Overview',
    items: [
      {
        name: 'Dashboard',
        href: '/admin',
        icon: LayoutDashboard,
      },
    ],
  },

  {
    label: 'Online Store',
    items: [
      {
        name: 'Products',
        href: '/admin/products',
        icon: ShoppingBag,
      },
      {
        name: 'Categories',
        href: '/admin/categories',
        icon: Layers3,
      },
      {
        name: 'Orders',
        href: '/admin/orders',
        icon: ShoppingCart,
      },
      {
        name: 'Customers',
        href: '/admin/customers',
        icon: Users,
      },
      {
        name: 'Inventory',
        href: '/admin/inventory',
        icon: Boxes,
      },
      {
        name: 'Coupons',
        href: '/admin/coupons',
        icon: TicketPercent,
      },
    ],
  },

  {
    label: 'Offline Store',
    items: [
      {
        name: 'New Sale',
        href: '/admin/offline/sale',
        icon: Receipt,
      },
      {
        name: 'Sales',
        href: '/admin/offline/sales',
        icon: Store,
      },
      {
        name: 'Customers',
        href: '/admin/offline/customers',
        icon: UserRoundPlus,
      },
      {
        name: 'Inventory',
        href: '/admin/offline/inventory',
        icon: PackageSearch,
      },
    ],
  },

  {
    label: 'Content',
    items: [
      {
        name: 'Hero Slides',
        href: '/admin/hero-slides',
        icon: Images,
      },
      {
        name: 'Blog',
        href: '/admin/blog',
        icon: FileText,
      },
      {
        name: 'Feedback',
        href: '/admin/feedback',
        icon: MessageSquare,
      },
    ],
  },

  {
    label: 'System',
    items: [
      {
        name: 'Settings',
        href: '/admin/settings',
        icon: Settings,
      },
    ],
  },
]

export default function AdminSidebar({ profile }) {
  const pathname = usePathname()

  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  const closeMobile = () => {
    setMobileOpen(false)
  }

  const isActive = (href) => {
    if (href === '/admin') {
      return pathname === '/admin'
    }

    return pathname === href || pathname.startsWith(`${href}/`)
  }

  const initials = (profile?.full_name || 'Administrator')
    .trim()
    .charAt(0)
    .toUpperCase()

  return (
    <>
      {/* =========================================================
          MOBILE MENU BUTTON
      ========================================================= */}

      <button
        type="button"
        aria-label="Open admin menu"
        onClick={() => setMobileOpen(true)}
        className="fixed left-4 top-4 z-[60] flex h-11 w-11 items-center justify-center rounded-xl border border-black/[0.06] bg-white/90 text-neutral-900 shadow-lg backdrop-blur-xl transition hover:bg-white lg:hidden"
      >
        <LayoutDashboard size={19} />
      </button>

      {/* =========================================================
          MOBILE BACKDROP
      ========================================================= */}

      <motion.div
        initial={false}
        animate={{
          opacity: mobileOpen ? 1 : 0,
          pointerEvents: mobileOpen ? 'auto' : 'none',
        }}
        className="fixed inset-0 z-40 bg-black/30 backdrop-blur-sm lg:hidden"
        onClick={closeMobile}
      />

      {/* =========================================================
          SIDEBAR
      ========================================================= */}

      <motion.aside
        initial={false}
        animate={{
          width: collapsed ? 82 : 260,
        }}
        transition={{
          type: 'spring',
          stiffness: 300,
          damping: 30,
        }}
        className={`fixed left-0 top-0 z-50 flex h-screen flex-col border-r border-black/[0.06] bg-white/90 shadow-xl backdrop-blur-2xl ${
          mobileOpen
            ? 'translate-x-0'
            : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* =======================================================
            BRAND
        ======================================================== */}

        <div className="flex h-20 shrink-0 items-center border-b border-black/[0.05] px-4">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-neutral-950 text-sm font-black text-white shadow-sm">
              R
            </div>

            {!collapsed && (
              <div className="min-w-0">
                <p className="truncate text-sm font-black tracking-tight text-neutral-950">
                  RADHA
                </p>

                <p className="truncate text-[9px] font-semibold uppercase tracking-[0.25em] text-neutral-400">
                  Outfit Collection
                </p>
              </div>
            )}
          </div>

          {/* Mobile close */}

          <button
            type="button"
            aria-label="Close admin menu"
            onClick={closeMobile}
            className="ml-auto rounded-xl p-2 text-neutral-400 transition hover:bg-neutral-100 hover:text-neutral-900 lg:hidden"
          >
            <X size={18} />
          </button>
        </div>

        {/* =======================================================
            NAVIGATION
        ======================================================== */}

        <nav className="flex-1 overflow-y-auto px-3 py-5">
          {navigation.map((section) => (
            <div
              key={section.label}
              className="mb-6"
            >
              {!collapsed && (
                <p className="mb-2 px-3 text-[9px] font-bold uppercase tracking-[0.2em] text-neutral-400">
                  {section.label}
                </p>
              )}

              <div className="space-y-1">
                {section.items.map((item) => {
                  const Icon = item.icon
                  const active = isActive(item.href)

                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      title={collapsed ? item.name : undefined}
                      onClick={closeMobile}
                      className="group relative flex items-center gap-3 overflow-hidden rounded-xl px-3 py-2.5 text-sm transition-colors duration-200"
                    >
                      {/* Active background */}

                      {active && (
                        <motion.div
                          layoutId="admin-active"
                          transition={{
                            type: 'spring',
                            stiffness: 400,
                            damping: 30,
                          }}
                          className="absolute inset-0 rounded-xl bg-neutral-950"
                        />
                      )}

                      {/* Hover background */}

                      {!active && (
                        <span className="absolute inset-0 rounded-xl bg-neutral-100 opacity-0 transition-opacity duration-200 group-hover:opacity-100" />
                      )}

                      {/* Icon */}

                      <Icon
                        size={18}
                        strokeWidth={1.8}
                        className={`relative z-10 shrink-0 transition-colors duration-200 ${
                          active
                            ? 'text-white'
                            : 'text-neutral-400 group-hover:text-neutral-900'
                        }`}
                      />

                      {/* Text */}

                      {!collapsed && (
                        <span
                          className={`relative z-10 truncate ${
                            active
                              ? 'font-semibold text-white'
                              : 'font-medium text-neutral-600 group-hover:text-neutral-950'
                          }`}
                        >
                          {item.name}
                        </span>
                      )}

                      {/* Active indicator */}

                      {active && !collapsed && (
                        <motion.span
                          layoutId="admin-active-dot"
                          className="relative z-10 ml-auto h-1.5 w-1.5 rounded-full bg-white"
                        />
                      )}
                    </Link>
                  )
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* =======================================================
            ADMIN PROFILE
        ======================================================== */}

        <div className="shrink-0 border-t border-black/[0.05] p-3">
          <div className="flex items-center gap-3 rounded-2xl bg-neutral-50 p-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-neutral-900 text-xs font-bold text-white">
              {initials}
            </div>

            {!collapsed && (
              <div className="min-w-0">
                <p className="truncate text-xs font-bold text-neutral-900">
                  {profile?.full_name || 'Administrator'}
                </p>

                <p className="truncate text-[10px] text-neutral-400">
                  Administrator
                </p>
              </div>
            )}
          </div>

          {/* =====================================================
              COLLAPSE BUTTON
          ====================================================== */}

          <button
            type="button"
            aria-label={
              collapsed
                ? 'Expand sidebar'
                : 'Collapse sidebar'
            }
            onClick={() => setCollapsed((value) => !value)}
            className="mt-2 hidden w-full items-center justify-center rounded-xl py-2 text-neutral-400 transition hover:bg-neutral-100 hover:text-neutral-900 lg:flex"
          >
            {collapsed ? (
              <ChevronRight size={17} />
            ) : (
              <ChevronLeft size={17} />
            )}
          </button>
        </div>
      </motion.aside>
    </>
  )
}