'use client'

import { useEffect, useState } from 'react'
import { X, Save } from 'lucide-react'

const emptySlide = {
  title: '',
  subtitle: '',
  description: '',
  image_url: '',
  mobile_image_url: '',
  badge: '',
  button_text: 'Shop Now',
  button_url: '/shop',
  text_position: 'left',
  is_active: true,
  sort_order: 0,
}

export default function HeroSlideForm({
  open,
  slide,
  onClose,
  onSave,
  saving,
}) {
  const [form, setForm] = useState(emptySlide)

  useEffect(() => {
    if (slide) {
      setForm({
        ...emptySlide,
        ...slide,
      })
    } else {
      setForm(emptySlide)
    }
  }, [slide, open])

  if (!open) {
    return null
  }

  function updateField(name, value) {
    setForm((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  function handleSubmit(e) {
    e.preventDefault()

    onSave({
      ...form,
      sort_order: Number(form.sort_order) || 0,
    })
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">

      <div className="max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-[28px] bg-white shadow-2xl">

        {/* HEADER */}

        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-neutral-100 bg-white px-6 py-5">

          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-neutral-400">
              {slide ? 'Edit Hero Slide' : 'New Hero Slide'}
            </p>

            <h2 className="mt-1 text-xl font-bold">
              {slide ? 'Update slide' : 'Create slide'}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-full bg-neutral-100 p-2.5 text-neutral-500 transition hover:bg-neutral-200 hover:text-black"
          >
            <X size={18} />
          </button>

        </div>

        {/* FORM */}

        <form
          onSubmit={handleSubmit}
          className="space-y-6 p-6"
        >

          {/* TITLE */}

          <div className="grid gap-5 md:grid-cols-2">

            <div>
              <label className="mb-2 block text-xs font-semibold text-neutral-700">
                Title
              </label>

              <input
                value={form.title}
                onChange={(e) =>
                  updateField(
                    'title',
                    e.target.value
                  )
                }
                placeholder="FALL / WINTER 2026"
                className="w-full rounded-2xl border border-neutral-200 px-4 py-3 text-sm outline-none transition focus:border-black"
              />
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-neutral-700">
                Subtitle
              </label>

              <input
                value={form.subtitle}
                onChange={(e) =>
                  updateField(
                    'subtitle',
                    e.target.value
                  )
                }
                placeholder="NEW COLLECTION"
                className="w-full rounded-2xl border border-neutral-200 px-4 py-3 text-sm outline-none transition focus:border-black"
              />
            </div>

          </div>

          {/* DESCRIPTION */}

          <div>
            <label className="mb-2 block text-xs font-semibold text-neutral-700">
              Description
            </label>

            <textarea
              value={form.description}
              onChange={(e) =>
                updateField(
                  'description',
                  e.target.value
                )
              }
              rows={4}
              placeholder="Heavyweight streetwear designed for everyday movement."
              className="w-full resize-none rounded-2xl border border-neutral-200 px-4 py-3 text-sm outline-none transition focus:border-black"
            />
          </div>

          {/* IMAGE */}

          <div className="rounded-2xl bg-neutral-50 p-4">

            <p className="mb-4 text-xs font-bold uppercase tracking-wider text-neutral-500">
              Images
            </p>

            <div className="space-y-4">

              <div>
                <label className="mb-2 block text-xs font-semibold text-neutral-700">
                  Desktop Image URL
                </label>

                <input
                  value={form.image_url}
                  onChange={(e) =>
                    updateField(
                      'image_url',
                      e.target.value
                    )
                  }
                  placeholder="https://..."
                  className="w-full rounded-2xl border border-neutral-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-black"
                />
              </div>

              <div>
                <label className="mb-2 block text-xs font-semibold text-neutral-700">
                  Mobile Image URL
                </label>

                <input
                  value={form.mobile_image_url || ''}
                  onChange={(e) =>
                    updateField(
                      'mobile_image_url',
                      e.target.value
                    )
                  }
                  placeholder="Optional mobile image"
                  className="w-full rounded-2xl border border-neutral-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-black"
                />
              </div>

            </div>

          </div>

          {/* BADGE */}

          <div>
            <label className="mb-2 block text-xs font-semibold text-neutral-700">
              Badge
            </label>

            <input
              value={form.badge || ''}
              onChange={(e) =>
                updateField(
                  'badge',
                  e.target.value
                )
              }
              placeholder="NEW DROP"
              className="w-full rounded-2xl border border-neutral-200 px-4 py-3 text-sm outline-none transition focus:border-black"
            />
          </div>

          {/* CTA */}

          <div className="grid gap-5 md:grid-cols-2">

            <div>
              <label className="mb-2 block text-xs font-semibold text-neutral-700">
                Button Text
              </label>

              <input
                value={form.button_text || ''}
                onChange={(e) =>
                  updateField(
                    'button_text',
                    e.target.value
                  )
                }
                placeholder="Shop Now"
                className="w-full rounded-2xl border border-neutral-200 px-4 py-3 text-sm outline-none transition focus:border-black"
              />
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-neutral-700">
                Button URL
              </label>

              <input
                value={form.button_url || ''}
                onChange={(e) =>
                  updateField(
                    'button_url',
                    e.target.value
                  )
                }
                placeholder="/shop"
                className="w-full rounded-2xl border border-neutral-200 px-4 py-3 text-sm outline-none transition focus:border-black"
              />
            </div>

          </div>

          {/* OPTIONS */}

          <div className="grid gap-5 md:grid-cols-3">

            <div>
              <label className="mb-2 block text-xs font-semibold text-neutral-700">
                Text Position
              </label>

              <select
                value={form.text_position || 'left'}
                onChange={(e) =>
                  updateField(
                    'text_position',
                    e.target.value
                  )
                }
                className="w-full rounded-2xl border border-neutral-200 bg-white px-4 py-3 text-sm outline-none focus:border-black"
              >
                <option value="left">Left</option>
                <option value="center">Center</option>
                <option value="right">Right</option>
              </select>
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-neutral-700">
                Sort Order
              </label>

              <input
                type="number"
                value={form.sort_order}
                onChange={(e) =>
                  updateField(
                    'sort_order',
                    e.target.value
                  )
                }
                min="0"
                className="w-full rounded-2xl border border-neutral-200 px-4 py-3 text-sm outline-none focus:border-black"
              />
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-neutral-700">
                Status
              </label>

              <button
                type="button"
                onClick={() =>
                  updateField(
                    'is_active',
                    !form.is_active
                  )
                }
                className={`flex w-full items-center justify-between rounded-2xl border px-4 py-3 text-sm font-semibold transition ${
                  form.is_active
                    ? 'border-green-200 bg-green-50 text-green-700'
                    : 'border-neutral-200 bg-neutral-50 text-neutral-500'
                }`}
              >
                <span>
                  {form.is_active
                    ? 'Active'
                    : 'Inactive'}
                </span>

                <span
                  className={`h-2.5 w-2.5 rounded-full ${
                    form.is_active
                      ? 'bg-green-500'
                      : 'bg-neutral-300'
                  }`}
                />
              </button>
            </div>

          </div>

          {/* ACTIONS */}

          <div className="flex justify-end gap-3 border-t border-neutral-100 pt-5">

            <button
              type="button"
              onClick={onClose}
              className="rounded-full border border-neutral-200 px-5 py-3 text-sm font-semibold transition hover:bg-neutral-50"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-full bg-black px-6 py-3 text-sm font-semibold text-white transition hover:bg-neutral-800 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Save size={16} />

              {saving
                ? 'Saving...'
                : slide
                  ? 'Update Slide'
                  : 'Create Slide'}
            </button>

          </div>

        </form>

      </div>

    </div>
  )
}