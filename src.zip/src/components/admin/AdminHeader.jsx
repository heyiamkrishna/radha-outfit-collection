'use client'

import { Bell, Search, ExternalLink } from 'lucide-react'
import Link from 'next/link'

export default function AdminHeader({ profile, email }) {
  return (
    <header className="fixed left-0 right-0 top-0 z-30 border-b border-black/[0.05] bg-[#f5f4f0]/80 backdrop-blur-xl lg:left-[260px]">

      <div className="flex h-20 items-center justify-between px-4 sm:px-6 lg:px-8">

        {/* Search */}

        <div className="hidden items-center gap-3 md:flex">

          <div className="flex h-10 w-[280px] items-center gap-2 rounded-xl border border-black/[0.06] bg-white/70 px-3">

            <Search
              size={16}
              className="text-neutral-400"
            />

            <input
              type="search"
              placeholder="Search anything..."
              className="w-full bg-transparent text-sm outline-none placeholder:text-neutral-400"
            />

            <kbd className="rounded-md bg-neutral-100 px-1.5 py-0.5 text-[9px] text-neutral-400">
              ⌘ K
            </kbd>

          </div>

        </div>

        {/* Right */}

        <div className="ml-auto flex items-center gap-2 sm:gap-4">

          <Link
            href="/"
            target="_blank"
            className="hidden items-center gap-2 rounded-xl px-3 py-2 text-xs font-medium text-neutral-500 transition hover:bg-white hover:text-neutral-900 sm:flex"
          >
            View Store
            <ExternalLink size={14} />
          </Link>

          <button className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-white/70 transition hover:bg-white">
            <Bell size={18} />

            <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-red-500" />
          </button>

          <div className="hidden h-8 w-px bg-black/10 sm:block" />

          <div className="text-right">

            <p className="text-xs font-semibold">
              {profile?.full_name || 'Admin'}
            </p>

            <p className="hidden text-[10px] text-neutral-400 sm:block">
              {email}
            </p>

          </div>

          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-neutral-950 text-sm font-semibold text-white">
            {(profile?.full_name || 'A')
              .charAt(0)
              .toUpperCase()}
          </div>

        </div>

      </div>

    </header>
  )
}