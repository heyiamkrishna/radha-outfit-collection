'use client'

import { useEffect, useState } from 'react'
import { useCartStore } from '@/store/cartStore'
import { X, Trash2, Plus, Minus, ShoppingBag } from 'lucide-react'
import Link from 'next/link'

export default function CartDrawer() {
  // Prevent hydration errors by waiting for component to mount on client
  const [isMounted, setIsMounted] = useState(false)
  
  const { 
    isCartOpen, 
    setIsCartOpen, 
    cartItems, 
    removeFromCart, 
    updateQuantity, 
    getCartTotal 
  } = useCartStore()

  useEffect(() => {
    setIsMounted(true)
  }, [])

  if (!isMounted || !isCartOpen) return null

  return (
    <div className="fixed inset-0 z-[100] flex justify-end">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/40 backdrop-blur-sm transition-opacity" 
        onClick={() => setIsCartOpen(false)} 
      />
      
      {/* Slide-out Drawer */}
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-neutral-100">
          <div className="flex items-center gap-2 font-[family-name:var(--font-syne)] text-xl font-bold">
            <ShoppingBag size={20} />
            Your Cart
          </div>
          <button 
            onClick={() => setIsCartOpen(false)}
            className="p-2 -mr-2 text-neutral-400 hover:text-black hover:bg-neutral-100 rounded-full transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {cartItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-neutral-500 space-y-4">
              <ShoppingBag size={48} className="opacity-20" />
              <p>Your cart is empty.</p>
              <button 
                onClick={() => setIsCartOpen(false)}
                className="text-black font-medium hover:underline"
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            cartItems.map((item) => (
              <div key={`${item.id}-${item.size}-${item.color}`} className="flex gap-4">
                <div className="w-20 h-24 bg-neutral-100 rounded-lg overflow-hidden shrink-0">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-medium text-sm line-clamp-1">{item.name}</h3>
                    <p className="text-xs text-neutral-500 mt-1">
                      {item.color} / {item.size}
                    </p>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="font-semibold text-sm">₹ {item.price}</span>
                    
                    {/* Quantity Controls */}
                    <div className="flex items-center border border-neutral-200 rounded-full h-8">
                      <button 
                        onClick={() => updateQuantity(item.id, item.size, item.color, item.quantity - 1)}
                        className="px-2.5 text-neutral-500 hover:text-black"
                      >
                        <Minus size={12} />
                      </button>
                      <span className="text-xs font-medium w-4 text-center">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(item.id, item.size, item.color, item.quantity + 1)}
                        className="px-2.5 text-neutral-500 hover:text-black"
                      >
                        <Plus size={12} />
                      </button>
                    </div>
                  </div>
                </div>
                <button 
                  onClick={() => removeFromCart(item.id, item.size, item.color)}
                  className="text-neutral-400 hover:text-red-500 transition-colors shrink-0 flex items-start p-1"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer / Checkout */}
        {cartItems.length > 0 && (
          <div className="border-t border-neutral-100 p-6 bg-neutral-50/50">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-neutral-500">Subtotal</span>
              <span className="font-bold text-lg">₹ {getCartTotal()}</span>
            </div>
            <p className="text-xs text-neutral-500 mb-6">Taxes and shipping calculated at checkout.</p>
            <Link 
              href="/checkout"
              onClick={() => setIsCartOpen(false)}
              className="w-full bg-black text-white py-4 rounded-full text-sm font-medium hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2"
            >
              Proceed to Checkout <span className="ml-1">→</span>
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}