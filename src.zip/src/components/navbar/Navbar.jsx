'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Search, ShoppingCart, Menu, X, User, LogOut, Package } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { useCartStore } from '@/store/cartStore'
import { createClient } from '@/lib/supabase/client'
import { logout } from '@/actions/auth'

export default function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isProfileOpen, setIsProfileOpen] = useState(false)
  const [isMounted, setIsMounted] = useState(false)

  // Authentication State
  const [user, setUser] = useState(null)

  const pathname = usePathname()

  // Pull cart logic from Zustand
  const { setIsCartOpen, getCartCount } = useCartStore()

  useEffect(() => {
    setIsMounted(true)

    // Fetch Supabase User Session
    const supabase = createClient()

    const fetchUser = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      setUser(user)
    }

    fetchUser()

    // Listen for real-time login/logout changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null)
    })

    return () => subscription.unsubscribe()
  }, [])

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'unset'
    }
  }, [isMobileMenuOpen])

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Collection', href: '/shop' },
    { name: 'Feedback', href: '/feedback' },
    { name: 'About Us', href: '/about' },
  ]

  const handleSignOut = async () => {
    await logout()
    setUser(null)
    setIsProfileOpen(false)
    setIsMobileMenuOpen(false)
  }

  // Helper to get first initial
  const userInitial = user?.user_metadata?.first_name?.charAt(0) || 'U'

  return (
    <header className="fixed top-4 left-0 right-0 z-40 px-4 md:px-8">
      <nav className="glass mx-auto max-w-7xl rounded-full px-6 py-4 flex items-center justify-between">

        {/* Logo */}
        <Link href="/" className="flex flex-col items-center z-50">
          <span className="font-[family-name:var(--font-syne)] text-2xl font-bold tracking-wide">RADHA</span>
          <span className="text-[10px] tracking-widest uppercase text-neutral-500 font-sans">Outfit Collection</span>
        </Link>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center space-x-8 text-sm font-medium">
          {navLinks.map((link) => {
            const isActive = pathname === link.href
            return (
              <Link
                key={link.name}
                href={link.href}
                className={`hover:text-neutral-600 transition-colors ${isActive ? 'border-b-2 border-black pb-1' : ''
                  }`}
              >
                {link.name}
              </Link>
            )
          })}
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-5 z-50">

          {/* Cart Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative hover:opacity-70 transition-opacity"
            aria-label="Open Cart"
          >
            <ShoppingCart size={20} strokeWidth={1.5} />
            {isMounted && getCartCount() > 0 && (
              <span className="absolute -top-2 -right-2 bg-black text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {getCartCount()}
              </span>
            )}
          </button>

          {/* Search Button */}
          <button aria-label="Search" className="hover:opacity-70 transition-opacity">
            <Search size={20} strokeWidth={1.5} />
          </button>

          {/* DESKTOP AUTH: Logged In vs Logged Out */}
          {user ? (
            <div className="relative hidden md:block">
              <button
                onClick={() => setIsProfileOpen(!isProfileOpen)}
                className="flex items-center gap-2 hover:opacity-70 transition-opacity bg-neutral-100 pl-1 pr-3 py-1 rounded-full"
              >
                <div className="w-7 h-7 bg-black text-white rounded-full flex items-center justify-center text-xs font-bold uppercase">
                  {userInitial}
                </div>
                <span className="text-sm font-bold text-black">
                  {user.user_metadata?.first_name || 'Account'}
                </span>
              </button>

              {/* Profile Dropdown */}
              <AnimatePresence>
                {isProfileOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full right-0 mt-4 w-56 bg-white border border-neutral-100 rounded-2xl shadow-xl shadow-black/[0.05] py-2 flex flex-col overflow-hidden"
                  >
                    <div className="px-4 py-3 border-b border-neutral-100 mb-2">
                      <p className="text-sm font-bold text-black truncate">
                        {user.user_metadata?.first_name} {user.user_metadata?.last_name}
                      </p>
                      <p className="text-[10px] text-neutral-500 truncate">{user.email}</p>
                    </div>
                    <Link onClick={() => setIsProfileOpen(false)} href="/account" className="flex items-center gap-3 px-4 py-2 text-xs font-bold text-neutral-500 hover:text-black hover:bg-neutral-50 transition-colors">
                      <Package size={14} /> My Orders
                    </Link>
                    <button onClick={handleSignOut} className="flex items-center gap-3 px-4 py-2 mt-1 border-t border-neutral-100 text-xs font-bold text-red-500 text-left hover:bg-red-50 transition-colors pt-3">
                      <LogOut size={14} /> Sign Out
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <Link href={`/auth/login?next=${pathname}`} className="hidden md:flex items-center bg-black text-white px-6 py-2 rounded-full text-sm font-medium hover:bg-neutral-800 transition-colors">
              Sign In
            </Link>
          )}

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden text-black hover:opacity-70 transition-opacity"
            onClick={() => setIsMobileMenuOpen(true)}
          >
            <Menu size={24} strokeWidth={1.5} />
          </button>
        </div>
      </nav>

      {/* Mobile Drawer (Right Side) */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <div className="fixed inset-0 z-[60] flex justify-end md:hidden">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm"
              onClick={() => setIsMobileMenuOpen(false)}
            />

            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', bounce: 0, duration: 0.4 }}
              className="relative w-4/5 max-w-sm bg-white h-full shadow-2xl flex flex-col pt-24 px-8"
            >
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="absolute top-8 right-6 text-neutral-500 hover:text-black transition-colors"
              >
                <X size={28} strokeWidth={1.5} />
              </button>

              <div className="flex flex-col space-y-8 text-xl font-medium mt-8">
                {navLinks.map((link) => {
                  const isActive = pathname === link.href
                  return (
                    <Link
                      key={link.name}
                      href={link.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={`transition-colors ${isActive ? 'text-black font-bold' : 'text-neutral-500 hover:text-black'
                        }`}
                    >
                      {link.name}
                    </Link>
                  )
                })}
              </div>

              {/* MOBILE AUTH: Logged In vs Logged Out */}
              <div className="mt-auto pb-12 flex flex-col gap-4">
                {user ? (
                  <>
                    <div className="flex items-center gap-3 px-4 py-3 bg-neutral-50 border border-neutral-100 rounded-2xl">
                      <div className="w-10 h-10 bg-black text-white rounded-full flex items-center justify-center font-bold uppercase">
                        {userInitial}
                      </div>
                      <div className="flex flex-col overflow-hidden">
                        <span className="text-sm font-bold text-black truncate">
                          {user.user_metadata?.first_name} {user.user_metadata?.last_name}
                        </span>
                        <span className="text-[10px] text-neutral-500 truncate">{user.email}</span>
                      </div>
                    </div>
                    <Link
                      href="/account"
                      onClick={() => setIsMobileMenuOpen(false)}
                      className="flex items-center justify-center bg-neutral-100 text-black w-full py-4 rounded-full text-sm font-bold hover:bg-neutral-200 transition-colors"
                    >
                      My Orders
                    </Link>
                    <button
                      onClick={handleSignOut}
                      className="flex items-center justify-center bg-black text-white w-full py-4 rounded-full text-sm font-bold hover:bg-neutral-800 transition-colors"
                    >
                      Sign Out
                    </button>
                  </>
                ) : (
                  <Link
                    href={`/auth/login?next=${pathname}`}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="flex items-center justify-center bg-black text-white w-full py-4 rounded-full text-base font-medium hover:bg-neutral-800 transition-colors"
                  >
                    Sign In
                  </Link>
                )}
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </header>
  )
}