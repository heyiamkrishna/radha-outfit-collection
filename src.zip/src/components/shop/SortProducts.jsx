'use client'

import { useRouter, usePathname, useSearchParams } from 'next/navigation'

export default function SortProducts({ currentSort }) {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  const handleSortChange = (e) => {
    const params = new URLSearchParams(searchParams.toString())
    params.set('sort', e.target.value)
    router.push(pathname + '?' + params.toString())
  }

  return (
    <div className="flex items-center gap-3 text-sm">
      <label htmlFor="sort" className="text-neutral-500 hidden md:block">Sort by:</label>
      <select
        id="sort"
        value={currentSort}
        onChange={handleSortChange}
        className="bg-transparent border border-neutral-200 rounded-full px-4 py-2 focus:outline-none focus:border-black focus:ring-1 focus:ring-black w-full md:w-auto"
      >
        <option value="newest">Newest Arrivals</option>
        <option value="price_asc">Price: Low to High</option>
        <option value="price_desc">Price: High to Low</option>
      </select>
    </div>
  )
}