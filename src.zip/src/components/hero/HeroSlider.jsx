'use client'

import { useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Sparkles,
} from 'lucide-react'

const AUTOPLAY_TIME = 6000

export default function HeroSlider({ slides = [] }) {
  const [current, setCurrent] = useState(0)
  const [isPaused, setIsPaused] = useState(false)
  const [direction, setDirection] = useState(1)

  const validSlides = useMemo(() => {
    if (!Array.isArray(slides)) return []

    return [...slides]
      .filter(
        (slide) =>
          slide &&
          slide.image_url &&
          slide.is_active !== false
      )
      .sort(
        (a, b) =>
          (a.sort_order ?? 0) -
          (b.sort_order ?? 0)
      )
  }, [slides])

  useEffect(() => {
    if (current >= validSlides.length) {
      setCurrent(0)
    }
  }, [current, validSlides.length])

  useEffect(() => {
    if (validSlides.length <= 1 || isPaused) {
      return
    }

    const timer = setInterval(() => {
      setDirection(1)

      setCurrent((previous) => {
        return previous === validSlides.length - 1
          ? 0
          : previous + 1
      })
    }, AUTOPLAY_TIME)

    return () => clearInterval(timer)
  }, [validSlides.length, isPaused])

  const nextSlide = () => {
    if (validSlides.length <= 1) return

    setDirection(1)

    setCurrent((previous) =>
      previous === validSlides.length - 1
        ? 0
        : previous + 1
    )
  }

  const previousSlide = () => {
    if (validSlides.length <= 1) return

    setDirection(-1)

    setCurrent((previous) =>
      previous === 0
        ? validSlides.length - 1
        : previous - 1
    )
  }

  const goToSlide = (index) => {
    if (index === current) return

    setDirection(index > current ? 1 : -1)
    setCurrent(index)
  }

  if (!validSlides.length) {
    return (
      <section className="relative min-h-[65svh] overflow-hidden rounded-[2rem] bg-neutral-950 text-white sm:min-h-[70svh] lg:min-h-[78svh]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(255,255,255,0.08),transparent_35%),radial-gradient(circle_at_80%_80%,rgba(255,255,255,0.06),transparent_35%)]" />

        <div className="relative z-10 flex min-h-[65svh] items-center justify-center px-6 text-center sm:min-h-[70svh] lg:min-h-[78svh]">
          <div>
            <Sparkles className="mx-auto mb-5 text-white/50" size={28} />

            <p className="mb-3 text-[10px] font-bold uppercase tracking-[0.35em] text-white/40">
              Radha Outfit Collection
            </p>

            <h1 className="font-[family-name:var(--font-syne)] text-4xl font-black tracking-tight sm:text-5xl md:text-6xl">
              No Hero Slides
            </h1>

            <p className="mx-auto mt-4 max-w-md text-sm leading-relaxed text-white/50">
              Add an active hero slide from your admin panel.
            </p>

            <Link
              href="/admin/hero-slider"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 text-xs font-extrabold uppercase tracking-wide text-black transition-transform duration-300 hover:-translate-y-1"
            >
              Manage Hero Slider
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>
    )
  }

  const slide = validSlides[current]

  return (
    <section
      className="relative w-full overflow-hidden rounded-[1.75rem] bg-black text-white shadow-[0_30px_100px_rgba(0,0,0,0.18)] sm:rounded-[2.25rem] lg:rounded-[2.75rem]"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={() => setIsPaused(true)}
      onTouchEnd={() => setIsPaused(false)}
    >
      <div className="relative min-h-[68svh] sm:min-h-[72svh] md:min-h-[76svh] lg:min-h-[80svh] xl:min-h-[84svh]">

        <AnimatePresence
          initial={false}
          custom={direction}
          mode="sync"
        >
          <motion.div
            key={slide.id || current}
            custom={direction}
            initial={{
              opacity: 0,
              x: direction > 0 ? 45 : -45,
            }}
            animate={{
              opacity: 1,
              x: 0,
            }}
            exit={{
              opacity: 0,
              x: direction > 0 ? -45 : 45,
            }}
            transition={{
              duration: 0.7,
              ease: [0.22, 1, 0.36, 1],
            }}
            className="absolute inset-0"
          >
            {/* IMAGE */}
            <motion.picture
              className="absolute inset-0 block"
              initial={{ scale: 1.035 }}
              animate={{ scale: 1 }}
              transition={{
                duration: 6.5,
                ease: 'easeOut',
              }}
            >
              <source
                media="(max-width: 767px)"
                srcSet={
                  slide.mobile_image_url ||
                  slide.image_url
                }
              />

              <img
                src={slide.image_url}
                alt={
                  slide.title ||
                  'Radha Outfit Collection'
                }
                className="h-full w-full object-cover object-center"
                loading={
                  current === 0
                    ? 'eager'
                    : 'lazy'
                }
                decoding="async"
              />
            </motion.picture>

            {/* IMAGE OVERLAYS */}
            <div className="absolute inset-0 bg-black/20" />

            <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/40 to-transparent" />

            <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-black/15" />

            <div className="absolute inset-0 bg-gradient-to-b from-black/25 via-transparent to-transparent" />

            {/* SOFT LIGHT */}
            <motion.div
              className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-white/[0.08] blur-[100px]"
              animate={{
                x: [0, 40, 0],
                y: [0, 25, 0],
              }}
              transition={{
                duration: 9,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
            />

            <motion.div
              className="pointer-events-none absolute -bottom-32 -right-24 h-96 w-96 rounded-full bg-white/[0.06] blur-[120px]"
              animate={{
                x: [0, -30, 0],
                y: [0, -25, 0],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
            />

            {/* CONTENT */}
            <div className="relative z-10 flex min-h-[68svh] items-end sm:min-h-[72svh] md:min-h-[76svh] lg:min-h-[80svh] xl:min-h-[84svh]">
              <div className="mx-auto w-full max-w-7xl px-5 pb-28 sm:px-8 sm:pb-32 lg:px-12 lg:pb-36 xl:px-16">

                <div className="max-w-4xl">

                  {/* SUBTITLE */}
                  {slide.subtitle && (
                    <motion.div
                      initial={{
                        opacity: 0,
                        y: 18,
                      }}
                      animate={{
                        opacity: 1,
                        y: 0,
                      }}
                      transition={{
                        delay: 0.15,
                        duration: 0.55,
                      }}
                      className="mb-5"
                    >
                      <div className="inline-flex max-w-full items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3.5 py-2 backdrop-blur-xl sm:px-4">
                        <Sparkles
                          size={13}
                          className="shrink-0"
                        />

                        <span className="truncate text-[9px] font-bold uppercase tracking-[0.2em] text-white/90 sm:text-[10px] md:text-xs">
                          {slide.subtitle}
                        </span>
                      </div>
                    </motion.div>
                  )}

                  {/* TITLE */}
                  <motion.h1
                    initial={{
                      opacity: 0,
                      y: 35,
                      filter: 'blur(8px)',
                    }}
                    animate={{
                      opacity: 1,
                      y: 0,
                      filter: 'blur(0px)',
                    }}
                    transition={{
                      delay: 0.25,
                      duration: 0.75,
                      ease: [0.22, 1, 0.36, 1],
                    }}
                    className="max-w-4xl font-[family-name:var(--font-syne)] text-[clamp(3rem,10vw,8rem)] font-black uppercase leading-[0.84] tracking-[-0.065em]"
                  >
                    {slide.title}
                  </motion.h1>

                  {/* DESCRIPTION */}
                  {slide.description && (
                    <motion.p
                      initial={{
                        opacity: 0,
                        y: 20,
                      }}
                      animate={{
                        opacity: 1,
                        y: 0,
                      }}
                      transition={{
                        delay: 0.42,
                        duration: 0.6,
                      }}
                      className="mt-6 max-w-xl text-xs font-medium leading-relaxed text-white/70 sm:text-sm md:text-base lg:text-lg"
                    >
                      {slide.description}
                    </motion.p>
                  )}

                  {/* BUTTONS */}
                  <motion.div
                    initial={{
                      opacity: 0,
                      y: 20,
                    }}
                    animate={{
                      opacity: 1,
                      y: 0,
                    }}
                    transition={{
                      delay: 0.55,
                      duration: 0.6,
                    }}
                    className="mt-7 flex flex-wrap gap-3 sm:mt-9"
                  >
                    <Link
                      href={
                        slide.button_url ||
                        '/shop'
                      }
                      className="group inline-flex h-12 items-center justify-center gap-3 rounded-full bg-white px-5 text-[10px] font-extrabold uppercase tracking-wide text-black shadow-2xl shadow-black/20 transition-all duration-300 hover:-translate-y-1 hover:bg-neutral-100 active:scale-95 sm:h-14 sm:px-7 sm:text-xs"
                    >
                      <span>
                        {slide.button_text ||
                          'Shop Collection'}
                      </span>

                      <span className="flex h-7 w-7 items-center justify-center rounded-full bg-black text-white transition-transform duration-300 group-hover:translate-x-1">
                        <ArrowRight size={14} />
                      </span>
                    </Link>

                    <Link
                      href="/shop"
                      className="inline-flex h-12 items-center justify-center rounded-full border border-white/25 bg-white/10 px-5 text-[10px] font-bold uppercase tracking-wide text-white backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:bg-white/20 sm:h-14 sm:px-7 sm:text-xs"
                    >
                      Explore
                    </Link>
                  </motion.div>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* COUNTER */}
        {validSlides.length > 1 && (
          <div className="absolute right-5 top-6 z-30 sm:right-8 sm:top-8 lg:right-12 lg:top-10">
            <div className="flex items-center gap-2 text-white">
              <span className="font-mono text-xs font-bold sm:text-sm">
                {String(current + 1).padStart(2, '0')}
              </span>

              <span className="h-px w-6 bg-white/40 sm:w-10" />

              <span className="font-mono text-[10px] text-white/45 sm:text-xs">
                {String(validSlides.length).padStart(2, '0')}
              </span>
            </div>
          </div>
        )}

        {/* CONTROLS */}
        {validSlides.length > 1 && (
          <div className="absolute bottom-6 right-5 z-30 flex gap-2 sm:bottom-8 sm:right-8 lg:right-12">
            <button
              type="button"
              onClick={previousSlide}
              aria-label="Previous slide"
              className="group flex h-10 w-10 items-center justify-center rounded-full border border-white/20 bg-black/20 text-white backdrop-blur-xl transition-all duration-300 hover:bg-white hover:text-black active:scale-90 sm:h-11 sm:w-11"
            >
              <ChevronLeft
                size={17}
                className="transition-transform duration-300 group-hover:-translate-x-0.5"
              />
            </button>

            <button
              type="button"
              onClick={nextSlide}
              aria-label="Next slide"
              className="group flex h-10 w-10 items-center justify-center rounded-full border border-white/20 bg-black/20 text-white backdrop-blur-xl transition-all duration-300 hover:bg-white hover:text-black active:scale-90 sm:h-11 sm:w-11"
            >
              <ChevronRight
                size={17}
                className="transition-transform duration-300 group-hover:translate-x-0.5"
              />
            </button>
          </div>
        )}

        {/* PROGRESS */}
        {validSlides.length > 1 && (
          <div className="absolute bottom-7 left-5 z-30 w-[40%] max-w-[360px] sm:bottom-9 sm:left-8 sm:w-[45%] lg:left-12">
            <div className="flex gap-1.5">
              {validSlides.map((item, index) => (
                <button
                  key={item.id || index}
                  type="button"
                  onClick={() => goToSlide(index)}
                  aria-label={`Go to slide ${index + 1}`}
                  className="h-1 flex-1 overflow-hidden rounded-full bg-white/20"
                >
                  <motion.div
                    className="h-full rounded-full bg-white"
                    initial={{
                      width:
                        index === current
                          ? '0%'
                          : index < current
                            ? '100%'
                            : '0%',
                    }}
                    animate={{
                      width:
                        index === current
                          ? '100%'
                          : index < current
                            ? '100%'
                            : '0%',
                    }}
                    transition={{
                      duration:
                        index === current
                          ? AUTOPLAY_TIME / 1000
                          : 0.25,
                      ease: 'linear',
                    }}
                  />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* SCROLL */}
        <motion.div
          animate={{
            y: [0, 6, 0],
            opacity: [0.4, 0.9, 0.4],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="absolute bottom-7 left-1/2 z-20 hidden -translate-x-1/2 flex-col items-center gap-2 text-white/50 md:flex"
        >
          <span className="text-[8px] font-bold uppercase tracking-[0.3em]">
            Scroll
          </span>

          <div className="h-6 w-px bg-white/30" />
        </motion.div>
      </div>
    </section>
  )
}