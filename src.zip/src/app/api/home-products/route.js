import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET() {
  try {
    const supabase = await createClient()

    const baseSelect = `
      id,
      name,
      slug,
      base_price,
      compare_price,
      badge,
      gender,
      status,
      is_active,
      is_trending,
      product_images (
        image_url,
        sort_order,
        is_primary
      )
    `

    const getProducts = async ({
      gender = null,
      trending = false,
    }) => {
      let query = supabase
        .from('products')
        .select(baseSelect)
        .eq('is_active', true)
        .eq('status', 'ACTIVE')
        .limit(SECTION_LIMIT)

      if (gender) {
        query = query.eq(
          'gender',
          gender
        )
      }

      if (trending) {
        query = query.eq(
          'is_trending',
          true
        )
      }

      query = query.order(
        'created_at',
        {
          ascending: false,
        }
      )

      const { data, error } = await query

      if (error) {
        throw error
      }

      return (data || []).map((product) => ({
        ...product,
        product_images: [
          ...(product.product_images || []),
        ].sort((a, b) => {
          if (
            a.is_primary &&
            !b.is_primary
          ) {
            return -1
          }

          if (
            !a.is_primary &&
            b.is_primary
          ) {
            return 1
          }

          return (
            (a.sort_order ?? 0) -
            (b.sort_order ?? 0)
          )
        }),
      }))
    }

    const [
      trending,
      men,
      women,
      kids,
    ] = await Promise.all([
      getProducts({
        trending: true,
      }),

      getProducts({
        gender: 'MEN',
      }),

      getProducts({
        gender: 'WOMEN',
      }),

      getProducts({
        gender: 'KIDS',
      }),
    ])

    return NextResponse.json({
      trending,
      men,
      women,
      kids,
    })
  } catch (error) {
    console.error(
      'Homepage products API error:',
      error
    )

    return NextResponse.json(
      {
        trending: [],
        men: [],
        women: [],
        kids: [],
        error:
          'Unable to load products',
      },
      {
        status: 500,
      }
    )
  }
}