'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import {
  ChevronLeft,
  CreditCard,
  MapPin,
  User,
  Check,
  ShoppingBag,
  ShieldCheck,
  ArrowRight,
  Package,
  Loader2,
  AlertCircle,
} from 'lucide-react'

import { useCartStore } from '@/store/cartStore'
import { createClient } from '@/lib/supabase/client'

export default function CheckoutPage() {
  const supabase = createClient()

  const [isMounted, setIsMounted] = useState(false)
  const [step, setStep] = useState(1)
  const [isProcessing, setIsProcessing] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState('')

  const [finalOrderDetails, setFinalOrderDetails] = useState(null)

  const {
    cartItems,
    getCartTotal,
    clearCart,
  } = useCartStore()

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    apartment: '',
    city: '',
    state: '',
    zip: '',
  })

  /*
  |--------------------------------------------------------------------------
  | Mount + Load Logged In User
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    let mounted = true

    async function loadUser() {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()

        if (!mounted) return

        if (!user) {
          setError('Please sign in before placing an order.')
          return
        }

        const { data: profile } = await supabase
          .from('profiles')
          .select('full_name, phone')
          .eq('id', user.id)
          .maybeSingle()

        const fullName = profile?.full_name || ''

        const nameParts = fullName.trim().split(' ')

        setFormData((prev) => ({
          ...prev,
          firstName: nameParts[0] || '',
          lastName: nameParts.slice(1).join(' ') || '',
          email: user.email || '',
          phone: profile?.phone || '',
        }))
      } catch (err) {
        console.error('User loading error:', err)
        setError('Unable to load your account information.')
      } finally {
        if (mounted) {
          setIsMounted(true)
        }
      }
    }

    loadUser()

    return () => {
      mounted = false
    }
  }, [])

  /*
  |--------------------------------------------------------------------------
  | Input Handler
  |--------------------------------------------------------------------------
  */

  const handleInputChange = (e) => {
    const { name, value } = e.target

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))

    if (error) {
      setError('')
    }
  }

  /*
  |--------------------------------------------------------------------------
  | Generate Order Number
  |--------------------------------------------------------------------------
  */

  const generateOrderNumber = () => {
    const timestamp = Date.now().toString().slice(-8)

    const random = Math.floor(
      1000 + Math.random() * 9000
    )

    return `RADHA-${timestamp}-${random}`
  }

  /*
  |--------------------------------------------------------------------------
  | Validate Shipping
  |--------------------------------------------------------------------------
  */

  const validateShipping = () => {
    const requiredFields = [
      'firstName',
      'lastName',
      'email',
      'phone',
      'address',
      'city',
      'state',
      'zip',
    ]

    for (const field of requiredFields) {
      if (!formData[field]?.trim()) {
        setError(
          `Please enter your ${field
            .replace(/([A-Z])/g, ' $1')
            .toLowerCase()}.`
        )

        return false
      }
    }

    if (!/^\d{6}$/.test(formData.zip.trim())) {
      setError('Please enter a valid 6-digit PIN code.')
      return false
    }

    return true
  }

  /*
  |--------------------------------------------------------------------------
  | Next Step
  |--------------------------------------------------------------------------
  */

  const handleNextStep = (e) => {
    e.preventDefault()

    setError('')

    if (step === 1) {
      if (!validateShipping()) return
    }

    setStep((prev) => Math.min(prev + 1, 3))

    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    })
  }

  /*
  |--------------------------------------------------------------------------
  | Previous Step
  |--------------------------------------------------------------------------
  */

  const handlePrevStep = () => {
    setError('')

    setStep((prev) => Math.max(prev - 1, 1))

    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    })
  }

  /*
  |--------------------------------------------------------------------------
  | CREATE ORDER
  |--------------------------------------------------------------------------
  */

  const handlePlaceOrder = async (e) => {
    e.preventDefault()

    if (isProcessing) return

    setError('')
    setIsProcessing(true)

    try {
      /*
      |--------------------------------------------------------------------------
      | 1. Check Authentication
      |--------------------------------------------------------------------------
      */

      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser()

      if (authError) {
        throw new Error(authError.message)
      }

      if (!user) {
        throw new Error(
          'Your session has expired. Please sign in again.'
        )
      }

      /*
      |--------------------------------------------------------------------------
      | 2. Check Cart
      |--------------------------------------------------------------------------
      */

      if (!cartItems || cartItems.length === 0) {
        throw new Error('Your cart is empty.')
      }

      /*
      |--------------------------------------------------------------------------
      | 3. Calculate Total
      |--------------------------------------------------------------------------
      */

      const subtotal = Number(getCartTotal()) || 0

      /*
      |--------------------------------------------------------------------------
      | 4. Shipping
      |--------------------------------------------------------------------------
      */

      const shippingAmount = 0

      const discountAmount = 0

      const totalAmount =
        subtotal -
        discountAmount +
        shippingAmount

      /*
      |--------------------------------------------------------------------------
      | 5. Generate Order Number
      |--------------------------------------------------------------------------
      */

      const orderNumber = generateOrderNumber()

      /*
      |--------------------------------------------------------------------------
      | 6. Build Shipping Address
      |--------------------------------------------------------------------------
      */

      const fullShippingAddress = [
        formData.address,
        formData.apartment,
      ]
        .filter(Boolean)
        .join(', ')

      /*
      |--------------------------------------------------------------------------
      | 7. Create Order
      |--------------------------------------------------------------------------
      */

      const { data: order, error: orderError } =
        await supabase
          .from('orders')
          .insert({
            order_number: orderNumber,

            user_id: user.id,

            status: 'PENDING',

            payment_method: 'COD',

            payment_status: 'PENDING',

            subtotal,

            discount_amount: discountAmount,

            shipping_amount: shippingAmount,

            total_amount: totalAmount,

            coupon_code: null,

            notes: null,

            shipping_name:
              `${formData.firstName} ${formData.lastName}`.trim(),

            shipping_phone: formData.phone,

            shipping_address:
              fullShippingAddress,

            shipping_city: formData.city,

            shipping_state: formData.state,

            shipping_postal_code: formData.zip,

            shipping_country: 'India',
          })
          .select('id, order_number, total_amount')
          .single()

      if (orderError) {
        console.error('ORDER INSERT ERROR:', orderError)

        throw new Error(
          orderError.message ||
            'Failed to create order.'
        )
      }

      /*
      |--------------------------------------------------------------------------
      | 8. Create Order Items
      |--------------------------------------------------------------------------
      */

      const orderItems = cartItems.map((item) => ({
        order_id: order.id,

        product_id:
          item.product_id ||
          item.productId ||
          item.id ||
          null,

        variant_id:
          item.variant_id ||
          item.variantId ||
          null,

        product_name:
          item.name ||
          item.product_name ||
          'Product',

        product_image:
          item.image ||
          item.product_image ||
          null,

        size:
          item.size ||
          null,

        color:
          item.color ||
          null,

        quantity:
          Number(item.quantity) || 1,

        unit_price:
          Number(item.price) || 0,

        total_price:
          (Number(item.price) || 0) *
          (Number(item.quantity) || 1),
      }))

      /*
      |--------------------------------------------------------------------------
      | 9. Insert Order Items
      |--------------------------------------------------------------------------
      */

      const {
        error: itemsError,
      } = await supabase
        .from('order_items')
        .insert(orderItems)

      if (itemsError) {
        console.error(
          'ORDER ITEMS INSERT ERROR:',
          itemsError
        )

        /*
        |--------------------------------------------------------------------------
        | IMPORTANT:
        | If order_items fails, delete the parent order
        |--------------------------------------------------------------------------
        */

        await supabase
          .from('orders')
          .delete()
          .eq('id', order.id)

        throw new Error(
          itemsError.message ||
            'Failed to create order items.'
        )
      }

      /*
      |--------------------------------------------------------------------------
      | 10. Save Address
      |--------------------------------------------------------------------------
      |
      | This is optional but useful because your database has
      | an addresses table.
      |
      */

      const {
        data: existingAddress,
        error: addressLookupError,
      } = await supabase
        .from('addresses')
        .select('id')
        .eq('user_id', user.id)
        .eq('full_name', `${formData.firstName} ${formData.lastName}`.trim())
        .eq('phone', formData.phone)
        .eq('address_line1', formData.address)
        .eq('city', formData.city)
        .eq('state', formData.state)
        .eq('postal_code', formData.zip)
        .maybeSingle()

      if (addressLookupError) {
        console.warn(
          'Address lookup warning:',
          addressLookupError.message
        )
      }

      /*
      |--------------------------------------------------------------------------
      | Insert Address Only If It Doesn't Exist
      |--------------------------------------------------------------------------
      */

      if (!existingAddress) {
        const { error: addressInsertError } =
          await supabase
            .from('addresses')
            .insert({
              user_id: user.id,

              full_name:
                `${formData.firstName} ${formData.lastName}`.trim(),

              phone: formData.phone,

              address_line1: formData.address,

              address_line2:
                formData.apartment || null,

              city: formData.city,

              state: formData.state,

              postal_code: formData.zip,

              country: 'India',

              is_default: false,
            })

        if (addressInsertError) {
          /*
          |--------------------------------------------------------------------------
          | Address failure should NOT cancel the order.
          |--------------------------------------------------------------------------
          */

          console.warn(
            'Address save warning:',
            addressInsertError.message
          )
        }
      }

      /*
      |--------------------------------------------------------------------------
      | 11. SUCCESS
      |--------------------------------------------------------------------------
      */

      setFinalOrderDetails({
        orderNumber:
          order.order_number,

        total:
          Number(order.total_amount),

        email:
          formData.email,

        name:
          formData.firstName,

        orderId:
          order.id,
      })

      /*
      |--------------------------------------------------------------------------
      | 12. Clear Cart
      |--------------------------------------------------------------------------
      */

      clearCart()

      setIsProcessing(false)

      setIsSuccess(true)

      window.scrollTo({
        top: 0,
        behavior: 'smooth',
      })
    } catch (err) {
      console.error(
        'PLACE ORDER ERROR:',
        err
      )

      setError(
        err?.message ||
          'Something went wrong while placing your order.'
      )

      setIsProcessing(false)
    }
  }

  /*
  |--------------------------------------------------------------------------
  | Loading
  |--------------------------------------------------------------------------
  */

  if (!isMounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-neutral-50">
        <Loader2
          size={32}
          className="animate-spin text-black"
        />
      </div>
    )
  }

  /*
  |--------------------------------------------------------------------------
  | SUCCESS RECEIPT
  |--------------------------------------------------------------------------
  */

  if (
    isSuccess &&
    finalOrderDetails
  ) {
    return (
      <div className="min-h-[100dvh] pt-24 pb-12 md:pt-32 md:pb-24 flex items-center justify-center px-4 sm:px-6 bg-neutral-100/50">
        <div className="w-full max-w-lg bg-white p-6 sm:p-8 md:p-10 rounded-3xl md:rounded-[2rem] shadow-2xl border border-neutral-100 text-center relative overflow-hidden animate-in fade-in slide-in-from-bottom-8 duration-700">

          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 bg-green-400/10 blur-[60px] rounded-full pointer-events-none" />

          <div className="relative w-20 h-20 md:w-24 md:h-24 mx-auto mb-6">

            <div className="absolute inset-0 bg-green-500 rounded-full animate-ping opacity-20" />

            <div className="absolute inset-0 bg-black rounded-full flex items-center justify-center shadow-xl z-10">

              <Check
                size={40}
                className="text-white"
                strokeWidth={3.5}
              />

            </div>

          </div>

          <h1 className="font-[family-name:var(--font-syne)] text-3xl md:text-4xl font-extrabold tracking-tight mb-3">
            Order Confirmed
          </h1>

          <p className="text-neutral-500 text-sm md:text-base mb-8 leading-relaxed">
            Thank you, {finalOrderDetails.name}.
            We've received your order and are
            getting it ready.
          </p>

          <div className="bg-neutral-50 rounded-2xl p-6 text-left mb-8 border border-neutral-200/60">

            <div className="border-b-2 border-dashed border-neutral-200 pb-5 mb-5">

              <p className="text-xs text-neutral-400 font-bold uppercase tracking-widest mb-1">
                Order Number
              </p>

              <p className="font-mono font-extrabold text-xl md:text-2xl text-black tracking-wider break-all">
                #{finalOrderDetails.orderNumber}
              </p>

            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">

              <div>
                <p className="text-xs text-neutral-400 font-bold uppercase tracking-widest mb-1">
                  Total Amount
                </p>

                <p className="font-bold text-lg">
                  ₹{finalOrderDetails.total}
                </p>
              </div>

              <div className="sm:text-right">

                <p className="text-xs text-neutral-400 font-bold uppercase tracking-widest mb-1">
                  Payment
                </p>

                <p className="font-semibold text-sm">
                  Cash on Delivery
                </p>

              </div>

            </div>

          </div>

          <div className="flex flex-col sm:flex-row gap-3">

            <Link
              href="/account/orders"
              className="flex-1 h-13 flex items-center justify-center gap-2 border-2 border-neutral-200 rounded-xl font-bold hover:border-black transition-all"
            >
              <Package size={18} />
              My Orders
            </Link>

            <Link
              href="/shop"
              className="flex-1 h-13 flex items-center justify-center gap-2 bg-black text-white rounded-xl font-bold hover:bg-neutral-800 transition-all group"
            >
              Shop More
              <ArrowRight
                size={18}
                className="group-hover:translate-x-1 transition-transform"
              />
            </Link>

          </div>

        </div>
      </div>
    )
  }

  /*
  |--------------------------------------------------------------------------
  | EMPTY CART
  |--------------------------------------------------------------------------
  */

  if (!cartItems || cartItems.length === 0) {
    return (
      <div className="min-h-[100dvh] pt-24 pb-12 flex flex-col items-center justify-center px-6 text-center">

        <ShoppingBag
          size={64}
          className="text-neutral-200 mb-5"
        />

        <h1 className="font-[family-name:var(--font-syne)] text-3xl font-bold mb-4">
          Your cart is empty
        </h1>

        <p className="text-neutral-500 text-sm mb-8 max-w-sm">
          Looks like you haven't added anything
          to your cart yet.
        </p>

        <Link
          href="/shop"
          className="h-14 flex items-center justify-center bg-black text-white px-8 rounded-full font-medium hover:bg-neutral-800 transition-colors"
        >
          Explore Collection
        </Link>

      </div>
    )
  }

  /*
  |--------------------------------------------------------------------------
  | CHECKOUT
  |--------------------------------------------------------------------------
  */

  return (
    <div className="min-h-[100dvh] pt-24 pb-16 md:pt-32 md:pb-24 bg-neutral-50/30">

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* HEADER */}

        <div className="mb-8 md:mb-10">

          <Link
            href="/cart"
            onClick={(e) => {

              if (step > 1) {
                e.preventDefault()
                handlePrevStep()
              }

            }}
            className="inline-flex items-center text-sm font-semibold text-neutral-400 hover:text-black mb-4 transition-colors"
          >
            <ChevronLeft
              size={16}
              className="mr-1"
            />

            {step > 1
              ? 'Back to previous step'
              : 'Back to Cart'}
          </Link>

          <h1 className="font-[family-name:var(--font-syne)] text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
            Checkout
          </h1>

        </div>

        {/* ERROR */}

        {error && (
          <div className="mb-6 max-w-3xl">

            <div className="flex items-start gap-3 bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4">

              <AlertCircle
                size={20}
                className="shrink-0 mt-0.5"
              />

              <div>
                <p className="font-bold text-sm">
                  Order Error
                </p>

                <p className="text-sm mt-1">
                  {error}
                </p>
              </div>

            </div>

          </div>
        )}

        <div className="flex flex-col lg:flex-row gap-8 lg:gap-12 xl:gap-20">

          {/* LEFT */}

          <div className="flex-1 w-full max-w-3xl mx-auto lg:mx-0">

            {/* STEPS */}

            <div className="flex justify-between relative mb-10 px-2 sm:px-6">

              <div className="absolute top-6 left-[15%] right-[15%] h-1 bg-neutral-200 rounded-full -z-10" />

              <div
                className="absolute top-6 left-[15%] right-[15%] h-1 bg-black rounded-full -z-10 transition-all duration-500 origin-left"
                style={{
                  transform: `scaleX(${
                    step === 1
                      ? 0
                      : step === 2
                      ? 0.5
                      : 1
                  })`,
                }}
              />

              {[
                {
                  num: 1,
                  label: 'Shipping',
                  icon: MapPin,
                },
                {
                  num: 2,
                  label: 'Payment',
                  icon: CreditCard,
                },
                {
                  num: 3,
                  label: 'Review',
                  icon: Check,
                },
              ].map((s) => {

                const Icon = s.icon

                return (
                  <div
                    key={s.num}
                    className="flex flex-col items-center gap-2 bg-neutral-50/50"
                  >

                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center font-bold transition-all duration-300 ${
                        step >= s.num
                          ? 'bg-black text-white shadow-lg shadow-black/20 scale-105'
                          : 'bg-white border-2 border-neutral-200 text-neutral-400'
                      }`}
                    >

                      {step > s.num ? (
                        <Check
                          size={18}
                          strokeWidth={3}
                        />
                      ) : (
                        <Icon size={18} />
                      )}

                    </div>

                    <span
                      className={`text-[10px] md:text-xs font-bold uppercase tracking-wider ${
                        step >= s.num
                          ? 'text-black'
                          : 'text-neutral-400'
                      }`}
                    >
                      {s.label}
                    </span>

                  </div>
                )
              })}

            </div>

            {/* FORM */}

            <form
              onSubmit={
                step === 3
                  ? handlePlaceOrder
                  : handleNextStep
              }
              className="bg-white p-5 sm:p-8 md:p-10 rounded-2xl md:rounded-[2rem] border border-neutral-100 shadow-xl shadow-black/[0.02]"
            >

              {/* =========================================================
                  STEP 1
              ========================================================== */}

              {step === 1 && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-3">

                    <h2 className="text-xl md:text-2xl font-bold tracking-tight">
                      Shipping Details
                    </h2>

                    <div className="inline-flex items-center text-xs font-medium text-green-600 bg-green-50 px-3 py-1.5 rounded-full">

                      <User
                        size={14}
                        className="mr-1.5"
                      />

                      Logged In

                    </div>

                  </div>

                  <div className="space-y-5">

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">

                      <Input
                        label="First Name"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        required
                      />

                      <Input
                        label="Last Name"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        required
                      />

                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">

                      <Input
                        label="Email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                      />

                      <Input
                        label="Phone"
                        name="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={handleInputChange}
                        required
                      />

                    </div>

                    <Input
                      label="Street Address"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      required
                    />

                    <Input
                      label="Apartment / Landmark"
                      name="apartment"
                      value={formData.apartment}
                      onChange={handleInputChange}
                    />

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">

                      <Input
                        label="PIN Code"
                        name="zip"
                        value={formData.zip}
                        onChange={handleInputChange}
                        required
                      />

                      <Input
                        label="City"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        required
                      />

                      <Input
                        label="State"
                        name="state"
                        value={formData.state}
                        onChange={handleInputChange}
                        required
                      />

                    </div>

                    <button
                      type="submit"
                      className="w-full h-14 mt-6 bg-black text-white rounded-2xl font-bold hover:bg-neutral-800 transition-all active:scale-[0.99] flex items-center justify-center"
                    >
                      Continue to Payment
                    </button>

                  </div>

                </div>
              )}

              {/* =========================================================
                  STEP 2
              ========================================================== */}

              {step === 2 && (
                <div className="animate-in fade-in slide-in-from-right-8 duration-500">

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-3">

                    <h2 className="text-xl md:text-2xl font-bold tracking-tight">
                      Payment Method
                    </h2>

                    <div className="inline-flex items-center text-xs font-medium text-neutral-500 bg-neutral-100 px-3 py-1.5 rounded-full">

                      <ShieldCheck
                        size={14}
                        className="mr-1.5"
                      />

                      Secure Checkout

                    </div>

                  </div>

                  <div className="border-2 border-black rounded-2xl p-5 bg-neutral-50 mb-8">

                    <div className="flex items-center gap-4">

                      <div className="w-12 h-12 bg-black text-white rounded-xl flex items-center justify-center">

                        <Package size={22} />

                      </div>

                      <div>

                        <h3 className="font-bold">
                          Cash on Delivery
                        </h3>

                        <p className="text-sm text-neutral-500">
                          Pay when your order arrives
                        </p>

                      </div>

                    </div>

                  </div>

                  <div className="bg-neutral-50 border border-neutral-200 rounded-2xl p-5 mb-8">

                    <p className="text-sm text-neutral-600 leading-relaxed">
                      Your order will be placed using
                      <strong className="text-black">
                        {' '}Cash on Delivery
                      </strong>
                      . No card information is
                      required.
                    </p>

                  </div>

                  <button
                    type="submit"
                    className="w-full h-14 bg-black text-white rounded-2xl font-bold hover:bg-neutral-800 transition-all flex items-center justify-center"
                  >
                    Review Order
                  </button>

                </div>
              )}

              {/* =========================================================
                  STEP 3
              ========================================================== */}

              {step === 3 && (
                <div className="animate-in fade-in slide-in-from-right-8 duration-500">

                  <h2 className="text-xl md:text-2xl font-bold tracking-tight mb-8">
                    Final Review
                  </h2>

                  <div className="space-y-5 mb-8">

                    {/* SHIPPING */}

                    <div className="p-5 border-2 border-neutral-100 rounded-2xl bg-neutral-50 flex justify-between items-start gap-4">

                      <div>

                        <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-2">
                          Shipping To
                        </h3>

                        <p className="font-semibold">
                          {formData.firstName}{' '}
                          {formData.lastName}
                        </p>

                        <p className="text-sm text-neutral-600 mt-1">
                          {formData.address}
                        </p>

                        {formData.apartment && (
                          <p className="text-sm text-neutral-600">
                            {formData.apartment}
                          </p>
                        )}

                        <p className="text-sm text-neutral-600">
                          {formData.city},{' '}
                          {formData.state}{' '}
                          {formData.zip}
                        </p>

                        <p className="text-sm text-neutral-600 mt-1">
                          {formData.phone}
                        </p>

                      </div>

                      <button
                        type="button"
                        onClick={() => setStep(1)}
                        className="text-xs font-bold underline underline-offset-4"
                      >
                        Edit
                      </button>

                    </div>

                    {/* PAYMENT */}

                    <div className="p-5 border-2 border-neutral-100 rounded-2xl bg-neutral-50 flex justify-between items-start">

                      <div>

                        <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-2">
                          Payment Method
                        </h3>

                        <p className="font-semibold flex items-center gap-2">

                          <Package size={18} />

                          Cash on Delivery

                        </p>

                      </div>

                      <button
                        type="button"
                        onClick={() => setStep(2)}
                        className="text-xs font-bold underline underline-offset-4"
                      >
                        Edit
                      </button>

                    </div>

                  </div>

                  <button
                    type="submit"
                    disabled={isProcessing}
                    className="w-full h-14 md:h-16 bg-black text-white rounded-2xl font-bold hover:bg-neutral-800 transition-all disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >

                    {isProcessing ? (
                      <>
                        <Loader2
                          size={20}
                          className="animate-spin"
                        />

                        Creating Order...
                      </>
                    ) : (
                      <>
                        Place Order · ₹
                        {getCartTotal()}
                        <ArrowRight size={18} />
                      </>
                    )}

                  </button>

                </div>
              )}

            </form>

          </div>

          {/* =============================================================
              ORDER SUMMARY
          ============================================================= */}

          <div className="w-full lg:w-[380px] order-first lg:order-last">

            <div className="bg-white border border-neutral-100 rounded-2xl md:rounded-[2rem] p-5 md:p-8 lg:sticky lg:top-32 shadow-xl shadow-black/[0.02]">

              <h2 className="text-xl font-bold tracking-tight mb-6">
                Order Summary
              </h2>

              <div className="space-y-5 mb-6 max-h-[40vh] overflow-y-auto pr-2">

                {cartItems.map((item) => (

                  <div
                    key={`${item.id}-${item.size}-${item.color}`}
                    className="flex gap-4"
                  >

                    <div className="w-20 h-24 bg-neutral-100 rounded-xl overflow-hidden shrink-0">

                      <img
                        src={
                          item.image ||
                          item.product_image
                        }
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />

                    </div>

                    <div className="flex-1 flex flex-col justify-center">

                      <h3 className="font-bold text-sm line-clamp-1">
                        {item.name}
                      </h3>

                      <p className="text-[10px] font-semibold text-neutral-400 mt-1 uppercase tracking-wider">
                        {item.color || 'Default'}
                        {' / '}
                        {item.size || 'One Size'}
                      </p>

                      <div className="flex items-center justify-between mt-2">

                        <span className="text-[10px] font-bold text-neutral-400 bg-neutral-100 px-2 py-1 rounded-md">
                          Qty {item.quantity}
                        </span>

                        <span className="font-bold text-sm">
                          ₹
                          {Number(item.price) *
                            Number(item.quantity)}
                        </span>

                      </div>

                    </div>

                  </div>

                ))}

              </div>

              <div className="border-t-2 border-neutral-100 pt-6 space-y-4">

                <div className="flex justify-between text-sm font-semibold text-neutral-500">

                  <span>
                    Subtotal
                  </span>

                  <span className="text-black">
                    ₹{getCartTotal()}
                  </span>

                </div>

                <div className="flex justify-between text-sm font-semibold text-neutral-500">

                  <span>
                    Shipping
                  </span>

                  <span className="text-green-600 uppercase tracking-widest text-xs">
                    Free
                  </span>

                </div>

                <div className="border-t-2 border-dashed border-neutral-200 pt-5 flex justify-between items-end">

                  <span className="font-extrabold">
                    Total
                  </span>

                  <span className="font-[family-name:var(--font-syne)] font-bold text-3xl">
                    ₹{getCartTotal()}
                  </span>

                </div>

              </div>

            </div>

          </div>

        </div>

      </div>

    </div>
  )
}

/*
|--------------------------------------------------------------------------
| Reusable Input
|--------------------------------------------------------------------------
*/

function Input({
  label,
  name,
  type = 'text',
  value,
  onChange,
  required = false,
}) {
  return (
    <div>

      <label className="block text-xs font-bold text-neutral-500 uppercase tracking-wider mb-2 ml-1">
        {label}
      </label>

      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        required={required}
        className="w-full h-14 px-5 text-sm rounded-2xl border-2 border-neutral-100 bg-neutral-50 focus:bg-white focus:border-black focus:ring-0 outline-none transition-all font-medium text-black"
      />

    </div>
  )
}