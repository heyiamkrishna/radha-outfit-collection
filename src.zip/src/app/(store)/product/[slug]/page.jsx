'use client'

import { use, useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronRight, ChevronLeft, Minus, Plus, ShoppingBag, ShieldCheck, Truck, RotateCcw, Loader2, Share2, Zap } from 'lucide-react'
import { toast } from 'sonner'
import { createClient } from '@/lib/supabase/client'
import { useCartStore } from '@/store/cartStore'
import Navbar from '@/components/navbar/Navbar'

export default function ProductPage({ params }) {
  const { slug } = use(params)
  const router = useRouter()
  const { addToCart, setIsCartOpen } = useCartStore()
  const supabase = createClient()

  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)
  const [images, setImages] = useState([])
  
  // Slider State
  const [currentIndex, setCurrentIndex] = useState(0)
  const [direction, setDirection] = useState(0)
  
  const [selectedSize, setSelectedSize] = useState('')
  const [selectedColor, setSelectedColor] = useState('')
  const [quantity, setQuantity] = useState(1)

  // ================= FETCH REAL-TIME DATA =================
  useEffect(() => {
    async function fetchProduct() {
      setLoading(true)
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('slug', slug)
        .eq('is_active', true)
        .single()

      if (data) {
        setProduct(data)

        let parsedImages = []
        if (Array.isArray(data.images) && data.images.length > 0) {
          parsedImages = data.images.map(img => (typeof img === 'string' ? img : img?.url)).filter(Boolean)
        }
        if (parsedImages.length === 0 && data.image_url) parsedImages = [data.image_url]
        if (parsedImages.length === 0) parsedImages = ['https://placehold.co/600x800/f5f5f5/a3a3a3?text=No+Image']

        setImages(parsedImages)

        if (data.sizes?.length > 0) setSelectedSize(data.sizes[0])
        if (data.colors?.length > 0) setSelectedColor(data.colors[0])
      }
      setLoading(false)
    }
    fetchProduct()
  }, [slug])

  // ================= ERROR & LOADING STATES =================
  if (loading) return <div className="flex min-h-[70vh] w-full items-center justify-center bg-white"><Loader2 className="h-10 w-10 animate-spin text-neutral-300" /></div>
  if (!product) return (
    <div className="flex min-h-[70vh] w-full flex-col items-center justify-center bg-white px-4 text-center">
      <h1 className="text-3xl font-bold text-neutral-900">Product not found</h1>
      <Link href="/shop" className="mt-6 rounded-full bg-black px-8 py-3 text-sm font-semibold text-white">Back to Shop</Link>
    </div>
  )

  // ================= SAFE HANDLERS =================
  const isOutOfStock = product.stock <= 0

  const discountPercentage = product.compare_price > product.base_price 
    ? Math.round(((product.compare_price - product.base_price) / product.compare_price) * 100) 
    : 0

  const handleQuantity = (type) => {
    if (type === 'dec' && quantity > 1) setQuantity(prev => prev - 1)
    if (type === 'inc' && quantity < (product.stock || 10)) setQuantity(prev => prev + 1)
  }

  const validateSelection = () => {
    if (isOutOfStock) { toast.error('This product is out of stock.'); return false; }
    if (product.sizes?.length && !selectedSize) { toast.error('Please select a size.'); return false; }
    if (product.colors?.length && !selectedColor) { toast.error('Please select a color.'); return false; }
    return true;
  }

  // Real Add to Cart integration using your cart store
  const handleAddToCart = () => {
    if (!validateSelection()) return
    addToCart(product, selectedSize, selectedColor, quantity, product.base_price)
    toast.success(`Added ${quantity} ${product.name} to cart!`)
  }

  // Real Buy Now integration (adds to cart, closes drawer, redirects to checkout)
  const handleBuyNow = () => {
    if (!validateSelection()) return
    addToCart(product, selectedSize, selectedColor, quantity, product.base_price)
    setIsCartOpen(false)
    router.push('/checkout')
  }

  const handleShare = async () => {
    const shareData = {
      title: product.name,
      text: `Check out ${product.name} at Radha Outfit Collection!`,
      url: window.location.href
    }
    if (navigator.share) {
      try { await navigator.share(shareData) } catch (err) {}
    } else {
      navigator.clipboard.writeText(window.location.href)
      toast.success('Link copied to clipboard!')
    }
  }

  const paginate = (newDirection) => {
    setDirection(newDirection)
    setCurrentIndex((prev) => (prev + newDirection + images.length) % images.length)
  }

  // ================= ANIMATION VARIANTS =================
  const slideVariants = {
    enter: (direction) => ({ x: direction > 0 ? '100%' : '-100%', opacity: 0 }),
    center: { zIndex: 1, x: 0, opacity: 1 },
    exit: (direction) => ({ zIndex: 0, x: direction < 0 ? '100%' : '-100%', opacity: 0 })
  }
  const staggerContainer = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.1 } } }
  const fadeUp = { hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' } } }

  return (
    <main className="min-h-screen bg-white pb-32 pt-4 md:pb-24 md:pt-8">
      <div className="mx-auto max-w-6xl px-4 md:px-8">

        <div><Navbar/></div>
        
        {/* BREADCRUMBS & SHARE */}
        <motion.nav initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }} className="mb-6 flex items-center justify-between md:mb-8">
          <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-widest text-neutral-400">
            <Link href="/" className="hover:text-black transition-colors">Home</Link>
            <ChevronRight size={12} />
            <Link href="/shop" className="hover:text-black transition-colors">Shop</Link>
            <ChevronRight size={12} />
            <span className="truncate text-black">{product.gender || 'Collection'}</span>
          </div>
          <button onClick={handleShare} className="flex items-center gap-2 rounded-full bg-neutral-100 px-3 py-1.5 text-xs font-bold text-neutral-700 transition hover:bg-neutral-200">
            <Share2 size={14} /> Share
          </button>
        </motion.nav>

        {/* MAIN GRID */}
        <div className="grid gap-10 lg:grid-cols-[400px_1fr] lg:gap-14 xl:grid-cols-[460px_1fr]">
          
          {/* IMAGE GALLERY */}
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease: "easeOut" }} className="flex flex-col-reverse gap-3 md:flex-row md:gap-4 lg:sticky lg:top-28 lg:h-fit">
            
            <div className="flex gap-2 overflow-x-auto pb-2 hide-scrollbar md:w-16 md:flex-col md:pb-0 shrink-0">
              {images.map((img, idx) => (
                <button 
                  key={idx}
                  onClick={() => { setDirection(idx > currentIndex ? 1 : -1); setCurrentIndex(idx); }}
                  className={`relative aspect-[3/4] w-16 shrink-0 overflow-hidden rounded-xl border-2 transition-all duration-300 md:w-full ${currentIndex === idx ? 'border-black shadow-md' : 'border-transparent opacity-50 hover:opacity-100'}`}
                >
                  <img src={img} alt={`Thumbnail ${idx}`} className="h-full w-full object-cover" />
                </button>
              ))}
            </div>

            <div className="relative aspect-[3/4] w-full flex-1 overflow-hidden rounded-2xl bg-neutral-100 shadow-sm">
              <AnimatePresence initial={false} custom={direction}>
                <motion.img 
                  key={currentIndex}
                  custom={direction}
                  variants={slideVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{ x: { type: "spring", stiffness: 300, damping: 30 }, opacity: { duration: 0.2 } }}
                  drag="x"
                  dragConstraints={{ left: 0, right: 0 }}
                  dragElastic={1}
                  onDragEnd={(e, { offset, velocity }) => {
                    const swipe = Math.abs(offset.x) * velocity.x;
                    if (swipe < -10000) paginate(1);
                    else if (swipe > 10000) paginate(-1);
                  }}
                  src={images[currentIndex]} 
                  alt={product.name} 
                  className="absolute h-full w-full object-cover" 
                />
              </AnimatePresence>
              
              {images.length > 1 && (
                <>
                  <button onClick={() => paginate(-1)} className="absolute left-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-white/80 p-2 text-neutral-800 shadow-sm backdrop-blur-md transition-transform hover:scale-110 active:scale-95"><ChevronLeft size={18} /></button>
                  <button onClick={() => paginate(1)} className="absolute right-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-white/80 p-2 text-neutral-800 shadow-sm backdrop-blur-md transition-transform hover:scale-110 active:scale-95"><ChevronRight size={18} /></button>
                </>
              )}
            </div>
          </motion.div>

          {/* PRODUCT DETAILS */}
          <motion.div variants={staggerContainer} initial="hidden" animate="show" className="flex flex-col pt-2">
            
            <motion.h1 variants={fadeUp} className="text-3xl font-bold tracking-tight text-neutral-900 md:text-4xl font-[family-name:var(--font-syne)]">
              {product.name}
            </motion.h1>
            
            <motion.div variants={fadeUp} className="mt-4 flex items-end gap-3">
              <span className="text-3xl font-bold text-black">₹{product.base_price}</span>
              {discountPercentage > 0 && (
                <>
                  <span className="mb-1 text-lg font-medium text-neutral-400 line-through">₹{product.compare_price}</span>
                  <span className="mb-1 text-sm font-bold text-[#388e3c]">{discountPercentage}% OFF</span>
                </>
              )}
            </motion.div>

            <motion.p variants={fadeUp} className="mt-6 text-sm leading-relaxed text-neutral-600">
              {product.description || 'Premium quality apparel designed for maximum comfort and style.'}
            </motion.p>

            <motion.div variants={fadeUp} className="my-8 h-[1px] w-full bg-neutral-100" />

            {/* SIZES */}
            {product.sizes?.length > 0 && (
              <motion.div variants={fadeUp} className="mb-6">
                <div className="mb-3 flex justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900">Select Size</h3>
                  <button className="text-xs font-medium text-neutral-500 underline underline-offset-2">Size Guide</button>
                </div>
                <div className="flex flex-wrap gap-2 md:gap-3">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`flex h-12 min-w-[3.5rem] items-center justify-center rounded-xl border px-4 text-xs font-semibold transition-all duration-300 ${selectedSize === size ? 'border-black bg-black text-white shadow-md' : 'border-neutral-200 bg-white text-neutral-600 hover:border-black'}`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* COLORS */}
            {product.colors?.length > 0 && (
              <motion.div variants={fadeUp} className="mb-8">
                <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-neutral-900">Select Color</h3>
                <div className="flex flex-wrap gap-2 md:gap-3">
                  {product.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`flex h-12 items-center justify-center rounded-xl border px-5 text-xs font-semibold transition-all duration-300 ${selectedColor === color ? 'border-black bg-black text-white shadow-md' : 'border-neutral-200 bg-white text-neutral-600 hover:border-black'}`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* QUANTITY */}
            <motion.div variants={fadeUp} className="mb-8 hidden md:block">
               <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-neutral-900">Quantity</h3>
               <div className="flex h-12 w-32 items-center justify-between rounded-xl border border-neutral-200 bg-neutral-50 px-2">
                <button onClick={() => handleQuantity('dec')} className="flex h-8 w-8 items-center justify-center rounded-lg text-neutral-500 hover:bg-white hover:text-black hover:shadow-sm"><Minus size={16}/></button>
                <span className="w-8 text-center text-sm font-bold text-black">{quantity}</span>
                <button onClick={() => handleQuantity('inc')} className="flex h-8 w-8 items-center justify-center rounded-lg text-neutral-500 hover:bg-white hover:text-black hover:shadow-sm"><Plus size={16}/></button>
              </div>
            </motion.div>

            {/* INTEGRATED ADD TO CART & BUY NOW BUTTONS */}
            <motion.div variants={fadeUp} className="fixed bottom-0 left-0 z-40 flex w-full flex-row gap-3 border-t border-neutral-100 bg-white/90 px-4 py-4 backdrop-blur-xl md:relative md:border-none md:bg-transparent md:p-0">
              <button 
                onClick={handleAddToCart}
                disabled={isOutOfStock}
                className="flex h-14 flex-1 items-center justify-center gap-2 rounded-2xl border-2 border-neutral-200 bg-white px-2 text-sm font-bold text-neutral-800 transition-all active:scale-[0.98] hover:border-black disabled:opacity-50"
              >
                <ShoppingBag size={18} /> <span className="hidden sm:inline">Add to Cart</span>
              </button>
              
              <button 
                onClick={handleBuyNow}
                disabled={isOutOfStock}
                className="group relative flex h-14 flex-[2] items-center justify-center gap-2 overflow-hidden rounded-2xl bg-black px-4 text-sm font-bold text-white transition-all active:scale-[0.98] disabled:opacity-50"
              >
                <div className="absolute inset-0 flex h-full w-full justify-center [transform:skew(-12deg)_translateX(-150%)] group-hover:duration-1000 group-hover:[transform:skew(-12deg)_translateX(150%)]">
                  <div className="relative h-full w-8 bg-white/20" />
                </div>
                {isOutOfStock ? 'Out of Stock' : <><Zap size={18} className="fill-white" /> Buy It Now</>}
              </button>
            </motion.div>

            {/* VALUE PROPS */}
            <motion.div variants={fadeUp} className="mt-8 grid grid-cols-3 gap-4 rounded-3xl bg-neutral-50 p-6 shadow-inner">
              <div className="flex flex-col items-center text-center gap-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-neutral-700 shadow-sm"><Truck size={18} /></div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-neutral-800">Free Ship</p>
              </div>
              <div className="flex flex-col items-center text-center gap-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-neutral-700 shadow-sm"><RotateCcw size={18} /></div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-neutral-800">7-Day Return</p>
              </div>
              <div className="flex flex-col items-center text-center gap-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-neutral-700 shadow-sm"><ShieldCheck size={18} /></div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-neutral-800">Secure Pay</p>
              </div>
            </motion.div>

          </motion.div>
        </div>
      </div>
    </main>
  )
}