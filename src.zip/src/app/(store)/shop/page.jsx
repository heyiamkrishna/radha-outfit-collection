'use client'

import { use, useEffect, useState } from 'react'
import Link from 'next/link'
import { Filter, SlidersHorizontal, ArrowRight, CheckCircle2, Loader2 } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { createClient } from '@/lib/supabase/client'

export default function ShopPage({ searchParams }) {
  // In Next.js 15, searchParams is a promise, so we unwrap it with React.use()
  const params = use(searchParams)
  const currentGender = params?.gender || 'all'
  const currentSort = params?.sort || 'newest'

  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  // Fetch products dynamically when filters change
  useEffect(() => {
    async function fetchProducts() {
      setLoading(true)
      let query = supabase
        .from('products')
        .select('id, name, slug, base_price, compare_price, image_url, gender, badge, is_trending, is_active')
        .eq('is_active', true)

      if (currentGender !== 'all') query = query.eq('gender', currentGender)
      
      if (currentSort === 'price_asc') query = query.order('base_price', { ascending: true })
      else if (currentSort === 'price_desc') query = query.order('base_price', { ascending: false })
      else query = query.order('created_at', { ascending: false })

      const { data } = await query
      setProducts(data || [])
      setLoading(false)
    }

    fetchProducts()
  }, [currentGender, currentSort])

  const getFilterUrl = (genderStr) => `/shop?gender=${genderStr}&sort=${currentSort}`
  const getSortUrl = (sortStr) => `/shop?gender=${currentGender}&sort=${sortStr}`

  // Framer Motion Variants
  const containerVariants = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.1 } }
  }
  const itemVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.95 },
    show: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: "easeOut" } },
    exit: { opacity: 0, scale: 0.9, transition: { duration: 0.2 } }
  }

  // Visual Category Data
  const visualCategories = [
    { id: 'all', title: "All Products", bgClass: 'from-neutral-300 to-neutral-100', textColor: 'text-neutral-900', imgSrc: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=400&q=80' },
    { id: 'men', title: "Men's Wear", bgClass: 'from-blue-300 to-blue-100', textColor: 'text-blue-950', imgSrc: 'https://images.unsplash.com/photo-1617137968427-85924c800a22?w=300&q=80' },
    { id: 'women', title: "Women's Wear", bgClass: 'from-orange-300 to-orange-100', textColor: 'text-orange-950', imgSrc: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=300&q=80' },
    { id: 'kids', title: "Kids Collection", bgClass: 'from-emerald-300 to-emerald-100', textColor: 'text-emerald-950', imgSrc: 'https://images.unsplash.com/photo-1519241047957-be31d7379a5d?w=300&q=80' },
    { id: 'unisex', title: "Unisex Styles", bgClass: 'from-rose-300 to-rose-100', textColor: 'text-rose-950', imgSrc: 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=300&q=80' }
  ]

  return (
    <main className="min-h-screen bg-white pb-24 pt-8 overflow-hidden">
      <div className="mx-auto max-w-[1600px] px-4 md:px-8">
        
        {/* ================= HEADER ================= */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8 border-b border-neutral-100 pb-8 text-center md:text-left"
        >
          <h1 className="text-4xl font-bold tracking-tight text-neutral-900 md:text-5xl font-[family-name:var(--font-syne)]">
            Shop Collection
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-neutral-500 md:mx-0">
            Premium fabrics. Perfect oversized fits. Elevate your everyday wardrobe with our latest arrivals.
          </p>
        </motion.div>

        {/* ================= VISUAL CATEGORIES ================= */}
        <div className="mb-10 lg:mb-16">
          <motion.div 
            variants={containerVariants}
            initial="hidden"
            animate="show"
            className="flex w-full snap-x snap-mandatory gap-3 overflow-x-auto pb-4 hide-scrollbar md:grid md:grid-cols-3 lg:grid-cols-5 md:gap-4 md:overflow-visible md:pb-0"
          >
            {visualCategories.map((category) => {
              const isActive = currentGender === category.id
              return (
                <motion.div key={category.id} variants={itemVariants} className="min-w-[220px] shrink-0 snap-start md:w-full md:min-w-0">
                  <Link
                    href={getFilterUrl(category.id)}
                    className={`group relative flex h-28 w-full items-center overflow-hidden rounded-2xl bg-gradient-to-r p-4 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] md:h-32 ${category.bgClass} ${isActive ? 'ring-2 ring-black ring-offset-2 shadow-lg' : 'shadow-sm'}`}
                  >
                    <div className="relative z-10 w-[55%]">
                      <h3 className={`text-base font-bold leading-tight md:text-lg ${category.textColor}`}>{category.title}</h3>
                      {isActive && (
                        <span className="mt-2 inline-flex items-center gap-1 rounded-full bg-white/70 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-black shadow-sm backdrop-blur-md">
                          <CheckCircle2 size={12} /> Active
                        </span>
                      )}
                    </div>
                    <div className="absolute -right-2 top-0 h-full w-[55%]">
                      <div className="absolute inset-0 z-10 bg-gradient-to-r from-transparent via-transparent to-transparent [mask-image:linear-gradient(to_right,transparent_0%,black_30%)]">
                        <img src={category.imgSrc} alt={category.title} className={`h-full w-full object-cover object-center transition-transform duration-700 ${isActive ? 'scale-110' : 'group-hover:scale-110'}`} />
                      </div>
                    </div>
                  </Link>
                </motion.div>
              )
            })}
          </motion.div>
        </div>

        {/* ================= MAIN CONTENT ================= */}
        <div className="flex flex-col gap-8 lg:flex-row lg:items-start lg:gap-12">
          
          {/* SIDEBAR: STICKY ON DESKTOP */}
          <motion.aside 
            initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.2 }}
            className="w-full shrink-0 lg:sticky lg:top-28 lg:w-64"
          >
            <div className="rounded-2xl border border-neutral-100 bg-neutral-50 p-6 shadow-sm">
              <h3 className="mb-4 flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-neutral-900">
                <SlidersHorizontal size={16} /> Sort By
              </h3>
              <ul className="space-y-3">
                {[
                  { id: 'newest', label: 'Newest Arrivals' },
                  { id: 'price_asc', label: 'Price: Low to High' },
                  { id: 'price_desc', label: 'Price: High to Low' },
                ].map((item) => (
                  <li key={item.id}>
                    <Link href={getSortUrl(item.id)} className={`flex items-center justify-between text-sm transition-colors duration-200 ${currentSort === item.id ? 'font-bold text-black' : 'font-medium text-neutral-500 hover:text-black'}`}>
                      <span>{item.label}</span>
                      {currentSort === item.id && <motion.div layoutId="active-sort"><ArrowRight size={14} /></motion.div>}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </motion.aside>

          {/* PRODUCT GRID */}
          <div className="flex-1">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mb-6 flex items-center justify-between">
              <p className="text-sm font-medium text-neutral-500">
                {loading ? 'Loading...' : <>Showing <span className="font-bold text-black">{products.length}</span> products</>}
              </p>
            </motion.div>

            {loading ? (
              <div className="flex w-full items-center justify-center py-32">
                <Loader2 className="h-8 w-8 animate-spin text-neutral-400" />
              </div>
            ) : products.length === 0 ? (
              <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-neutral-200 bg-neutral-50 px-4 py-32 text-center">
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-white shadow-sm"><Filter size={24} className="text-neutral-400" /></div>
                <h3 className="text-lg font-bold text-neutral-900">No products found</h3>
                <Link href="/shop" className="mt-6 rounded-full bg-black px-6 py-3 text-sm font-semibold text-white transition hover:bg-neutral-800">Clear filters</Link>
              </motion.div>
            ) : (
              <motion.div layout className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-4 md:gap-x-6 md:gap-y-12">
                <AnimatePresence mode="popLayout">
                  {products.map((product) => (
                    <motion.div layout key={product.id} variants={itemVariants} initial="hidden" animate="show" exit="exit" className="group block">
                      <Link href={`/product/${product.slug}`}>
                        <div className="relative aspect-[3/4] w-full overflow-hidden rounded-2xl bg-neutral-100 shadow-[0_2px_10px_-3px_rgba(6,81,237,0.05)] transition-all duration-300 group-hover:-translate-y-1 group-hover:shadow-[0_8px_30px_rgb(0,0,0,0.1)]">
                          <img src={product.image_url || 'https://placehold.co/600x800/f5f5f5/a3a3a3?text=No+Image'} alt={product.name} className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110" loading="lazy" />
                          <div className="absolute inset-0 bg-black/0 transition-colors duration-500 group-hover:bg-black/5" />
                          <div className="absolute left-3 top-3 flex flex-col gap-2">
                            {product.compare_price > product.base_price && (
                              <span className="inline-flex w-fit items-center rounded-full bg-[#ff3333] px-2.5 py-1 text-[9px] font-black uppercase tracking-wider text-white shadow-sm">Sale</span>
                            )}
                          </div>
                        </div>
                        <div className="mt-4 flex flex-col">
                          <div className="flex justify-between gap-2">
                            <h3 className="truncate text-sm font-bold text-neutral-900 transition-colors group-hover:text-neutral-600">{product.name}</h3>
                            <span className="shrink-0 text-sm font-bold text-black">₹{product.base_price}</span>
                          </div>
                          <div className="mt-1 flex items-center justify-between">
                            <p className="text-[10px] font-bold uppercase tracking-widest text-neutral-400">{product.gender || 'UNISEX'}</p>
                            {product.compare_price > product.base_price && (
                              <span className="text-xs font-medium text-neutral-400 line-through">₹{product.compare_price}</span>
                            )}
                          </div>
                        </div>
                      </Link>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}