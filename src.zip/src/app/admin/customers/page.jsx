'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import {
  Search,
  Users,
  UserCheck,
  UserX,
  ShoppingBag,
  X,
  Loader2,
  Mail,
  Phone,
  CalendarDays,
  ChevronRight,
  RefreshCw,
} from 'lucide-react'

import { createClient } from '@/lib/supabase/client'

export default function CustomersPage() {
  const [customers, setCustomers] = useState([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [error, setError] = useState('')

  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all')
  const [selectedCustomer, setSelectedCustomer] = useState(null)

  /*
  ==================================================
  LOAD CUSTOMERS
  ==================================================
  */

  const loadCustomers = useCallback(async (showRefresh = false) => {
    try {
      if (showRefresh) {
        setRefreshing(true)
      } else {
        setLoading(true)
      }

      setError('')

      const response = await fetch(
        '/api/admin/customers',
        {
          method: 'GET',
          cache: 'no-store',
        }
      )

      const result = await response.json()

      if (!response.ok) {
        throw new Error(
          result?.error || 'Unable to load customers.'
        )
      }

      setCustomers(result?.customers || [])
    } catch (error) {
      console.error(
        'Customer load error:',
        error
      )

      setError(
        error?.message ||
          'Unable to load customers.'
      )
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }, [])

  /*
  ==================================================
  INITIAL LOAD
  ==================================================
  */

  useEffect(() => {
    loadCustomers()
  }, [loadCustomers])

  /*
  ==================================================
  REALTIME
  ==================================================
  */

  useEffect(() => {
    const supabase = createClient()

    const channel = supabase
      .channel('admin-customers-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'profiles',
        },
        () => {
          loadCustomers(true)
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [loadCustomers])

  /*
  ==================================================
  STATS
  ==================================================
  */

  const stats = useMemo(() => {
    const total = customers.length

    const active = customers.filter(
      (customer) =>
        customer.is_active !== false
    ).length

    const inactive = customers.filter(
      (customer) =>
        customer.is_active === false
    ).length

    const totalOrders = customers.reduce(
      (sum, customer) =>
        sum +
        Number(
          customer.order_count || 0
        ),
      0
    )

    return {
      total,
      active,
      inactive,
      totalOrders,
    }
  }, [customers])

  /*
  ==================================================
  FILTER
  ==================================================
  */

  const filteredCustomers = useMemo(() => {
    const searchValue =
      search.trim().toLowerCase()

    return customers.filter(
      (customer) => {
        const name =
          customer.full_name
            ?.toLowerCase() || ''

        const email =
          customer.email
            ?.toLowerCase() || ''

        const phone =
          customer.phone
            ?.toLowerCase() || ''

        const matchesSearch =
          !searchValue ||
          name.includes(searchValue) ||
          email.includes(searchValue) ||
          phone.includes(searchValue)

        let matchesFilter = true

        if (filter === 'active') {
          matchesFilter =
            customer.is_active !== false
        }

        if (filter === 'inactive') {
          matchesFilter =
            customer.is_active === false
        }

        return (
          matchesSearch &&
          matchesFilter
        )
      }
    )
  }, [
    customers,
    search,
    filter,
  ])

  /*
  ==================================================
  LOADING
  ==================================================
  */

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {Array.from({
            length: 4,
          }).map((_, index) => (
            <div
              key={index}
              className="h-36 animate-pulse rounded-[28px] bg-neutral-200"
            />
          ))}
        </div>

        <div className="h-20 animate-pulse rounded-[28px] bg-neutral-200" />

        <div className="h-[500px] animate-pulse rounded-[28px] bg-neutral-200" />
      </div>
    )
  }

  /*
  ==================================================
  ERROR
  ==================================================
  */

  if (error) {
    return (
      <div className="rounded-[28px] border border-red-100 bg-red-50 p-6">
        <p className="font-semibold text-red-700">
          Unable to load customers
        </p>

        <p className="mt-2 text-sm text-red-500">
          {error}
        </p>

        <button
          type="button"
          onClick={() =>
            loadCustomers()
          }
          className="mt-5 rounded-xl bg-black px-5 py-3 text-sm font-semibold text-white"
        >
          Try Again
        </button>
      </div>
    )
  }

  return (
    <>
      <div className="space-y-8">

        {/* ==========================================
            HEADER ACTIONS
        ========================================== */}

        <div className="flex items-center justify-end">
          <button
            type="button"
            onClick={() =>
              loadCustomers(true)
            }
            disabled={refreshing}
            className="inline-flex h-11 items-center gap-2 rounded-2xl border border-black/[0.06] bg-white px-4 text-sm font-semibold shadow-sm transition hover:-translate-y-0.5 disabled:opacity-50"
          >
            <RefreshCw
              size={16}
              className={
                refreshing
                  ? 'animate-spin'
                  : ''
              }
            />

            Refresh
          </button>
        </div>

        {/* ==========================================
            STATS
        ========================================== */}

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">

          <StatCard
            label="Customers"
            value={stats.total}
            description="Registered customers"
            icon={<Users size={20} />}
          />

          <StatCard
            label="Active"
            value={stats.active}
            description="Currently active"
            icon={<UserCheck size={20} />}
          />

          <StatCard
            label="Inactive"
            value={stats.inactive}
            description="Inactive accounts"
            icon={<UserX size={20} />}
          />

          <StatCard
            label="Orders"
            value={stats.totalOrders}
            description="Total customer orders"
            icon={
              <ShoppingBag size={20} />
            }
          />

        </div>

        {/* ==========================================
            SEARCH + FILTER
        ========================================== */}

        <div className="rounded-[28px] border border-black/[0.05] bg-white p-3 shadow-[0_4px_20px_rgba(0,0,0,0.03)]">

          <div className="flex flex-col gap-3 md:flex-row">

            <div className="flex h-12 flex-1 items-center rounded-2xl bg-neutral-50 px-4">

              <Search
                size={18}
                className="mr-3 shrink-0 text-neutral-400"
              />

              <input
                type="text"
                value={search}
                onChange={(event) =>
                  setSearch(
                    event.target.value
                  )
                }
                placeholder="Search name, email or phone..."
                className="w-full bg-transparent text-sm outline-none placeholder:text-neutral-400"
              />

              {search && (
                <button
                  type="button"
                  onClick={() =>
                    setSearch('')
                  }
                  className="text-neutral-400 transition hover:text-black"
                >
                  <X size={17} />
                </button>
              )}

            </div>

            <div className="flex overflow-x-auto rounded-2xl bg-neutral-50 p-1">

              <FilterButton
                active={
                  filter === 'all'
                }
                onClick={() =>
                  setFilter('all')
                }
              >
                All
              </FilterButton>

              <FilterButton
                active={
                  filter === 'active'
                }
                onClick={() =>
                  setFilter('active')
                }
              >
                Active
              </FilterButton>

              <FilterButton
                active={
                  filter === 'inactive'
                }
                onClick={() =>
                  setFilter('inactive')
                }
              >
                Inactive
              </FilterButton>

            </div>

          </div>

        </div>

        {/* ==========================================
            CUSTOMER TABLE
        ========================================== */}

        <div className="overflow-hidden rounded-[28px] border border-black/[0.05] bg-white shadow-[0_4px_20px_rgba(0,0,0,0.03)]">

          {/* DESKTOP TABLE */}

          <div className="hidden overflow-x-auto md:block">

            <table className="w-full">

              <thead>
                <tr className="border-b border-black/[0.05] text-left">

                  <th className="px-6 py-5 text-[10px] font-bold uppercase tracking-[0.18em] text-neutral-400">
                    Customer
                  </th>

                  <th className="px-6 py-5 text-[10px] font-bold uppercase tracking-[0.18em] text-neutral-400">
                    Contact
                  </th>

                  <th className="px-6 py-5 text-[10px] font-bold uppercase tracking-[0.18em] text-neutral-400">
                    Orders
                  </th>

                  <th className="px-6 py-5 text-[10px] font-bold uppercase tracking-[0.18em] text-neutral-400">
                    Status
                  </th>

                  <th className="px-6 py-5 text-right text-[10px] font-bold uppercase tracking-[0.18em] text-neutral-400">
                    Action
                  </th>

                </tr>
              </thead>

              <tbody>

                {filteredCustomers.map(
                  (customer) => (
                    <CustomerRow
                      key={customer.id}
                      customer={customer}
                      onClick={() =>
                        setSelectedCustomer(
                          customer
                        )
                      }
                    />
                  )
                )}

              </tbody>

            </table>

          </div>

          {/* MOBILE */}

          <div className="divide-y divide-black/[0.05] md:hidden">

            {filteredCustomers.map(
              (customer) => (
                <MobileCustomerCard
                  key={customer.id}
                  customer={customer}
                  onClick={() =>
                    setSelectedCustomer(
                      customer
                    )
                  }
                />
              )
            )}

          </div>

          {/* EMPTY */}

          {filteredCustomers.length ===
            0 && (
            <div className="flex min-h-[350px] flex-col items-center justify-center px-6 text-center">

              <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-neutral-100">
                <Users
                  size={25}
                  className="text-neutral-400"
                />
              </div>

              <h3 className="mt-5 text-lg font-bold">
                No customers found
              </h3>

              <p className="mt-2 max-w-sm text-sm text-neutral-400">
                Try changing your search
                or filter.
              </p>

            </div>
          )}

        </div>

      </div>

      {/* ==========================================
          CUSTOMER DRAWER
      ========================================== */}

      {selectedCustomer && (
        <CustomerDrawer
          customer={
            selectedCustomer
          }
          onClose={() =>
            setSelectedCustomer(null)
          }
        />
      )}
    </>
  )
}

/*
==================================================
STAT CARD
==================================================
*/

function StatCard({
  label,
  value,
  description,
  icon,
}) {
  return (
    <div className="group rounded-[28px] border border-black/[0.05] bg-white p-6 shadow-[0_4px_20px_rgba(0,0,0,0.03)] transition duration-300 hover:-translate-y-1 hover:shadow-lg">

      <div className="flex items-start justify-between">

        <div>
          <p className="text-xs font-medium text-neutral-400">
            {label}
          </p>

          <h2 className="mt-3 text-4xl font-bold tracking-tight">
            {value}
          </h2>
        </div>

        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-neutral-100 transition group-hover:bg-black group-hover:text-white">
          {icon}
        </div>

      </div>

      <p className="mt-5 text-xs text-neutral-400">
        {description}
      </p>

    </div>
  )
}

/*
==================================================
FILTER BUTTON
==================================================
*/

function FilterButton({
  active,
  onClick,
  children,
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        active
          ? 'whitespace-nowrap rounded-xl bg-black px-5 py-2.5 text-xs font-semibold text-white'
          : 'whitespace-nowrap rounded-xl px-5 py-2.5 text-xs font-medium text-neutral-500 transition hover:bg-white'
      }
    >
      {children}
    </button>
  )
}

/*
==================================================
CUSTOMER ROW
==================================================
*/

function CustomerRow({
  customer,
  onClick,
}) {
  const name =
    customer.full_name ||
    'Unnamed Customer'

  const initial =
    name
      .charAt(0)
      .toUpperCase()

  return (
    <tr className="group border-b border-black/[0.04] transition hover:bg-neutral-50">

      <td className="px-6 py-5">

        <div className="flex items-center gap-3">

          <Avatar
            customer={customer}
          />

          <div>
            <p className="text-sm font-semibold">
              {name}
            </p>

            <p className="mt-1 text-xs text-neutral-400">
              {customer.id?.slice(
                0,
                8
              )}
              ...
            </p>
          </div>

        </div>

      </td>

      <td className="px-6 py-5">

        <div className="space-y-1">

          {customer.email && (
            <p className="text-sm text-neutral-600">
              {customer.email}
            </p>
          )}

          {customer.phone && (
            <p className="text-xs text-neutral-400">
              {customer.phone}
            </p>
          )}

        </div>

      </td>

      <td className="px-6 py-5">

        <span className="text-sm font-semibold">
          {Number(
            customer.order_count || 0
          )}
        </span>

      </td>

      <td className="px-6 py-5">

        <StatusBadge
          active={
            customer.is_active !==
            false
          }
        />

      </td>

      <td className="px-6 py-5 text-right">

        <button
          type="button"
          onClick={onClick}
          className="inline-flex h-10 items-center gap-2 rounded-xl border border-black/[0.06] bg-white px-4 text-xs font-semibold transition hover:-translate-y-0.5 hover:bg-black hover:text-white"
        >
          View

          <ChevronRight
            size={14}
          />
        </button>

      </td>

    </tr>
  )
}

/*
==================================================
MOBILE CUSTOMER
==================================================
*/

function MobileCustomerCard({
  customer,
  onClick,
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-4 p-5 text-left transition hover:bg-neutral-50"
    >

      <Avatar
        customer={customer}
      />

      <div className="min-w-0 flex-1">

        <p className="truncate text-sm font-semibold">
          {customer.full_name ||
            'Unnamed Customer'}
        </p>

        <p className="mt-1 truncate text-xs text-neutral-400">
          {customer.email ||
            customer.phone ||
            'No contact information'}
        </p>

        <div className="mt-2 flex items-center gap-2">

          <StatusBadge
            active={
              customer.is_active !==
              false
            }
          />

          <span className="text-[10px] text-neutral-400">
            {Number(
              customer.order_count ||
                0
            )}{' '}
            orders
          </span>

        </div>

      </div>

      <ChevronRight
        size={17}
        className="shrink-0 text-neutral-300"
      />

    </button>
  )
}

/*
==================================================
AVATAR
==================================================
*/

function Avatar({
  customer,
}) {
  const name =
    customer.full_name ||
    'Customer'

  const initial =
    name
      .charAt(0)
      .toUpperCase()

  return (
    <div className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-2xl bg-neutral-100 text-sm font-bold">

      {customer.avatar_url ? (
        <img
          src={customer.avatar_url}
          alt={name}
          className="h-full w-full object-cover"
        />
      ) : (
        initial
      )}

    </div>
  )
}

/*
==================================================
STATUS
==================================================
*/

function StatusBadge({
  active,
}) {
  return (
    <span
      className={
        active
          ? 'inline-flex rounded-full bg-emerald-50 px-3 py-1.5 text-[10px] font-semibold text-emerald-600'
          : 'inline-flex rounded-full bg-neutral-100 px-3 py-1.5 text-[10px] font-semibold text-neutral-500'
      }
    >
      {active
        ? 'Active'
        : 'Inactive'}
    </span>
  )
}

/*
==================================================
CUSTOMER DRAWER
==================================================
*/

function CustomerDrawer({
  customer,
  onClose,
}) {
  const name =
    customer.full_name ||
    'Unnamed Customer'

  return (
    <div className="fixed inset-0 z-[999]">

      {/* BACKDROP */}

      <button
        type="button"
        aria-label="Close customer details"
        onClick={onClose}
        className="absolute inset-0 h-full w-full bg-black/40 backdrop-blur-sm"
      />

      {/* DRAWER */}

      <div className="absolute right-0 top-0 flex h-full w-full max-w-lg flex-col bg-white shadow-2xl">

        {/* HEADER */}

        <div className="flex items-center justify-between border-b border-black/[0.06] px-6 py-5">

          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-neutral-400">
              Customer
            </p>

            <h2 className="mt-1 text-xl font-bold">
              Details
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex h-10 w-10 items-center justify-center rounded-xl bg-neutral-100 transition hover:bg-black hover:text-white"
          >
            <X size={18} />
          </button>

        </div>

        {/* CONTENT */}

        <div className="flex-1 overflow-y-auto p-6">

          <div className="rounded-[28px] bg-neutral-950 p-6 text-white">

            <div className="flex items-center gap-4">

              <div className="flex h-16 w-16 items-center justify-center overflow-hidden rounded-3xl bg-white/10 text-xl font-bold">

                {customer.avatar_url ? (
                  <img
                    src={
                      customer.avatar_url
                    }
                    alt={name}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  name
                    .charAt(0)
                    .toUpperCase()
                )}

              </div>

              <div>

                <h3 className="text-xl font-bold">
                  {name}
                </h3>

                <StatusBadge
                  active={
                    customer.is_active !==
                    false
                  }
                />

              </div>

            </div>

          </div>

          <div className="mt-6 grid gap-3">

            <DetailCard
              icon={
                <Mail size={17} />
              }
              label="Email"
              value={
                customer.email ||
                'Not available'
              }
            />

            <DetailCard
              icon={
                <Phone size={17} />
              }
              label="Phone"
              value={
                customer.phone ||
                'Not available'
              }
            />

            <DetailCard
              icon={
                <ShoppingBag
                  size={17}
                />
              }
              label="Orders"
              value={String(
                Number(
                  customer.order_count ||
                    0
                )
              )}
            />

            <DetailCard
              icon={
                <CalendarDays
                  size={17}
                />
              }
              label="Joined"
              value={
                customer.created_at
                  ? new Date(
                      customer.created_at
                    ).toLocaleDateString(
                      'en-IN',
                      {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                      }
                    )
                  : 'Unknown'
              }
            />

          </div>

        </div>

      </div>

    </div>
  )
}

/*
==================================================
DETAIL CARD
==================================================
*/

function DetailCard({
  icon,
  label,
  value,
}) {
  return (
    <div className="flex items-center gap-4 rounded-2xl border border-black/[0.05] bg-white p-4">

      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-neutral-100">
        {icon}
      </div>

      <div className="min-w-0">

        <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-neutral-400">
          {label}
        </p>

        <p className="mt-1 break-words text-sm font-semibold text-neutral-800">
          {value}
        </p>

      </div>

    </div>
  )
}