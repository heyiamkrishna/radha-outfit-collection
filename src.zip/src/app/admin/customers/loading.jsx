export default function Loading() {
  return (
    <div className="min-h-screen bg-[#fafafa] px-4 pb-24 pt-28 md:px-8">

      <div className="mx-auto max-w-[1500px] animate-pulse">

        <div className="h-4 w-32 rounded bg-neutral-200" />

        <div className="mt-3 h-12 w-64 rounded-xl bg-neutral-200" />

        <div className="mt-3 h-4 w-96 rounded bg-neutral-200" />

        <div className="mt-10 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">

          {[1, 2, 3, 4].map(
            (item) => (
              <div
                key={item}
                className="h-36 rounded-[28px] bg-neutral-200"
              />
            )
          )}

        </div>

        <div className="mt-8 h-16 rounded-[28px] bg-neutral-200" />

        <div className="mt-6 h-[550px] rounded-[28px] bg-neutral-200" />

      </div>

    </div>
  )
}