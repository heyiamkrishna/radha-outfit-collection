import Link from 'next/link'
import { Plus } from 'lucide-react'

import { createClient } from '@/lib/supabase/server'
import ProductTable from '@/components/admin/products/ProductTable'
import ProductFilters from '@/components/admin/products/ProductFilters'

export const metadata = {
  title: 'Products | Admin | Radha Outfit Collection',
}

export default async function ProductsPage({ searchParams }) {
  const params = await searchParams

  const search = params?.q || ''
  const category = params?.category || 'all'
  const status = params?.status || 'all'

  const supabase = await createClient()

  // --------------------------------------------
  // CATEGORIES
  // --------------------------------------------

  const { data: categories } = await supabase
    .from('categories')
    .select('id, name, slug')
    .order('sort_order', {
      ascending: true,
    })

  // --------------------------------------------
  // PRODUCTS
  // --------------------------------------------

  let query = supabase
    .from('products')
    .select(`
      id,
      name,
      slug,
      base_price,
      compare_price,
      status,
      is_active,
      is_featured,
      is_trending,
      badge,
      category_id,
      created_at,
      categories (
        id,
        name,
        slug
      ),
      product_images (
        image_url,
        is_primary
      )
    `)
    .order('created_at', {
      ascending: false,
    })

  // Search

  if (search) {
    query = query.ilike(
      'name',
      `%${search}%`
    )
  }

  // Category

  if (category !== 'all') {
    query = query.eq(
      'category_id',
      category
    )
  }

  // Status

  if (status === 'active') {
    query = query.eq('is_active', true)
  }

  if (status === 'inactive') {
    query = query.eq('is_active', false)
  }

  const { data: products, error } = await query

  if (error) {
    console.error(
      'Admin products error:',
      error.message
    )
  }

  const safeProducts = products || []

  return (
    <div className="mx-auto max-w-[1600px]">

      {/* HEADER */}

      <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">

        <div>

          <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-neutral-400">
            Admin / Store
          </p>

          <h1 className="font-[family-name:var(--font-syne)] text-3xl font-bold tracking-tight sm:text-4xl">
            Products
          </h1>

          <p className="mt-2 text-sm text-neutral-500">
            Manage your clothing collection, pricing and product visibility.
          </p>

        </div>

        {/* CHANGE THIS LINK */}
        <Link
          href="/admin/products/new"
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-neutral-950 px-5 py-3 text-sm font-medium text-white transition hover:bg-neutral-800"
        >
          <Plus size={17} />
          Add Product
        </Link>

      </div>

      {/* STATS */}

      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">

        <ProductMiniStat
          label="Total"
          value={safeProducts.length}
        />

        <ProductMiniStat
          label="Active"
          value={
            safeProducts.filter(
              (product) =>
                product.is_active
            ).length
          }
        />

        <ProductMiniStat
          label="Featured"
          value={
            safeProducts.filter(
              (product) =>
                product.is_featured
            ).length
          }
        />

        <ProductMiniStat
          label="Trending"
          value={
            safeProducts.filter(
              (product) =>
                product.is_trending
            ).length
          }
        />

      </div>

      {/* FILTERS */}

      <ProductFilters
        categories={categories || []}
        currentSearch={search}
        currentCategory={category}
        currentStatus={status}
      />

      {/* PRODUCT TABLE */}

      <ProductTable
        products={safeProducts}
      />

    </div>
  )
}

function ProductMiniStat({
  label,
  value,
}) {
  return (
    <div className="rounded-2xl border border-black/[0.05] bg-white p-4">

      <p className="text-[10px] font-medium uppercase tracking-[0.15em] text-neutral-400">
        {label}
      </p>

      <p className="mt-2 text-2xl font-semibold tracking-tight">
        {value}
      </p>

    </div>
  )
}