import { createClient } from '@/lib/supabase/server'
import ProductForm from '@/components/admin/products/ProductForm'

export const metadata = {
  title: 'New Product | Admin | Radha Outfit Collection',
}

export default async function NewProductPage() {
  const supabase = await createClient()

  const { data: categories } = await supabase
    .from('categories')
    .select('id, name, slug')
    .order('name', { ascending: true })

  return <ProductForm categories={categories || []} />
}