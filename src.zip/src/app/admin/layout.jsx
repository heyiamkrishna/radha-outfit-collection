import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'

import AdminSidebar from '@/components/admin/AdminSidebar'
import AdminHeader from '@/components/admin/AdminHeader'
import { Toaster } from 'sonner'

export default async function AdminLayout({ children }) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect('/admin/login')
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('full_name, role, is_active')
    .eq('id', user.id)
    .single()

  if (
    !profile ||
    profile.role !== 'ADMIN' ||
    !profile.is_active
  ) {
    redirect('/admin/login')
  }

  return (
    <div className="min-h-screen bg-[#f5f4f0] text-neutral-900">

      <AdminSidebar profile={profile} />

      <div className="lg:pl-[260px]">

        <AdminHeader
          profile={profile}
          email={user.email}
        />

        <main className="px-4 pb-10 pt-24 sm:px-6 lg:px-8 lg:pt-8">
          {children}
        </main>

      </div>
      <Toaster position="top-right" richColors />

    </div>
  )
}