export default function Loading() {
  return (
    <div className="min-h-screen bg-neutral-50 px-4 py-6 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">

        {/* Header */}
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="h-8 w-48 animate-pulse rounded-lg bg-neutral-200" />
            <div className="mt-3 h-4 w-72 animate-pulse rounded bg-neutral-200" />
          </div>

          <div className="h-11 w-36 animate-pulse rounded-full bg-neutral-200" />
        </div>

        {/* Stats */}
        <div className="mb-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {[1, 2, 3, 4].map((item) => (
            <div
              key={item}
              className="rounded-2xl border border-neutral-200 bg-white p-5"
            >
              <div className="h-4 w-20 animate-pulse rounded bg-neutral-200" />
              <div className="mt-4 h-8 w-16 animate-pulse rounded-lg bg-neutral-200" />
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="mb-6 rounded-2xl border border-neutral-200 bg-white p-4">
          <div className="flex flex-col gap-3 md:flex-row">
            <div className="h-11 flex-1 animate-pulse rounded-xl bg-neutral-100" />
            <div className="h-11 w-full animate-pulse rounded-xl bg-neutral-100 md:w-40" />
            <div className="h-11 w-full animate-pulse rounded-xl bg-neutral-100 md:w-40" />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white">
          <div className="border-b border-neutral-200 p-5">
            <div className="h-5 w-32 animate-pulse rounded bg-neutral-200" />
          </div>

          <div className="divide-y divide-neutral-100">
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <div
                key={item}
                className="flex items-center gap-4 p-5"
              >
                <div className="h-10 w-28 animate-pulse rounded-lg bg-neutral-100" />

                <div className="flex-1">
                  <div className="h-4 w-32 animate-pulse rounded bg-neutral-200" />
                  <div className="mt-2 h-3 w-48 animate-pulse rounded bg-neutral-100" />
                </div>

                <div className="hidden h-8 w-20 animate-pulse rounded-full bg-neutral-100 sm:block" />

                <div className="h-8 w-20 animate-pulse rounded-lg bg-neutral-100" />

                <div className="h-8 w-8 animate-pulse rounded-lg bg-neutral-100" />
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  )
}