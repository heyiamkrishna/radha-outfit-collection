'use client'

import { useEffect, useMemo, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  X,
  Check,
  Copy,
  TicketPercent,
  Loader2,
  AlertCircle,
  RefreshCw,
  Percent,
  IndianRupee,
  CalendarDays,
  Power,
} from 'lucide-react'

const EMPTY_FORM = {
  code: '',
  description: '',
  discount_type: 'PERCENTAGE',
  discount_value: '',
  minimum_order_amount: '',
  maximum_discount: '',
  usage_limit: '',
  starts_at: '',
  expires_at: '',
  is_active: true,
}

export default function CouponAdminPage() {
  const supabase = useMemo(() => createClient(), [])

  const [coupons, setCoupons] = useState([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState(null)

  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('ALL')

  const [showModal, setShowModal] = useState(false)
  const [editingCoupon, setEditingCoupon] = useState(null)
  const [form, setForm] = useState(EMPTY_FORM)

  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  // =========================================================
  // LOAD COUPONS
  // =========================================================

  async function loadCoupons() {
    try {
      setLoading(true)
      setError('')

      const { data, error: fetchError } = await supabase
        .from('coupons')
        .select('*')
        .order('created_at', { ascending: false })

      if (fetchError) {
        throw fetchError
      }

      setCoupons(data || [])
    } catch (err) {
      console.error('Coupon fetch error:', err)
      setError(err?.message || 'Failed to load coupons.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadCoupons()
  }, [])

  // =========================================================
  // REALTIME
  // =========================================================

  useEffect(() => {
    const channel = supabase
      .channel('admin-coupons-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'coupons',
        },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            setCoupons((prev) => [
              payload.new,
              ...prev.filter((item) => item.id !== payload.new.id),
            ])
          }

          if (payload.eventType === 'UPDATE') {
            setCoupons((prev) =>
              prev.map((item) =>
                item.id === payload.new.id
                  ? payload.new
                  : item
              )
            )
          }

          if (payload.eventType === 'DELETE') {
            setCoupons((prev) =>
              prev.filter((item) => item.id !== payload.old.id)
            )
          }
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  // =========================================================
  // FILTER
  // =========================================================

  const filteredCoupons = useMemo(() => {
    const query = search.trim().toLowerCase()

    return coupons.filter((coupon) => {
      const matchesSearch =
        !query ||
        coupon.code?.toLowerCase().includes(query) ||
        coupon.description?.toLowerCase().includes(query)

      const matchesStatus =
        statusFilter === 'ALL' ||
        (statusFilter === 'ACTIVE' && coupon.is_active) ||
        (statusFilter === 'INACTIVE' && !coupon.is_active)

      return matchesSearch && matchesStatus
    })
  }, [coupons, search, statusFilter])

  // =========================================================
  // STATS
  // =========================================================

  const stats = useMemo(() => {
    const active = coupons.filter((coupon) => coupon.is_active).length

    const inactive = coupons.filter(
      (coupon) => !coupon.is_active
    ).length

    const totalUsage = coupons.reduce(
      (sum, coupon) =>
        sum + Number(coupon.used_count || coupon.usage_count || 0),
      0
    )

    return {
      total: coupons.length,
      active,
      inactive,
      totalUsage,
    }
  }, [coupons])

  // =========================================================
  // FORM
  // =========================================================

  function openCreate() {
    setEditingCoupon(null)
    setForm(EMPTY_FORM)
    setError('')
    setSuccess('')
    setShowModal(true)
  }

  function openEdit(coupon) {
    setEditingCoupon(coupon)

    setForm({
      code: coupon.code || '',
      description: coupon.description || '',
      discount_type:
        coupon.discount_type || 'PERCENTAGE',
      discount_value:
        coupon.discount_value ?? '',
      minimum_order_amount:
        coupon.minimum_order_amount ?? '',
      maximum_discount:
        coupon.maximum_discount ?? '',
      usage_limit:
        coupon.usage_limit ?? '',
      starts_at: formatDateTimeInput(coupon.starts_at),
      expires_at: formatDateTimeInput(coupon.expires_at),
      is_active: coupon.is_active ?? true,
    })

    setError('')
    setSuccess('')
    setShowModal(true)
  }

  function closeModal() {
    if (saving) return

    setShowModal(false)
    setEditingCoupon(null)
    setForm(EMPTY_FORM)
  }

  function updateField(name, value) {
    setForm((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // =========================================================
  // VALIDATION
  // =========================================================

  function validateForm() {
    if (!form.code.trim()) {
      return 'Coupon code is required.'
    }

    if (!form.discount_value) {
      return 'Discount value is required.'
    }

    const discountValue = Number(form.discount_value)

    if (Number.isNaN(discountValue) || discountValue <= 0) {
      return 'Discount value must be greater than 0.'
    }

    if (
      form.discount_type === 'PERCENTAGE' &&
      discountValue > 100
    ) {
      return 'Percentage discount cannot be greater than 100%.'
    }

    if (
      form.minimum_order_amount &&
      Number(form.minimum_order_amount) < 0
    ) {
      return 'Minimum order amount cannot be negative.'
    }

    if (
      form.maximum_discount &&
      Number(form.maximum_discount) < 0
    ) {
      return 'Maximum discount cannot be negative.'
    }

    if (
      form.usage_limit &&
      Number(form.usage_limit) < 1
    ) {
      return 'Usage limit must be at least 1.'
    }

    if (
      form.starts_at &&
      form.expires_at &&
      new Date(form.starts_at) >= new Date(form.expires_at)
    ) {
      return 'Expiry date must be after start date.'
    }

    return null
  }

  // =========================================================
  // SAVE
  // =========================================================

  async function handleSubmit(event) {
    event.preventDefault()

    const validationError = validateForm()

    if (validationError) {
      setError(validationError)
      return
    }

    try {
      setSaving(true)
      setError('')
      setSuccess('')

      const payload = {
        code: form.code.trim().toUpperCase(),
        description: form.description.trim() || null,
        discount_type: form.discount_type,
        discount_value: Number(form.discount_value),
        minimum_order_amount:
          form.minimum_order_amount
            ? Number(form.minimum_order_amount)
            : 0,
        maximum_discount:
          form.maximum_discount
            ? Number(form.maximum_discount)
            : null,
        usage_limit:
          form.usage_limit
            ? Number(form.usage_limit)
            : null,
        starts_at: form.starts_at
          ? new Date(form.starts_at).toISOString()
          : null,
        expires_at: form.expires_at
          ? new Date(form.expires_at).toISOString()
          : null,
        is_active: Boolean(form.is_active),
      }

      if (editingCoupon) {
        const { data, error: updateError } = await supabase
          .from('coupons')
          .update(payload)
          .eq('id', editingCoupon.id)
          .select()
          .single()

        if (updateError) {
          throw updateError
        }

        setCoupons((prev) =>
          prev.map((coupon) =>
            coupon.id === data.id ? data : coupon
          )
        )

        setSuccess('Coupon updated successfully.')
      } else {
        const { data, error: insertError } = await supabase
          .from('coupons')
          .insert(payload)
          .select()
          .single()

        if (insertError) {
          throw insertError
        }

        setCoupons((prev) => [data, ...prev])

        setSuccess('Coupon created successfully.')
      }

      setTimeout(() => {
        setShowModal(false)
        setEditingCoupon(null)
        setForm(EMPTY_FORM)
        setSuccess('')
      }, 700)
    } catch (err) {
      console.error('Coupon save error:', err)

      if (err?.code === '23505') {
        setError('This coupon code already exists.')
      } else {
        setError(
          err?.message || 'Failed to save coupon.'
        )
      }
    } finally {
      setSaving(false)
    }
  }

  // =========================================================
  // DELETE
  // =========================================================

  async function deleteCoupon(coupon) {
    const confirmed = window.confirm(
      `Delete coupon "${coupon.code}"? This action cannot be undone.`
    )

    if (!confirmed) return

    try {
      setDeleting(coupon.id)
      setError('')

      const { error: deleteError } = await supabase
        .from('coupons')
        .delete()
        .eq('id', coupon.id)

      if (deleteError) {
        throw deleteError
      }

      setCoupons((prev) =>
        prev.filter((item) => item.id !== coupon.id)
      )

      setSuccess('Coupon deleted successfully.')

      setTimeout(() => {
        setSuccess('')
      }, 2500)
    } catch (err) {
      console.error('Coupon delete error:', err)
      setError(
        err?.message || 'Failed to delete coupon.'
      )
    } finally {
      setDeleting(null)
    }
  }

  // =========================================================
  // TOGGLE ACTIVE
  // =========================================================

  async function toggleCoupon(coupon) {
    try {
      const { data, error: updateError } = await supabase
        .from('coupons')
        .update({
          is_active: !coupon.is_active,
        })
        .eq('id', coupon.id)
        .select()
        .single()

      if (updateError) {
        throw updateError
      }

      setCoupons((prev) =>
        prev.map((item) =>
          item.id === data.id ? data : item
        )
      )
    } catch (err) {
      console.error('Coupon status error:', err)
      setError(
        err?.message || 'Failed to update coupon status.'
      )
    }
  }

  // =========================================================
  // COPY
  // =========================================================

  async function copyCode(code) {
    try {
      await navigator.clipboard.writeText(code)

      setSuccess(`Copied "${code}"`)

      setTimeout(() => {
        setSuccess('')
      }, 1500)
    } catch {
      setError('Could not copy coupon code.')
    }
  }

  // =========================================================
  // HELPERS
  // =========================================================

  function formatDateTimeInput(value) {
    if (!value) return ''

    const date = new Date(value)

    if (Number.isNaN(date.getTime())) {
      return ''
    }

    const offset = date.getTimezoneOffset()
    const localDate = new Date(
      date.getTime() - offset * 60 * 1000
    )

    return localDate.toISOString().slice(0, 16)
  }

  function formatDate(value) {
    if (!value) return '—'

    const date = new Date(value)

    if (Number.isNaN(date.getTime())) {
      return '—'
    }

    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    })
  }

  function isExpired(coupon) {
    if (!coupon.expires_at) return false

    return new Date(coupon.expires_at) < new Date()
  }

  function getDiscountText(coupon) {
    if (coupon.discount_type === 'FIXED') {
      return `₹${Number(
        coupon.discount_value || 0
      ).toLocaleString('en-IN')}`
    }

    return `${Number(
      coupon.discount_value || 0
    )}%`
  }

  // =========================================================
  // UI
  // =========================================================

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-950">

      {/* HEADER */}

      <div className="border-b border-neutral-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-4 py-5 sm:px-6 lg:px-8">

          <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">

            <div>
              <div className="mb-2 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-neutral-400">
                <TicketPercent size={14} />
                Promotions
              </div>

              <h1 className="font-[family-name:var(--font-syne)] text-3xl font-black tracking-tight sm:text-4xl">
                Coupons
              </h1>

              <p className="mt-1 text-sm text-neutral-500">
                Create and manage discount coupons for your store.
              </p>
            </div>

            <div className="flex gap-2">

              <button
                type="button"
                onClick={loadCoupons}
                disabled={loading}
                className="inline-flex h-11 items-center justify-center gap-2 rounded-full border border-neutral-200 bg-white px-4 text-sm font-bold transition hover:bg-neutral-100 disabled:opacity-50"
              >
                <RefreshCw
                  size={16}
                  className={loading ? 'animate-spin' : ''}
                />

                <span className="hidden sm:inline">
                  Refresh
                </span>
              </button>

              <button
                type="button"
                onClick={openCreate}
                className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-black px-5 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-95"
              >
                <Plus size={17} />
                New Coupon
              </button>

            </div>

          </div>

        </div>
      </div>

      {/* MAIN */}

      <main className="mx-auto max-w-[1600px] px-4 py-6 sm:px-6 lg:px-8">

        {/* ALERTS */}

        {error && (
          <div className="mb-5 flex items-start gap-3 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            <AlertCircle
              size={18}
              className="mt-0.5 shrink-0"
            />

            <div className="flex-1">
              {error}
            </div>

            <button
              type="button"
              onClick={() => setError('')}
            >
              <X size={17} />
            </button>
          </div>
        )}

        {success && (
          <div className="mb-5 flex items-center gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-700">
            <Check size={18} />
            {success}
          </div>
        )}

        {/* STATS */}

        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">

          <StatCard
            icon={TicketPercent}
            label="Total Coupons"
            value={stats.total}
          />

          <StatCard
            icon={Power}
            label="Active"
            value={stats.active}
          />

          <StatCard
            icon={CalendarDays}
            label="Inactive"
            value={stats.inactive}
          />

          <StatCard
            icon={Percent}
            label="Total Usage"
            value={stats.totalUsage}
          />

        </div>

        {/* TOOLBAR */}

        <div className="mt-6 rounded-3xl border border-neutral-200 bg-white p-4">

          <div className="flex flex-col gap-3 lg:flex-row">

            <div className="relative flex-1">

              <Search
                size={18}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400"
              />

              <input
                value={search}
                onChange={(event) =>
                  setSearch(event.target.value)
                }
                placeholder="Search coupon code..."
                className="h-11 w-full rounded-full border border-neutral-200 bg-neutral-50 pl-11 pr-4 text-sm outline-none transition focus:border-neutral-400 focus:bg-white"
              />

            </div>

            <div className="flex rounded-full bg-neutral-100 p-1">

              {['ALL', 'ACTIVE', 'INACTIVE'].map(
                (status) => (
                  <button
                    key={status}
                    type="button"
                    onClick={() =>
                      setStatusFilter(status)
                    }
                    className={`rounded-full px-4 py-2 text-xs font-bold transition ${
                      statusFilter === status
                        ? 'bg-black text-white'
                        : 'text-neutral-500 hover:text-black'
                    }`}
                  >
                    {status}
                  </button>
                )
              )}

            </div>

          </div>

        </div>

        {/* TABLE */}

        <div className="mt-5 overflow-hidden rounded-3xl border border-neutral-200 bg-white">

          {loading ? (
            <LoadingState />
          ) : filteredCoupons.length === 0 ? (
            <EmptyState
              onCreate={openCreate}
            />
          ) : (
            <div className="overflow-x-auto">

              <table className="w-full min-w-[950px] border-collapse">

                <thead>
                  <tr className="border-b border-neutral-200 bg-neutral-50 text-left">
                    <th className="px-5 py-4 text-[10px] font-black uppercase tracking-widest text-neutral-400">
                      Coupon
                    </th>

                    <th className="px-5 py-4 text-[10px] font-black uppercase tracking-widest text-neutral-400">
                      Discount
                    </th>

                    <th className="px-5 py-4 text-[10px] font-black uppercase tracking-widest text-neutral-400">
                      Minimum Order
                    </th>

                    <th className="px-5 py-4 text-[10px] font-black uppercase tracking-widest text-neutral-400">
                      Usage
                    </th>

                    <th className="px-5 py-4 text-[10px] font-black uppercase tracking-widest text-neutral-400">
                      Validity
                    </th>

                    <th className="px-5 py-4 text-[10px] font-black uppercase tracking-widest text-neutral-400">
                      Status
                    </th>

                    <th className="px-5 py-4 text-right text-[10px] font-black uppercase tracking-widest text-neutral-400">
                      Actions
                    </th>
                  </tr>
                </thead>

                <tbody>

                  {filteredCoupons.map((coupon) => {

                    const expired = isExpired(coupon)

                    return (
                      <tr
                        key={coupon.id}
                        className="border-b border-neutral-100 transition hover:bg-neutral-50/70"
                      >

                        {/* COUPON */}

                        <td className="px-5 py-5">

                          <div className="flex items-center gap-3">

                            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-neutral-950 text-white">
                              <TicketPercent size={18} />
                            </div>

                            <div className="min-w-0">

                              <div className="flex items-center gap-2">

                                <span className="font-mono text-sm font-black tracking-wide">
                                  {coupon.code}
                                </span>

                                <button
                                  type="button"
                                  onClick={() =>
                                    copyCode(coupon.code)
                                  }
                                  className="text-neutral-400 transition hover:text-black"
                                  title="Copy code"
                                >
                                  <Copy size={14} />
                                </button>

                              </div>

                              {coupon.description && (
                                <p className="mt-1 max-w-[250px] truncate text-xs text-neutral-400">
                                  {coupon.description}
                                </p>
                              )}

                            </div>

                          </div>

                        </td>

                        {/* DISCOUNT */}

                        <td className="px-5 py-5">

                          <div className="font-bold">
                            {getDiscountText(coupon)}
                          </div>

                          <div className="mt-1 text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                            {coupon.discount_type === 'FIXED'
                              ? 'Fixed'
                              : 'Percentage'}
                          </div>

                          {coupon.maximum_discount &&
                            coupon.discount_type ===
                              'PERCENTAGE' && (
                              <div className="mt-1 text-xs text-neutral-400">
                                Max ₹
                                {Number(
                                  coupon.maximum_discount
                                ).toLocaleString(
                                  'en-IN'
                                )}
                              </div>
                            )}

                        </td>

                        {/* MINIMUM */}

                        <td className="px-5 py-5">

                          <div className="flex items-center gap-1 text-sm font-semibold">
                            <IndianRupee size={13} />
                            {Number(
                              coupon.minimum_order_amount || 0
                            ).toLocaleString('en-IN')}
                          </div>

                        </td>

                        {/* USAGE */}

                        <td className="px-5 py-5">

                          <div className="text-sm font-bold">
                            {coupon.used_count ||
                              coupon.usage_count ||
                              0}
                            {coupon.usage_limit
                              ? ` / ${coupon.usage_limit}`
                              : ''}
                          </div>

                        </td>

                        {/* VALIDITY */}

                        <td className="px-5 py-5">

                          <div className="text-xs font-medium text-neutral-700">
                            {formatDate(coupon.starts_at)}
                          </div>

                          <div className="mt-1 text-[10px] uppercase tracking-wider text-neutral-400">
                            to
                          </div>

                          <div className="text-xs font-medium text-neutral-700">
                            {formatDate(coupon.expires_at)}
                          </div>

                        </td>

                        {/* STATUS */}

                        <td className="px-5 py-5">

                          <button
                            type="button"
                            onClick={() =>
                              toggleCoupon(coupon)
                            }
                            className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-[10px] font-black uppercase tracking-wider ${
                              coupon.is_active && !expired
                                ? 'bg-emerald-100 text-emerald-700'
                                : 'bg-neutral-100 text-neutral-500'
                            }`}
                          >
                            <span
                              className={`h-1.5 w-1.5 rounded-full ${
                                coupon.is_active &&
                                !expired
                                  ? 'bg-emerald-500'
                                  : 'bg-neutral-400'
                              }`}
                            />

                            {expired
                              ? 'Expired'
                              : coupon.is_active
                                ? 'Active'
                                : 'Inactive'}
                          </button>

                        </td>

                        {/* ACTIONS */}

                        <td className="px-5 py-5">

                          <div className="flex justify-end gap-2">

                            <button
                              type="button"
                              onClick={() =>
                                openEdit(coupon)
                              }
                              className="flex h-9 w-9 items-center justify-center rounded-full border border-neutral-200 transition hover:bg-black hover:text-white"
                              title="Edit coupon"
                            >
                              <Pencil size={15} />
                            </button>

                            <button
                              type="button"
                              onClick={() =>
                                deleteCoupon(coupon)
                              }
                              disabled={
                                deleting === coupon.id
                              }
                              className="flex h-9 w-9 items-center justify-center rounded-full border border-red-100 text-red-500 transition hover:bg-red-500 hover:text-white disabled:opacity-50"
                              title="Delete coupon"
                            >
                              {deleting === coupon.id ? (
                                <Loader2
                                  size={15}
                                  className="animate-spin"
                                />
                              ) : (
                                <Trash2 size={15} />
                              )}
                            </button>

                          </div>

                        </td>

                      </tr>
                    )
                  })}

                </tbody>

              </table>

            </div>
          )}

        </div>

      </main>

      {/* MODAL */}

      {showModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">

          <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-[2rem] bg-white shadow-2xl">

            {/* MODAL HEADER */}

            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-neutral-200 bg-white px-5 py-5 sm:px-7">

              <div>

                <p className="text-[10px] font-black uppercase tracking-[0.25em] text-neutral-400">
                  Promotion
                </p>

                <h2 className="mt-1 font-[family-name:var(--font-syne)] text-2xl font-black">
                  {editingCoupon
                    ? 'Edit Coupon'
                    : 'Create Coupon'}
                </h2>

              </div>

              <button
                type="button"
                onClick={closeModal}
                className="flex h-10 w-10 items-center justify-center rounded-full bg-neutral-100 transition hover:bg-neutral-200"
              >
                <X size={18} />
              </button>

            </div>

            {/* FORM */}

            <form
              onSubmit={handleSubmit}
              className="space-y-5 p-5 sm:p-7"
            >

              {/* ERROR */}

              {error && (
                <div className="flex items-start gap-2 rounded-2xl bg-red-50 px-4 py-3 text-sm text-red-600">
                  <AlertCircle size={17} />
                  <span>{error}</span>
                </div>
              )}

              {/* CODE */}

              <div>

                <label className="mb-2 block text-xs font-black uppercase tracking-wider text-neutral-500">
                  Coupon Code
                </label>

                <input
                  value={form.code}
                  onChange={(event) =>
                    updateField(
                      'code',
                      event.target.value
                        .toUpperCase()
                        .replace(/\s/g, '')
                    )
                  }
                  placeholder="WELCOME10"
                  maxLength={50}
                  className="h-12 w-full rounded-xl border border-neutral-200 bg-neutral-50 px-4 font-mono text-sm font-bold uppercase outline-none transition focus:border-black focus:bg-white"
                />

              </div>

              {/* DESCRIPTION */}

              <div>

                <label className="mb-2 block text-xs font-black uppercase tracking-wider text-neutral-500">
                  Description
                </label>

                <textarea
                  value={form.description}
                  onChange={(event) =>
                    updateField(
                      'description',
                      event.target.value
                    )
                  }
                  placeholder="10% off on your first order"
                  rows={3}
                  className="w-full resize-none rounded-xl border border-neutral-200 bg-neutral-50 px-4 py-3 text-sm outline-none transition focus:border-black focus:bg-white"
                />

              </div>

              {/* DISCOUNT */}

              <div className="grid gap-4 sm:grid-cols-2">

                <div>

                  <label className="mb-2 block text-xs font-black uppercase tracking-wider text-neutral-500">
                    Discount Type
                  </label>

                  <select
                    value={form.discount_type}
                    onChange={(event) =>
                      updateField(
                        'discount_type',
                        event.target.value
                      )
                    }
                    className="h-12 w-full rounded-xl border border-neutral-200 bg-neutral-50 px-4 text-sm font-semibold outline-none focus:border-black"
                  >
                    <option value="PERCENTAGE">
                      Percentage
                    </option>

                    <option value="FIXED">
                      Fixed Amount
                    </option>
                  </select>

                </div>

                <div>

                  <label className="mb-2 block text-xs font-black uppercase tracking-wider text-neutral-500">
                    Discount Value
                  </label>

                  <div className="relative">

                    {form.discount_type ===
                      'FIXED' ? (
                      <IndianRupee
                        size={15}
                        className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400"
                      />
                    ) : (
                      <Percent
                        size={15}
                        className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400"
                      />
                    )}

                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={form.discount_value}
                      onChange={(event) =>
                        updateField(
                          'discount_value',
                          event.target.value
                        )
                      }
                      placeholder="10"
                      className="h-12 w-full rounded-xl border border-neutral-200 bg-neutral-50 pl-10 pr-4 text-sm font-bold outline-none focus:border-black"
                    />

                  </div>

                </div>

              </div>

              {/* ORDER LIMITS */}

              <div className="grid gap-4 sm:grid-cols-3">

                <div>

                  <label className="mb-2 block text-xs font-black uppercase tracking-wider text-neutral-500">
                    Minimum Order
                  </label>

                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={form.minimum_order_amount}
                    onChange={(event) =>
                      updateField(
                        'minimum_order_amount',
                        event.target.value
                      )
                    }
                    placeholder="999"
                    className="h-12 w-full rounded-xl border border-neutral-200 bg-neutral-50 px-4 text-sm outline-none focus:border-black"
                  />

                </div>

                <div>

                  <label className="mb-2 block text-xs font-black uppercase tracking-wider text-neutral-500">
                    Maximum Discount
                  </label>

                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={form.maximum_discount}
                    onChange={(event) =>
                      updateField(
                        'maximum_discount',
                        event.target.value
                      )
                    }
                    placeholder="500"
                    disabled={
                      form.discount_type === 'FIXED'
                    }
                    className="h-12 w-full rounded-xl border border-neutral-200 bg-neutral-50 px-4 text-sm outline-none focus:border-black disabled:cursor-not-allowed disabled:opacity-50"
                  />

                </div>

                <div>

                  <label className="mb-2 block text-xs font-black uppercase tracking-wider text-neutral-500">
                    Usage Limit
                  </label>

                  <input
                    type="number"
                    min="1"
                    value={form.usage_limit}
                    onChange={(event) =>
                      updateField(
                        'usage_limit',
                        event.target.value
                      )
                    }
                    placeholder="100"
                    className="h-12 w-full rounded-xl border border-neutral-200 bg-neutral-50 px-4 text-sm outline-none focus:border-black"
                  />

                </div>

              </div>

              {/* DATES */}

              <div className="grid gap-4 sm:grid-cols-2">

                <div>

                  <label className="mb-2 block text-xs font-black uppercase tracking-wider text-neutral-500">
                    Starts At
                  </label>

                  <input
                    type="datetime-local"
                    value={form.starts_at}
                    onChange={(event) =>
                      updateField(
                        'starts_at',
                        event.target.value
                      )
                    }
                    className="h-12 w-full rounded-xl border border-neutral-200 bg-neutral-50 px-4 text-sm outline-none focus:border-black"
                  />

                </div>

                <div>

                  <label className="mb-2 block text-xs font-black uppercase tracking-wider text-neutral-500">
                    Expires At
                  </label>

                  <input
                    type="datetime-local"
                    value={form.expires_at}
                    onChange={(event) =>
                      updateField(
                        'expires_at',
                        event.target.value
                      )
                    }
                    className="h-12 w-full rounded-xl border border-neutral-200 bg-neutral-50 px-4 text-sm outline-none focus:border-black"
                  />

                </div>

              </div>

              {/* ACTIVE */}

              <label className="flex cursor-pointer items-center justify-between rounded-2xl border border-neutral-200 bg-neutral-50 p-4">

                <div>

                  <div className="text-sm font-bold">
                    Active Coupon
                  </div>

                  <div className="mt-1 text-xs text-neutral-500">
                    Customers can use this coupon when active.
                  </div>

                </div>

                <input
                  type="checkbox"
                  checked={form.is_active}
                  onChange={(event) =>
                    updateField(
                      'is_active',
                      event.target.checked
                    )
                  }
                  className="h-5 w-5 accent-black"
                />

              </label>

              {/* BUTTONS */}

              <div className="flex flex-col-reverse gap-3 border-t border-neutral-200 pt-5 sm:flex-row sm:justify-end">

                <button
                  type="button"
                  onClick={closeModal}
                  disabled={saving}
                  className="h-12 rounded-full border border-neutral-200 px-6 text-sm font-bold transition hover:bg-neutral-100 disabled:opacity-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={saving}
                  className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-black px-7 text-sm font-bold text-white transition hover:bg-neutral-800 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {saving ? (
                    <>
                      <Loader2
                        size={17}
                        className="animate-spin"
                      />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Check size={17} />
                      {editingCoupon
                        ? 'Update Coupon'
                        : 'Create Coupon'}
                    </>
                  )}
                </button>

              </div>

            </form>

          </div>

        </div>
      )}

    </div>
  )
}

// =========================================================
// STAT CARD
// =========================================================

function StatCard({
  icon: Icon,
  label,
  value,
}) {
  return (
    <div className="rounded-3xl border border-neutral-200 bg-white p-5">

      <div className="flex items-center justify-between">

        <div>
          <p className="text-[10px] font-black uppercase tracking-widest text-neutral-400">
            {label}
          </p>

          <p className="mt-2 text-2xl font-black tracking-tight">
            {value.toLocaleString('en-IN')}
          </p>
        </div>

        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-neutral-100">
          <Icon size={18} />
        </div>

      </div>

    </div>
  )
}

// =========================================================
// LOADING
// =========================================================

function LoadingState() {
  return (
    <div className="flex min-h-[400px] flex-col items-center justify-center">

      <Loader2
        size={28}
        className="animate-spin text-neutral-400"
      />

      <p className="mt-4 text-sm text-neutral-400">
        Loading coupons...
      </p>

    </div>
  )
}

// =========================================================
// EMPTY
// =========================================================

function EmptyState({ onCreate }) {
  return (
    <div className="flex min-h-[400px] flex-col items-center justify-center px-6 text-center">

      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-neutral-100">
        <TicketPercent
          size={28}
          className="text-neutral-400"
        />
      </div>

      <h3 className="mt-5 font-[family-name:var(--font-syne)] text-xl font-black">
        No coupons found
      </h3>

      <p className="mt-2 max-w-sm text-sm text-neutral-500">
        Create your first discount coupon to start offering promotions.
      </p>

      <button
        type="button"
        onClick={onCreate}
        className="mt-6 inline-flex h-11 items-center gap-2 rounded-full bg-black px-5 text-sm font-bold text-white transition hover:bg-neutral-800"
      >
        <Plus size={16} />
        Create Coupon
      </button>

    </div>
  )
}