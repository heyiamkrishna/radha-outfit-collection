export default function Loading() {
  return (
    <div className="min-h-screen bg-neutral-50 px-4 pb-20 pt-28 md:px-8">

      <div className="mx-auto max-w-7xl animate-pulse">

        <div className="h-10 w-56 rounded-xl bg-neutral-200" />

        <div className="mt-3 h-4 w-96 rounded bg-neutral-200" />

        <div className="mt-10 grid gap-4 md:grid-cols-4">

          {Array.from({
            length: 4,
          }).map((_, index) => (
            <div
              key={index}
              className="h-32 rounded-3xl bg-white"
            />
          ))}

        </div>

        <div className="mt-8 h-20 rounded-3xl bg-white" />

        <div className="mt-6 h-[500px] rounded-3xl bg-white" />

      </div>

    </div>
  )
}