import Link from 'next/link'
import { Plus } from 'lucide-react'

import InventoryClient from '@/components/admin/inventory/InventoryClient'

export const metadata = {
  title:
    'Inventory | Radha Outfit Collection',

  description:
    'Manage product inventory and stock.',
}

export default function InventoryPage() {
  return (
    <div className="min-h-screen bg-[#fafafa] px-4 pb-24 pt-28 md:px-8">
      <div className="mx-auto max-w-[1450px]">

        <div className="mb-8 flex flex-col gap-5 md:flex-row md:items-end md:justify-between">

          <div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.25em] text-neutral-400">
                Admin
              </p>

              <h1 className="mt-2 font-[family-name:var(--font-syne)] text-4xl font-bold tracking-tight md:text-5xl">
                Inventory
              </h1>
            </div>

            <p className="mt-2 max-w-xl text-sm leading-6 text-neutral-400">
              Manage product variants, stock
              quantities, sizes, colors and SKUs
              from one place.
            </p>
          </div>

          <Link
            href="/admin/products/new"
            className="
              inline-flex
              h-12
              items-center
              justify-center
              gap-2
              rounded-2xl
              bg-black
              px-6
              text-sm
              font-semibold
              text-white
              shadow-sm
              transition
              hover:bg-neutral-800
            "
          >
            <Plus size={17} />

            Add Product
          </Link>

        </div>

        <InventoryClient />

      </div>
    </div>
  )
}