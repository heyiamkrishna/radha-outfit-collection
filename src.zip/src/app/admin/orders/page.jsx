'use client'

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react'

import {
  Search,
  ShoppingBag,
  Clock3,
  CheckCircle2,
  XCircle,
  Truck,
  CreditCard,
  ChevronRight,
  X,
  Package,
  User,
  MapPin,
  Phone,
  RefreshCw,
  Loader2,
} from 'lucide-react'

import { motion, AnimatePresence } from 'framer-motion'

import { createClient } from '@/lib/supabase/client'

export default function OrdersPage() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [error, setError] = useState('')

  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('ALL')
  const [paymentFilter, setPaymentFilter] = useState('ALL')

  const [selectedOrder, setSelectedOrder] = useState(null)

  const loadOrders = useCallback(async (silent = false) => {
    try {
      if (silent) {
        setRefreshing(true)
      } else {
        setLoading(true)
      }

      setError('')

      const response = await fetch(
        '/api/admin/orders',
        {
          method: 'GET',
          cache: 'no-store',
        }
      )

      const result = await response.json()

      if (!response.ok) {
        throw new Error(
          result?.error ||
            'Unable to load orders.'
        )
      }

      setOrders(
        Array.isArray(result.orders)
          ? result.orders
          : []
      )
    } catch (error) {
      console.error(
        'Orders load error:',
        error
      )

      setError(
        error?.message ||
          'Unable to load orders.'
      )
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }, [])

  useEffect(() => {
    loadOrders()
  }, [loadOrders])

  /*
  ==================================================
  REALTIME
  ==================================================
  */

  useEffect(() => {
    const supabase = createClient()

    const channel = supabase
      .channel(
        'admin-orders-realtime'
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders',
        },
        () => {
          loadOrders(true)
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'order_items',
        },
        () => {
          loadOrders(true)
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [loadOrders])

  /*
  ==================================================
  STATS
  ==================================================
  */

  const stats = useMemo(() => {
    let revenue = 0
    let pending = 0
    let processing = 0
    let completed = 0
    let cancelled = 0

    orders.forEach((order) => {
      const amount =
        Number(order.total_amount) || 0

      revenue += amount

      const status =
        String(order.status || '')
          .toUpperCase()

      if (status === 'PENDING') {
        pending++
      }

      if (status === 'PROCESSING') {
        processing++
      }

      if (
        status === 'DELIVERED' ||
        status === 'COMPLETED'
      ) {
        completed++
      }

      if (status === 'CANCELLED') {
        cancelled++
      }
    })

    return {
      total: orders.length,
      revenue,
      pending,
      processing,
      completed,
      cancelled,
    }
  }, [orders])

  /*
  ==================================================
  FILTER
  ==================================================
  */

  const filteredOrders = useMemo(() => {
    const value = search
      .trim()
      .toLowerCase()

    return orders.filter((order) => {
      const orderNumber =
        String(
          order.order_number || ''
        ).toLowerCase()

      const customerName =
        String(
          order.customer?.full_name || ''
        ).toLowerCase()

      const customerPhone =
        String(
          order.customer?.phone || ''
        ).toLowerCase()

      const matchesSearch =
        !value ||
        orderNumber.includes(value) ||
        customerName.includes(value) ||
        customerPhone.includes(value)

      const matchesStatus =
        statusFilter === 'ALL' ||
        String(
          order.status || ''
        ).toUpperCase() ===
          statusFilter

      const matchesPayment =
        paymentFilter === 'ALL' ||
        String(
          order.payment_status || ''
        ).toUpperCase() ===
          paymentFilter

      return (
        matchesSearch &&
        matchesStatus &&
        matchesPayment
      )
    })
  }, [
    orders,
    search,
    statusFilter,
    paymentFilter,
  ])

  /*
  ==================================================
  UPDATE STATUS
  ==================================================
  */

  async function updateOrderStatus(
    orderId,
    status
  ) {
    try {
      const response = await fetch(
        `/api/admin/orders/${orderId}`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type':
              'application/json',
          },
          body: JSON.stringify({
            status,
          }),
        }
      )

      const result =
        await response.json()

      if (!response.ok) {
        throw new Error(
          result?.error ||
            'Unable to update order.'
        )
      }

      await loadOrders(true)

      setSelectedOrder((current) => {
        if (
          !current ||
          current.id !== orderId
        ) {
          return current
        }

        return {
          ...current,
          status,
        }
      })
    } catch (error) {
      console.error(
        'Order status update error:',
        error
      )

      alert(
        error?.message ||
          'Unable to update order.'
      )
    }
  }

  /*
  ==================================================
  LOADING
  ==================================================
  */

  if (loading) {
    return (
      <main className="min-h-screen bg-[#fafafa] px-4 pb-24 pt-28 md:px-8">
        <div className="mx-auto max-w-[1500px]">
          <div className="animate-pulse">
            <div className="h-4 w-20 rounded bg-neutral-200" />

            <div className="mt-3 h-12 w-64 rounded-xl bg-neutral-200" />

            <div className="mt-3 h-5 w-96 max-w-full rounded bg-neutral-200" />

            <div className="mt-10 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {Array.from({
                length: 4,
              }).map((_, index) => (
                <div
                  key={index}
                  className="h-36 rounded-[28px] bg-neutral-200"
                />
              ))}
            </div>

            <div className="mt-8 h-16 rounded-[24px] bg-neutral-200" />

            <div className="mt-6 h-[500px] rounded-[28px] bg-neutral-200" />
          </div>
        </div>
      </main>
    )
  }

  /*
  ==================================================
  ERROR
  ==================================================
  */

  if (error) {
    return (
      <main className="min-h-screen bg-[#fafafa] px-4 pb-24 pt-28 md:px-8">
        <div className="mx-auto max-w-[1500px]">
          <div className="rounded-[28px] border border-red-100 bg-red-50 p-8">
            <div className="flex items-center gap-3">
              <XCircle
                size={22}
                className="text-red-500"
              />

              <h2 className="font-semibold text-red-700">
                Unable to load orders
              </h2>
            </div>

            <p className="mt-3 text-sm text-red-500">
              {error}
            </p>

            <button
              type="button"
              onClick={() =>
                loadOrders()
              }
              className="mt-5 rounded-xl bg-black px-5 py-3 text-sm font-semibold text-white"
            >
              Try Again
            </button>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-[#fafafa] px-4 pb-24 pt-28 md:px-8">
      <div className="mx-auto max-w-[1500px]">

        {/* ==========================================
            HEADER
        ========================================== */}

        <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.25em] text-neutral-400">
              Admin / Orders
            </p>

            <h1 className="mt-2 font-[family-name:var(--font-syne)] text-4xl font-bold tracking-tight md:text-5xl">
              Orders
            </h1>

            <p className="mt-2 max-w-xl text-sm leading-6 text-neutral-400">
              Monitor customer orders, payments,
              fulfillment and delivery status in
              real time.
            </p>
          </div>

          <button
            type="button"
            onClick={() =>
              loadOrders(true)
            }
            disabled={refreshing}
            className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-black px-6 text-sm font-semibold text-white transition hover:bg-neutral-800 disabled:opacity-50"
          >
            {refreshing ? (
              <Loader2
                size={17}
                className="animate-spin"
              />
            ) : (
              <RefreshCw size={17} />
            )}

            Refresh
          </button>
        </div>

        {/* ==========================================
            STATS
        ========================================== */}

        <div className="mt-10 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">

          <StatCard
            title="Total Orders"
            value={stats.total}
            description="All orders"
            icon={
              <ShoppingBag size={19} />
            }
          />

          <StatCard
            title="Revenue"
            value={formatCurrency(
              stats.revenue
            )}
            description="Order value"
            icon={
              <CreditCard size={19} />
            }
          />

          <StatCard
            title="Pending"
            value={stats.pending}
            description="Needs attention"
            icon={
              <Clock3 size={19} />
            }
          />

          <StatCard
            title="Delivered"
            value={stats.completed}
            description="Successfully completed"
            icon={
              <CheckCircle2 size={19} />
            }
          />

        </div>

        {/* ==========================================
            FILTERS
        ========================================== */}

        <div className="mt-8 rounded-[28px] border border-black/[0.05] bg-white p-3 shadow-[0_4px_20px_rgba(0,0,0,0.03)]">

          <div className="flex flex-col gap-3 xl:flex-row">

            <div className="flex h-12 flex-1 items-center rounded-2xl bg-neutral-50 px-4">

              <Search
                size={18}
                className="mr-3 shrink-0 text-neutral-400"
              />

              <input
                type="text"
                value={search}
                onChange={(event) =>
                  setSearch(
                    event.target.value
                  )
                }
                placeholder="Search order number, customer or phone..."
                className="w-full bg-transparent text-sm outline-none placeholder:text-neutral-400"
              />

              {search && (
                <button
                  type="button"
                  onClick={() =>
                    setSearch('')
                  }
                  className="text-neutral-400 hover:text-black"
                >
                  <X size={16} />
                </button>
              )}

            </div>

            <div className="flex overflow-x-auto rounded-2xl bg-neutral-50 p-1">

              {[
                'ALL',
                'PENDING',
                'PROCESSING',
                'SHIPPED',
                'DELIVERED',
                'CANCELLED',
              ].map((status) => (
                <FilterButton
                  key={status}
                  active={
                    statusFilter ===
                    status
                  }
                  onClick={() =>
                    setStatusFilter(
                      status
                    )
                  }
                >
                  {formatStatus(status)}
                </FilterButton>
              ))}

            </div>

            <div className="flex overflow-x-auto rounded-2xl bg-neutral-50 p-1">

              {[
                'ALL',
                'PENDING',
                'PAID',
                'FAILED',
              ].map((status) => (
                <FilterButton
                  key={status}
                  active={
                    paymentFilter ===
                    status
                  }
                  onClick={() =>
                    setPaymentFilter(
                      status
                    )
                  }
                >
                  {formatStatus(status)}
                </FilterButton>
              ))}

            </div>

          </div>

        </div>

        {/* ==========================================
            RESULTS
        ========================================== */}

        <div className="mt-5 flex items-center justify-between px-1">
          <p className="text-xs text-neutral-400">
            Showing{' '}
            <span className="font-semibold text-neutral-700">
              {filteredOrders.length}
            </span>{' '}
            of{' '}
            <span className="font-semibold text-neutral-700">
              {orders.length}
            </span>{' '}
            orders
          </p>
        </div>

        {/* ==========================================
            TABLE
        ========================================== */}

        <div className="mt-4 overflow-hidden rounded-[30px] border border-black/[0.05] bg-white shadow-[0_4px_30px_rgba(0,0,0,0.03)]">

          {filteredOrders.length === 0 ? (
            <EmptyOrders />
          ) : (
            <div className="overflow-x-auto">

              <table className="w-full min-w-[1050px]">

                <thead>
                  <tr className="border-b border-black/[0.05] bg-neutral-50/70">

                    <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-[0.15em] text-neutral-400">
                      Order
                    </th>

                    <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-[0.15em] text-neutral-400">
                      Customer
                    </th>

                    <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-[0.15em] text-neutral-400">
                      Items
                    </th>

                    <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-[0.15em] text-neutral-400">
                      Payment
                    </th>

                    <th className="px-6 py-4 text-left text-[10px] font-bold uppercase tracking-[0.15em] text-neutral-400">
                      Status
                    </th>

                    <th className="px-6 py-4 text-right text-[10px] font-bold uppercase tracking-[0.15em] text-neutral-400">
                      Total
                    </th>

                    <th className="px-6 py-4" />

                  </tr>
                </thead>

                <tbody>
                  <AnimatePresence>
                    {filteredOrders.map(
                      (order) => (
                        <OrderRow
                          key={order.id}
                          order={order}
                          onClick={() =>
                            setSelectedOrder(
                              order
                            )
                          }
                        />
                      )
                    )}
                  </AnimatePresence>
                </tbody>

              </table>

            </div>
          )}

        </div>

      </div>

      {/* ==========================================
          ORDER DRAWER
      ========================================== */}

      <AnimatePresence>
        {selectedOrder && (
          <OrderDrawer
            order={selectedOrder}
            onClose={() =>
              setSelectedOrder(null)
            }
            onStatusChange={
              updateOrderStatus
            }
          />
        )}
      </AnimatePresence>

    </main>
  )
}

/*
==================================================
STAT CARD
==================================================
*/

function StatCard({
  title,
  value,
  description,
  icon,
}) {
  return (
    <motion.div
      initial={{
        opacity: 0,
        y: 12,
      }}
      animate={{
        opacity: 1,
        y: 0,
      }}
      className="rounded-[28px] border border-black/[0.05] bg-white p-6 shadow-[0_4px_20px_rgba(0,0,0,0.03)] transition hover:-translate-y-1 hover:shadow-md"
    >
      <div className="flex items-start justify-between">

        <div>
          <p className="text-xs font-medium text-neutral-400">
            {title}
          </p>

          <h2 className="mt-3 text-3xl font-bold tracking-tight">
            {value}
          </h2>
        </div>

        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-neutral-100">
          {icon}
        </div>

      </div>

      <p className="mt-4 text-[11px] text-neutral-400">
        {description}
      </p>
    </motion.div>
  )
}

/*
==================================================
ORDER ROW
==================================================
*/

function OrderRow({
  order,
  onClick,
}) {
  const customer =
    order.customer || {}

  const items =
    Array.isArray(order.items)
      ? order.items
      : []

  const itemCount =
    items.reduce(
      (total, item) =>
        total +
        (Number(item.quantity) || 0),
      0
    )

  return (
    <motion.tr
      initial={{
        opacity: 0,
      }}
      animate={{
        opacity: 1,
      }}
      exit={{
        opacity: 0,
      }}
      className="group cursor-pointer border-b border-black/[0.04] transition hover:bg-neutral-50/70"
      onClick={onClick}
    >

      <td className="px-6 py-5">

        <div>
          <p className="text-sm font-bold">
            #{order.order_number}
          </p>

          <p className="mt-1 text-[11px] text-neutral-400">
            {formatDate(
              order.created_at
            )}
          </p>
        </div>

      </td>

      <td className="px-6 py-5">

        <div className="flex items-center gap-3">

          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-neutral-100">
            <User size={16} />
          </div>

          <div className="min-w-0">

            <p className="truncate text-sm font-semibold">
              {customer.full_name ||
                order.shipping_name ||
                'Guest Customer'}
            </p>

            <p className="mt-1 truncate text-[11px] text-neutral-400">
              {customer.phone ||
                order.shipping_phone ||
                'No phone'}
            </p>

          </div>

        </div>

      </td>

      <td className="px-6 py-5">

        <div className="flex items-center gap-2">
          <Package
            size={15}
            className="text-neutral-400"
          />

          <span className="text-sm font-medium">
            {itemCount} item
            {itemCount !== 1
              ? 's'
              : ''}
          </span>
        </div>

      </td>

      <td className="px-6 py-5">

        <div>
          <p className="text-xs font-semibold">
            {formatStatus(
              order.payment_method
            )}
          </p>

          <PaymentStatus
            status={
              order.payment_status
            }
          />
        </div>

      </td>

      <td className="px-6 py-5">
        <OrderStatus
          status={order.status}
        />
      </td>

      <td className="px-6 py-5 text-right">

        <p className="text-sm font-bold">
          {formatCurrency(
            order.total_amount
          )}
        </p>

      </td>

      <td className="px-6 py-5">

        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-neutral-100 transition group-hover:bg-black group-hover:text-white">
          <ChevronRight size={16} />
        </div>

      </td>

    </motion.tr>
  )
}

/*
==================================================
ORDER STATUS
==================================================
*/

function OrderStatus({
  status,
}) {
  const value =
    String(status || '')
      .toUpperCase()

  let className =
    'bg-neutral-100 text-neutral-600'

  if (value === 'PENDING') {
    className =
      'bg-amber-50 text-amber-600'
  }

  if (value === 'PROCESSING') {
    className =
      'bg-blue-50 text-blue-600'
  }

  if (
    value === 'SHIPPED' ||
    value === 'DISPATCHED'
  ) {
    className =
      'bg-purple-50 text-purple-600'
  }

  if (
    value === 'DELIVERED' ||
    value === 'COMPLETED'
  ) {
    className =
      'bg-emerald-50 text-emerald-600'
  }

  if (value === 'CANCELLED') {
    className =
      'bg-red-50 text-red-600'
  }

  return (
    <span
      className={`inline-flex rounded-full px-3 py-1.5 text-[10px] font-bold ${className}`}
    >
      {formatStatus(value)}
    </span>
  )
}

/*
==================================================
PAYMENT STATUS
==================================================
*/

function PaymentStatus({
  status,
}) {
  const value =
    String(status || '')
      .toUpperCase()

  let className =
    'text-neutral-400'

  if (value === 'PAID') {
    className =
      'text-emerald-600'
  }

  if (value === 'FAILED') {
    className =
      'text-red-600'
  }

  return (
    <p
      className={`mt-1 text-[10px] font-semibold ${className}`}
    >
      {formatStatus(value)}
    </p>
  )
}

/*
==================================================
ORDER DRAWER
==================================================
*/

function OrderDrawer({
  order,
  onClose,
  onStatusChange,
}) {
  const customer =
    order.customer || {}

  const items =
    Array.isArray(order.items)
      ? order.items
      : []

  return (
    <>
      <motion.div
        initial={{
          opacity: 0,
        }}
        animate={{
          opacity: 1,
        }}
        exit={{
          opacity: 0,
        }}
        className="fixed inset-0 z-[998] bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />

      <motion.aside
        initial={{
          x: '100%',
        }}
        animate={{
          x: 0,
        }}
        exit={{
          x: '100%',
        }}
        transition={{
          type: 'spring',
          damping: 30,
          stiffness: 300,
        }}
        className="fixed right-0 top-0 z-[999] h-full w-full max-w-xl overflow-y-auto bg-white shadow-2xl"
      >

        {/* HEADER */}

        <div className="sticky top-0 z-10 border-b border-black/[0.05] bg-white/90 p-5 backdrop-blur-xl">

          <div className="flex items-center justify-between">

            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-neutral-400">
                Order Details
              </p>

              <h2 className="mt-1 text-xl font-bold">
                #{order.order_number}
              </h2>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-neutral-100 transition hover:bg-black hover:text-white"
            >
              <X size={18} />
            </button>

          </div>

        </div>

        <div className="p-5">

          {/* CUSTOMER */}

          <section className="rounded-[24px] bg-neutral-50 p-5">

            <div className="flex items-center gap-3">

              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-white shadow-sm">
                <User size={18} />
              </div>

              <div>
                <p className="text-sm font-bold">
                  {customer.full_name ||
                    order.shipping_name ||
                    'Guest Customer'}
                </p>

                <p className="mt-1 text-xs text-neutral-400">
                  Customer
                </p>
              </div>

            </div>

            <div className="mt-5 space-y-3">

              <InfoLine
                icon={<Phone size={14} />}
                text={
                  customer.phone ||
                  order.shipping_phone ||
                  'No phone'
                }
              />

              <InfoLine
                icon={<MapPin size={14} />}
                text={buildAddress(order)}
              />

            </div>

          </section>

          {/* STATUS */}

          <section className="mt-5">

            <p className="mb-3 text-xs font-bold uppercase tracking-[0.15em] text-neutral-400">
              Order Status
            </p>

            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">

              {[
                'PENDING',
                'PROCESSING',
                'SHIPPED',
                'DELIVERED',
                'CANCELLED',
              ].map((status) => (
                <button
                  key={status}
                  type="button"
                  onClick={() =>
                    onStatusChange(
                      order.id,
                      status
                    )
                  }
                  className={`rounded-xl px-3 py-3 text-xs font-semibold transition ${
                    String(
                      order.status
                    ).toUpperCase() ===
                    status
                      ? 'bg-black text-white'
                      : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                  }`}
                >
                  {formatStatus(status)}
                </button>
              ))}

            </div>

          </section>

          {/* ITEMS */}

          <section className="mt-7">

            <div className="flex items-center justify-between">
              <p className="text-xs font-bold uppercase tracking-[0.15em] text-neutral-400">
                Order Items
              </p>

              <span className="text-xs text-neutral-400">
                {items.length} product
                {items.length !== 1
                  ? 's'
                  : ''}
              </span>
            </div>

            <div className="mt-3 space-y-3">

              {items.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-3 rounded-2xl border border-black/[0.05] p-3"
                >

                  <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-neutral-100">

                    {item.product_image ? (
                      <img
                        src={
                          item.product_image
                        }
                        alt={
                          item.product_name
                        }
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center">
                        <Package
                          size={18}
                          className="text-neutral-300"
                        />
                      </div>
                    )}

                  </div>

                  <div className="min-w-0 flex-1">

                    <p className="truncate text-sm font-semibold">
                      {item.product_name}
                    </p>

                    <div className="mt-1 flex flex-wrap gap-2 text-[10px] text-neutral-400">

                      {item.size && (
                        <span>
                          Size: {item.size}
                        </span>
                      )}

                      {item.color && (
                        <span>
                          Color: {item.color}
                        </span>
                      )}

                      <span>
                        Qty: {item.quantity}
                      </span>

                    </div>

                    <p className="mt-2 text-xs font-bold">
                      {formatCurrency(
                        item.total_price
                      )}
                    </p>

                  </div>

                </div>
              ))}

            </div>

          </section>

          {/* TOTAL */}

          <section className="mt-7 rounded-[24px] bg-black p-5 text-white">

            <div className="flex justify-between text-sm text-white/60">
              <span>Subtotal</span>
              <span>
                {formatCurrency(
                  order.subtotal
                )}
              </span>
            </div>

            <div className="mt-3 flex justify-between text-sm text-white/60">
              <span>Discount</span>
              <span>
                -
                {formatCurrency(
                  order.discount_amount
                )}
              </span>
            </div>

            <div className="mt-3 flex justify-between text-sm text-white/60">
              <span>Shipping</span>
              <span>
                {formatCurrency(
                  order.shipping_amount
                )}
              </span>
            </div>

            <div className="my-4 border-t border-white/10" />

            <div className="flex justify-between">
              <span className="font-semibold">
                Total
              </span>

              <span className="text-xl font-bold">
                {formatCurrency(
                  order.total_amount
                )}
              </span>
            </div>

          </section>

          {/* PAYMENT */}

          <section className="mt-5 rounded-[24px] border border-black/[0.05] p-5">

            <p className="text-xs font-bold uppercase tracking-[0.15em] text-neutral-400">
              Payment
            </p>

            <div className="mt-4 flex items-center justify-between">

              <div>
                <p className="text-sm font-semibold">
                  {formatStatus(
                    order.payment_method
                  )}
                </p>

                <p className="mt-1 text-xs text-neutral-400">
                  Payment method
                </p>
              </div>

              <PaymentStatus
                status={
                  order.payment_status
                }
              />

            </div>

          </section>

        </div>

      </motion.aside>
    </>
  )
}

/*
==================================================
INFO LINE
==================================================
*/

function InfoLine({
  icon,
  text,
}) {
  return (
    <div className="flex gap-3 text-xs text-neutral-500">
      <span className="mt-0.5 text-neutral-400">
        {icon}
      </span>

      <span className="leading-5">
        {text}
      </span>
    </div>
  )
}

/*
==================================================
FILTER BUTTON
==================================================
*/

function FilterButton({
  active,
  onClick,
  children,
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        active
          ? 'whitespace-nowrap rounded-xl bg-black px-4 py-2.5 text-[11px] font-semibold text-white'
          : 'whitespace-nowrap rounded-xl px-4 py-2.5 text-[11px] font-medium text-neutral-500 transition hover:bg-white'
      }
    >
      {children}
    </button>
  )
}

/*
==================================================
EMPTY
==================================================
*/

function EmptyOrders() {
  return (
    <div className="flex min-h-[400px] flex-col items-center justify-center px-6 text-center">

      <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-neutral-100">
        <ShoppingBag
          size={25}
          className="text-neutral-400"
        />
      </div>

      <h3 className="mt-5 text-lg font-bold">
        No orders found
      </h3>

      <p className="mt-2 max-w-sm text-sm text-neutral-400">
        Try changing your search or filters.
      </p>

    </div>
  )
}

/*
==================================================
HELPERS
==================================================
*/

function formatCurrency(value) {
  return new Intl.NumberFormat(
    'en-IN',
    {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }
  ).format(Number(value) || 0)
}

function formatDate(value) {
  if (!value) return 'Unknown date'

  try {
    return new Intl.DateTimeFormat(
      'en-IN',
      {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }
    ).format(new Date(value))
  } catch {
    return 'Unknown date'
  }
}

function formatStatus(value) {
  if (!value) return 'Unknown'

  return String(value)
    .toLowerCase()
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (char) =>
      char.toUpperCase()
    )
}

function buildAddress(order) {
  const parts = [
    order.shipping_address,
    order.shipping_city,
    order.shipping_state,
    order.shipping_postal_code,
    order.shipping_country,
  ].filter(Boolean)

  if (parts.length === 0) {
    return 'No shipping address'
  }

  return parts.join(', ')
}