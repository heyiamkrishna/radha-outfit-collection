import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import {
  ArrowUpRight,
  ShoppingBag,
  ShoppingCart,
  Users,
  IndianRupee,
  Package,
  Plus,
  AlertTriangle,
} from 'lucide-react'

const formatCurrency = (value) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(value || 0)
}

export default async function AdminDashboard() {
  const supabase = await createClient()

  // --------------------------------------------------
  // PRODUCTS
  // --------------------------------------------------

  const { count: productCount } = await supabase
    .from('products')
    .select('*', {
      count: 'exact',
      head: true,
    })
    .eq('is_active', true)

  // --------------------------------------------------
  // CUSTOMERS
  // --------------------------------------------------

  const { count: customerCount } = await supabase
    .from('profiles')
    .select('*', {
      count: 'exact',
      head: true,
    })
    .eq('role', 'CUSTOMER')

  // --------------------------------------------------
  // ORDERS
  // --------------------------------------------------

  const { count: orderCount } = await supabase
    .from('orders')
    .select('*', {
      count: 'exact',
      head: true,
    })

  // --------------------------------------------------
  // REVENUE
  // --------------------------------------------------

  const { data: revenueOrders } = await supabase
    .from('orders')
    .select('total_amount')
    .in('status', [
      'CONFIRMED',
      'PROCESSING',
      'SHIPPED',
      'DELIVERED',
    ])

  const revenue =
    revenueOrders?.reduce(
      (total, order) =>
        total + Number(order.total_amount || 0),
      0
    ) || 0

  // --------------------------------------------------
  // RECENT ORDERS
  // --------------------------------------------------

  const { data: recentOrders } = await supabase
    .from('orders')
    .select(`
      id,
      order_number,
      total_amount,
      status,
      created_at,
      shipping_name
    `)
    .order('created_at', {
      ascending: false,
    })
    .limit(6)

  // --------------------------------------------------
  // LOW STOCK
  // --------------------------------------------------

  const { data: lowStock } = await supabase
    .from('product_variants')
    .select(`
      id,
      size,
      color,
      stock,
      products (
        name
      )
    `)
    .lte('stock', 5)
    .eq('is_active', true)
    .order('stock', {
      ascending: true,
    })
    .limit(5)

  const stats = [
    {
      title: 'Total Revenue',
      value: formatCurrency(revenue),
      description: 'Confirmed & completed orders',
      icon: IndianRupee,
      href: '/admin/orders',
    },
    {
      title: 'Orders',
      value: orderCount || 0,
      description: 'All customer orders',
      icon: ShoppingCart,
      href: '/admin/orders',
    },
    {
      title: 'Customers',
      value: customerCount || 0,
      description: 'Registered customers',
      icon: Users,
      href: '/admin/customers',
    },
    {
      title: 'Products',
      value: productCount || 0,
      description: 'Active products',
      icon: ShoppingBag,
      href: '/admin/products',
    },
  ]

  return (
    <div className="mx-auto max-w-[1600px]">

      {/* HEADER */}

      <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">

        <div>

          <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-neutral-400">
            Admin / Overview
          </p>

          <h1 className="font-[family-name:var(--font-syne)] text-3xl font-bold tracking-tight sm:text-4xl">
            Good morning, Admin.
          </h1>

          <p className="mt-2 text-sm text-neutral-500">
            Here's what's happening with your store today.
          </p>

        </div>

        <div className="flex gap-2">

          <Link
            href="/admin/products/new"
            className="flex items-center gap-2 rounded-xl bg-neutral-950 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-neutral-800"
          >
            <Plus size={16} />
            Add Product
          </Link>

        </div>

      </div>

      {/* STAT CARDS */}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">

        {stats.map((stat) => {
          const Icon = stat.icon

          return (
            <Link
              key={stat.title}
              href={stat.href}
              className="group relative overflow-hidden rounded-3xl border border-black/[0.05] bg-white p-5 transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-black/[0.04]"
            >

              <div className="mb-8 flex items-start justify-between">

                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-neutral-100">
                  <Icon size={19} />
                </div>

                <ArrowUpRight
                  size={17}
                  className="text-neutral-300 transition group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-neutral-900"
                />

              </div>

              <p className="text-xs text-neutral-400">
                {stat.title}
              </p>

              <p className="mt-1 text-2xl font-semibold tracking-tight">
                {stat.value}
              </p>

              <p className="mt-1 text-[11px] text-neutral-400">
                {stat.description}
              </p>

            </Link>
          )
        })}

      </div>

      {/* MAIN GRID */}

      <div className="mt-6 grid gap-6 xl:grid-cols-[1.6fr_1fr]">

        {/* SALES */}

        <section className="rounded-3xl border border-black/[0.05] bg-white p-6">

          <div className="mb-6 flex items-center justify-between">

            <div>
              <p className="text-lg font-semibold">
                Sales Overview
              </p>

              <p className="mt-1 text-xs text-neutral-400">
                Revenue performance
              </p>
            </div>

            <select className="rounded-xl border border-black/[0.06] bg-neutral-50 px-3 py-2 text-xs outline-none">
              <option>Last 7 days</option>
              <option>Last 30 days</option>
              <option>Last 90 days</option>
            </select>

          </div>

          {/* Chart placeholder */}

          <div className="flex h-[280px] items-end gap-3 border-b border-l border-neutral-100 px-4 pb-0">

            {[35, 48, 42, 70, 55, 78, 90, 65, 82, 96, 74, 88].map(
              (height, index) => (
                <div
                  key={index}
                  className="group relative flex h-full flex-1 items-end"
                >
                  <div
                    style={{
                      height: `${height}%`,
                    }}
                    className="w-full rounded-t-lg bg-neutral-900 transition-all duration-300 group-hover:bg-neutral-600"
                  />
                </div>
              )
            )}

          </div>

          <div className="mt-4 flex justify-between text-[10px] text-neutral-400">
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
            <span>Sun</span>
          </div>

        </section>

        {/* QUICK ACTIONS */}

        <section className="rounded-3xl border border-black/[0.05] bg-neutral-950 p-6 text-white">

          <p className="text-lg font-semibold">
            Quick Actions
          </p>

          <p className="mt-1 text-xs text-neutral-400">
            Manage your store quickly.
          </p>

          <div className="mt-6 space-y-2">

            <QuickAction
              href="/admin/products/new"
              icon={ShoppingBag}
              title="Add Product"
              description="Create a new product"
            />

            <QuickAction
              href="/admin/orders"
              icon={ShoppingCart}
              title="Manage Orders"
              description="View customer orders"
            />

            <QuickAction
              href="/admin/hero-slides"
              icon={Package}
              title="Update Hero"
              description="Change homepage slides"
            />

            <QuickAction
              href="/admin/coupons"
              icon={Plus}
              title="Create Coupon"
              description="Add a promotional code"
            />

          </div>

        </section>

      </div>

      {/* LOWER GRID */}

      <div className="mt-6 grid gap-6 lg:grid-cols-[1.5fr_1fr]">

        {/* RECENT ORDERS */}

        <section className="rounded-3xl border border-black/[0.05] bg-white">

          <div className="flex items-center justify-between border-b border-neutral-100 p-6">

            <div>
              <p className="font-semibold">
                Recent Orders
              </p>

              <p className="mt-1 text-xs text-neutral-400">
                Latest customer activity
              </p>
            </div>

            <Link
              href="/admin/orders"
              className="text-xs font-medium text-neutral-500 hover:text-black"
            >
              View all
            </Link>

          </div>

          <div className="divide-y divide-neutral-100">

            {recentOrders?.length ? (
              recentOrders.map((order) => (
                <Link
                  key={order.id}
                  href={`/admin/orders/${order.id}`}
                  className="flex items-center justify-between gap-4 px-6 py-4 transition hover:bg-neutral-50"
                >

                  <div className="flex min-w-0 items-center gap-3">

                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-neutral-100">
                      <ShoppingBag size={16} />
                    </div>

                    <div className="min-w-0">

                      <p className="truncate text-sm font-medium">
                        #{order.order_number}
                      </p>

                      <p className="truncate text-xs text-neutral-400">
                        {order.shipping_name || 'Customer'}
                      </p>

                    </div>

                  </div>

                  <div className="text-right">

                    <p className="text-sm font-semibold">
                      {formatCurrency(order.total_amount)}
                    </p>

                    <OrderStatus status={order.status} />

                  </div>

                </Link>
              ))
            ) : (
              <div className="px-6 py-12 text-center text-sm text-neutral-400">
                No orders yet.
              </div>
            )}

          </div>

        </section>

        {/* LOW STOCK */}

        <section className="rounded-3xl border border-black/[0.05] bg-white">

          <div className="flex items-center justify-between border-b border-neutral-100 p-6">

            <div>

              <p className="font-semibold">
                Low Stock
              </p>

              <p className="mt-1 text-xs text-neutral-400">
                Products that need attention
              </p>

            </div>

            <AlertTriangle
              size={18}
              className="text-amber-500"
            />

          </div>

          <div className="divide-y divide-neutral-100">

            {lowStock?.length ? (
              lowStock.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between gap-3 px-6 py-4"
                >

                  <div className="min-w-0">

                    <p className="truncate text-sm font-medium">
                      {item.products?.name || 'Product'}
                    </p>

                    <p className="mt-1 text-[11px] text-neutral-400">
                      {item.size || 'No size'}
                      {item.color
                        ? ` · ${item.color}`
                        : ''}
                    </p>

                  </div>

                  <span
                    className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-semibold ${
                      item.stock === 0
                        ? 'bg-red-50 text-red-600'
                        : 'bg-amber-50 text-amber-600'
                    }`}
                  >
                    {item.stock === 0
                      ? 'Out of stock'
                      : `${item.stock} left`}
                  </span>

                </div>
              ))
            ) : (
              <div className="px-6 py-12 text-center text-sm text-neutral-400">
                Inventory looks good.
              </div>
            )}

          </div>

        </section>

      </div>

    </div>
  )
}

function QuickAction({
  href,
  icon: Icon,
  title,
  description,
}) {
  return (
    <Link
      href={href}
      className="group flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.05] p-3 transition hover:bg-white/10"
    >

      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10">
        <Icon size={17} />
      </div>

      <div className="flex-1">

        <p className="text-sm font-medium">
          {title}
        </p>

        <p className="text-[10px] text-neutral-500">
          {description}
        </p>

      </div>

      <ArrowUpRight
        size={15}
        className="text-neutral-600 transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-white"
      />

    </Link>
  )
}

function OrderStatus({ status }) {
  const styles = {
    PENDING: 'bg-amber-50 text-amber-600',
    CONFIRMED: 'bg-blue-50 text-blue-600',
    PROCESSING: 'bg-purple-50 text-purple-600',
    SHIPPED: 'bg-indigo-50 text-indigo-600',
    DELIVERED: 'bg-green-50 text-green-600',
    CANCELLED: 'bg-red-50 text-red-600',
    REFUNDED: 'bg-neutral-100 text-neutral-500',
  }

  return (
    <span
      className={`mt-1 inline-block rounded-full px-2 py-0.5 text-[9px] font-semibold ${
        styles[status] || styles.PENDING
      }`}
    >
      {status}
    </span>
  )
}