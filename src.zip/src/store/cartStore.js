import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export const useCartStore = create(
  persist(
    (set, get) => ({
      cartItems: [],
      isCartOpen: false,
      
      setIsCartOpen: (isOpen) => set({ isCartOpen: isOpen }),

      addToCart: (product, size, color, quantity = 1, price) => set((state) => {
        const existingItem = state.cartItems.find(
          (item) => item.id === product.id && item.size === size && item.color === color
        )

        if (existingItem) {
          return {
            cartItems: state.cartItems.map((item) =>
              item === existingItem ? { ...item, quantity: item.quantity + quantity } : item
            ),
            isCartOpen: true // Auto-open drawer
          }
        }

        return {
          cartItems: [
            ...state.cartItems,
            {
              id: product.id,
              name: product.name,
              slug: product.slug,
              image: product.product_images?.[0]?.image_url || '/images/placeholders/product.jpg',
              size,
              color,
              quantity,
              price,
            },
          ],
          isCartOpen: true // Auto-open drawer
        }
      }),

      removeFromCart: (id, size, color) => set((state) => ({
        cartItems: state.cartItems.filter(
          (item) => !(item.id === id && item.size === size && item.color === color)
        )
      })),

    updateQuantity: (id, size, color, newQuantity) => set((state) => {
        if (newQuantity < 1) return state
        return {
          cartItems: state.cartItems.map((item) =>
            item.id === id && item.size === size && item.color === color
              ? { ...item, quantity: newQuantity }
              : item
          )
        }
      }),

      // Add this new function!
      clearCart: () => set({ cartItems: [] }),
      // Helper getters
      getCartTotal: () => get().cartItems.reduce((total, item) => total + item.price * item.quantity, 0),
      getCartCount: () => get().cartItems.reduce((count, item) => count + item.quantity, 0),
    }),
    {
      name: 'radha-outfit-cart', // Name of the localStorage key
    }
  )
)